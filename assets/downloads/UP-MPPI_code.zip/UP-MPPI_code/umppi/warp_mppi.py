"""GPU (NVIDIA Warp) version of the order-2 unified controller on the waiter task.

One thread per MPPI sample runs the whole rollout: per step the model (forward kinematics, mass
matrix, tool Jacobian, J-dot q-dot), the rows (HOCBF and velocity box, stabilised virtual rows,
support rows), an exact dual active-set solution of the inertia-metric projection, the
semi-implicit step and the cost.  The same formulas as umppi/robot.py, umppi/waiter.py and
umppi/generic.CAMP2, in float32; umppi/tests/test_warp.py checks them against numpy.

Support rows: with the lift-off row n.s >= S_MIN > 0 in place, the tipping rows of the lower end
of the h interval and the slip rows of the upper end of the mu interval can never bind, so only
the h_hi tipping rows, the mu_lo slip rows and the lift-off row are kept (17 instead of 33); the
admissible set is the same.  With every row tightened by eps_x |L| (Prop. tighten) this still holds while
eps_x <= r c S_MIN / (|L(h_lo)| - r c) (1.6 m/s^2 here) for the h_lo rows and eps_x <= S_MIN for the mu_hi rows.
"""
import numpy as np
import torch
import warp as wp

wp.init()

mat77 = wp.types.matrix(shape=(7, 7), dtype=wp.float32)
mat73 = wp.types.matrix(shape=(7, 3), dtype=wp.float32)
mat37 = wp.types.matrix(shape=(3, 7), dtype=wp.float32)
vec7 = wp.types.vector(length=7, dtype=wp.float32)
NR = 34  # rows: 3 virtual equalities, 17 support rows, 14 box rows
matR7 = wp.types.matrix(shape=(NR, 7), dtype=wp.float32)
vecR = wp.types.vector(length=NR, dtype=wp.float32)
ivec8 = wp.types.vector(length=8, dtype=wp.int32)
mat78 = wp.types.matrix(shape=(7, 8), dtype=wp.float32)
mat88 = wp.types.matrix(shape=(8, 8), dtype=wp.float32)
vec8 = wp.types.vector(length=8, dtype=wp.float32)
N_EQ, N_SUP = 3, 17


@wp.func
def chol(A: mat77):
    L = mat77()
    for j in range(7):
        s = A[j, j]
        for k in range(j):
            s = s - L[j, k] * L[j, k]
        ljj = wp.sqrt(wp.max(s, 1.0e-20))
        L[j, j] = ljj
        for i in range(j + 1, 7):
            t = A[i, j]
            for k in range(j):
                t = t - L[i, k] * L[j, k]
            L[i, j] = t / ljj
    return L


@wp.func
def chol_solve(L: mat77, b: vec7):
    y = vec7()
    for i in range(7):
        s = b[i]
        for k in range(i):
            s = s - L[i, k] * y[k]
        y[i] = s / L[i, i]
    x = vec7()
    for ii in range(7):
        i = 6 - ii
        s = y[i]
        for k in range(i + 1, 7):
            s = s - L[k, i] * x[k]
        x[i] = s / L[i, i]
    return x


@wp.func
def row_of(C: matR7, i: int):
    r = vec7()
    for j in range(7):
        r[j] = C[i, j]
    return r


@wp.func
def zrow(Z: mat73, i: int):
    return wp.vec3(Z[i, 0], Z[i, 1], Z[i, 2])


@wp.func
def solve_active(Lm: mat77, C: matR7, d: vecR, xt: vec7, act: ivec8, na: int):
    """x = xt - M^-1 C_A^T lam with lam = (C_A M^-1 C_A^T)^-1 (C_A xt - d_A); returns x and lam
    packed as a (7 + 8) vector would be clumsy, so lam is recomputed by the caller when needed."""
    Wm = mat78()
    for a in range(na):
        w = chol_solve(Lm, row_of(C, act[a]))
        for j in range(7):
            Wm[j, a] = w[j]
    G = mat88()
    rhs = vec8()
    for a in range(na):
        ca = row_of(C, act[a])
        rhs[a] = wp.dot(ca, xt) - d[act[a]]
        for b in range(na):
            s = float(0.0)
            for j in range(7):
                s = s + ca[j] * Wm[j, b]
            G[a, b] = s
    # Cholesky of the na x na block
    Lg = mat88()
    for j in range(na):
        s = G[j, j]
        for k in range(j):
            s = s - Lg[j, k] * Lg[j, k]
        ljj = wp.sqrt(wp.max(s, 1.0e-20))
        Lg[j, j] = ljj
        for i in range(j + 1, na):
            t = G[i, j]
            for k in range(j):
                t = t - Lg[i, k] * Lg[j, k]
            Lg[i, j] = t / ljj
    y = vec8()
    for i in range(na):
        s = rhs[i]
        for k in range(i):
            s = s - Lg[i, k] * y[k]
        y[i] = s / Lg[i, i]
    lam = vec8()
    for ii in range(na):
        i = na - 1 - ii
        s = y[i]
        for k in range(i + 1, na):
            s = s - Lg[k, i] * lam[k]
        lam[i] = s / Lg[i, i]
    x = xt
    for a in range(na):
        for j in range(7):
            x[j] = x[j] - Wm[j, a] * lam[a]
    return x, lam


@wp.func
def project(Lm: mat77, C: matR7, d: vecR, xt: vec7, use_box: int):
    """Exact inertia-metric projection of xt onto {C_eq x = d_eq, C_in x <= d_in} by a dual
    active-set method (equalities always active; box rows only if use_box).  Returns x and a status
    (0 ok, 1 not converged or infeasible)."""
    act = ivec8()
    for a in range(N_EQ):
        act[a] = a
    na = int(N_EQ)
    x = xt
    status = int(1)
    n_rows = int(N_EQ + N_SUP)
    if use_box == 1:
        n_rows = int(NR)
    for it in range(30):
        x, lam = solve_active(Lm, C, d, xt, act, na)
        # drop the inequality with the most negative multiplier
        imin = int(-1)
        lmin = float(-1.0e-7)
        for a in range(N_EQ, na):
            if lam[a] < lmin:
                lmin = lam[a]
                imin = a
        if imin >= 0:
            act[imin] = act[na - 1]
            na = na - 1
            continue
        # add the most violated inequality
        imax = int(-1)
        vmax = float(1.0e-5)
        for i in range(N_EQ, n_rows):
            inA = int(0)
            for a in range(na):
                if act[a] == i:
                    inA = 1
            if inA == 0:
                v = wp.dot(row_of(C, i), x) - d[i]
                if v > vmax:
                    vmax = v
                    imax = i
        if imax < 0:
            status = 0
            break
        if na >= 7:
            break
        act[na] = imax
        na = na + 1
    return x, status


@wp.kernel
def rollout(
    q0: vec7, qd0: vec7, U: wp.array(dtype=vec7), eps: wp.array2d(dtype=vec7),
    Rx: wp.array(dtype=wp.mat33), P: wp.array(dtype=wp.vec3), COM: wp.array(dtype=wp.vec3),
    MASS: wp.array(dtype=float), IL: wp.array(dtype=wp.mat33), ARM: vec7,
    base_rot: wp.mat33, base_pos: wp.vec3, tool: wp.vec3,
    qmin: vec7, qmax: vec7, qdmax: vec7, prm: wp.array(dtype=float),
    qref: vec7, pref: wp.array(dtype=wp.vec3), vref: wp.array(dtype=wp.vec3),
    H: int, Aout: wp.array2d(dtype=vec7), Sout: wp.array(dtype=float), relax: wp.array(dtype=wp.int32),
):
    k = wp.tid()
    # parameters
    dt = prm[0]
    h_safe = prm[1]
    k1 = prm[2]
    k2 = prm[3]
    KP = prm[4]
    KD = prm[5]
    h_hi = prm[6]
    mu_lo = prm[7]
    rbase = prm[8]
    c8 = prm[9]
    smin = prm[10]
    w_p = prm[11]
    w_pv = prm[12]
    w_v = prm[13]
    w_q = prm[14]
    w_T = prm[15]
    w_Tv = prm[16]
    mode = int(prm[17])  # 0: support rows hard (unified); 1: support rows as a penalty (baseline)
    w_s = prm[18]
    eps_x = prm[19]  # execution-error tightening: row L s <= b becomes L s <= b - |L| eps_x
    g = wp.vec3(0.0, 0.0, -9.81)
    q = q0
    qd = qd0
    S = float(0.0)
    nrelax = int(0)
    for t in range(H + 1):
        # ---------------- model at (q, qd): forward kinematics and mass matrix in one pass
        R = base_rot
        o = base_pos
        Z = mat73()
        O = mat73()
        M = mat77()
        for i in range(7):
            o = o + R * P[i]
            c = wp.cos(q[i])
            s = wp.sin(q[i])
            Rz = wp.mat33(c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0)
            R = R * Rx[i] * Rz
            for m in range(3):
                Z[i, m] = R[m, 2]
                O[i, m] = o[m]
            pci = o + R * COM[i]
            Iw = R * IL[i] * wp.transpose(R)
            for j in range(i + 1):
                zj = zrow(Z, j)
                cj = wp.cross(zj, pci - zrow(O, j))
                Izj = Iw * zj
                for l in range(j + 1):
                    zl = zrow(Z, l)
                    cl = wp.cross(zl, pci - zrow(O, l))
                    val = MASS[i] * wp.dot(cj, cl) + wp.dot(zl, Izj)
                    M[j, l] = M[j, l] + val
                    if l != j:
                        M[l, j] = M[l, j] + val
        for i in range(7):
            M[i, i] = M[i, i] + ARM[i]
        pt = o + R * tool
        # tool Jacobian, tool velocity, angular velocity
        Jv = mat37()
        Jw = mat37()
        vpt = wp.vec3(0.0, 0.0, 0.0)
        w = wp.vec3(0.0, 0.0, 0.0)
        for j in range(7):
            zj = zrow(Z, j)
            cj = wp.cross(zj, pt - zrow(O, j))
            for m in range(3):
                Jv[m, j] = cj[m]
                Jw[m, j] = zj[m]
            vpt = vpt + cj * qd[j]
            w = w + zj * qd[j]
        if t > 0:  # running cost of the state reached by step t-1
            dp = pt - pref[t - 1]
            dv = vpt - vref[t - 1]
            dq = q - qref
            S = S + dt * (w_p * wp.dot(dp, dp) + w_pv * wp.dot(dv, dv) + w_v * wp.dot(qd, qd) + w_q * wp.dot(dq, dq))
        if t == H:
            dp = pt - pref[H - 1]
            dv = vpt - vref[H - 1]
            S = S + w_T * wp.dot(dp, dp) + w_Tv * wp.dot(dv, dv)
            break
        # J-dot q-dot of the tool point (world frame)
        ab = wp.vec3(0.0, 0.0, 0.0)
        alb = wp.vec3(0.0, 0.0, 0.0)
        wprev = wp.vec3(0.0, 0.0, 0.0)
        for j in range(7):
            zj = zrow(Z, j)
            oj = zrow(O, j)
            voj = wp.vec3(0.0, 0.0, 0.0)
            for i in range(j):
                voj = voj + wp.cross(zrow(Z, i), oj - zrow(O, i)) * qd[i]
            zdot = wp.cross(wprev, zj)
            ab = ab + (wp.cross(zdot, pt - oj) + wp.cross(zj, vpt - voj)) * qd[j]
            alb = alb + zdot * qd[j]
            wprev = wprev + zj * qd[j]
        # ---------------- rows
        C = matR7()
        dd = vecR()
        ntr = -wp.vec3(R[0, 2], R[1, 2], R[2, 2])
        x7 = wp.vec3(R[0, 0], R[1, 0], R[2, 0])
        ex = wp.vec3(1.0, 0.0, 0.0)
        ey = wp.vec3(0.0, 1.0, 0.0)
        for r in range(3):
            v = ntr
            u = ex
            ev = ntr[0]
            if r == 1:
                u = ey
                ev = ntr[1]
            if r == 2:
                v = x7
                u = ey
                ev = x7[1]
            a = wp.cross(v, u)
            jq = float(0.0)
            for j in range(7):
                cjs = wp.dot(a, zrow(Z, j))
                C[r, j] = cjs
                jq = jq + cjs * qd[j]
            jd = wp.dot(wp.cross(wp.cross(w, v), u), w) + wp.dot(a, alb)
            dd[r] = -KD * jq - KP * ev - jd
        t1 = x7 - ntr * wp.dot(x7, ntr)
        t1 = wp.normalize(t1)
        t2 = wp.cross(ntr, t1)
        jds = ab - g
        for kk in range(8):
            th = 2.0 * 3.14159265358979 * float(kk) / 8.0
            u = t1 * wp.cos(th) + t2 * wp.sin(th)
            Lt = u * h_hi - ntr * (rbase * c8)
            Ls = u - ntr * (mu_lo * c8)
            for j in range(7):
                colj = wp.vec3(Jv[0, j], Jv[1, j], Jv[2, j])
                C[N_EQ + kk, j] = wp.dot(Lt, colj)
                C[N_EQ + 8 + kk, j] = wp.dot(Ls, colj)
            dd[N_EQ + kk] = -wp.dot(Lt, jds) - eps_x * wp.length(Lt)
            dd[N_EQ + 8 + kk] = -wp.dot(Ls, jds) - eps_x * wp.length(Ls)
        for j in range(7):
            colj = wp.vec3(Jv[0, j], Jv[1, j], Jv[2, j])
            C[N_EQ + 16, j] = -wp.dot(ntr, colj)
        dd[N_EQ + 16] = wp.dot(ntr, jds) - smin - eps_x
        sgain = k1 + k2
        pgain = k1 * k2
        for j in range(7):
            lo = q[j] - (qmin[j] + h_safe)
            hi = (qmax[j] - h_safe) - q[j]
            d_lo = wp.min(sgain * qd[j] + pgain * lo, (qdmax[j] + qd[j]) / dt)
            d_hi = wp.min(-sgain * qd[j] + pgain * hi, (qdmax[j] - qd[j]) / dt)
            C[N_EQ + N_SUP + j, j] = -1.0
            dd[N_EQ + N_SUP + j] = d_lo
            C[N_EQ + N_SUP + 7 + j, j] = 1.0
            dd[N_EQ + N_SUP + 7 + j] = d_hi
        if mode == 1:  # penalty baseline: the support rows leave the projection
            for i in range(N_EQ, N_EQ + N_SUP):
                for j in range(7):
                    C[i, j] = 0.0
                dd[i] = 1.0e6
        # normalise the rows (uniform tolerances)
        for i in range(NR):
            nrm = float(0.0)
            for j in range(7):
                nrm = nrm + C[i, j] * C[i, j]
            nrm = wp.sqrt(nrm)
            if nrm > 1.0e-9:
                for j in range(7):
                    C[i, j] = C[i, j] / nrm
                dd[i] = dd[i] / nrm
        # ---------------- projection in the inertia metric
        Lm = chol(M)
        xt = U[t] + eps[k, t]
        x, st = project(Lm, C, dd, xt, 1)
        if st != 0:  # priority fallback: box rows relaxed, support and virtual rows kept
            x, st = project(Lm, C, dd, xt, 0)
            nrelax = nrelax + 1
        Aout[k, t] = x
        if mode == 1:  # squared violation of the support rows, in m/s^2, added to the cost
            sacc = jds
            for j in range(7):
                sacc = sacc + wp.vec3(Jv[0, j], Jv[1, j], Jv[2, j]) * x[j]
            sn = wp.dot(ntr, sacc)
            pen = float(0.0)
            for kk in range(8):
                th = 2.0 * 3.14159265358979 * float(kk) / 8.0
                u = t1 * wp.cos(th) + t2 * wp.sin(th)
                us = wp.dot(u, sacc)
                # the same rows as the hard mode, tightened by eps_x (|Lt|, |Ls| do not depend on u)
                v1 = wp.max(h_hi * us - rbase * c8 * sn + eps_x * wp.sqrt(h_hi * h_hi + rbase * rbase * c8 * c8), 0.0)
                v2 = wp.max(us - mu_lo * c8 * sn + eps_x * wp.sqrt(1.0 + mu_lo * mu_lo * c8 * c8), 0.0)
                pen = pen + v1 * v1 + v2 * v2
            v3 = wp.max(smin + eps_x - sn, 0.0)
            S = S + dt * w_s * (pen + v3 * v3)
        # ---------------- semi-implicit step
        qd = qd + x * dt
        q = q + qd * dt
    Sout[k] = S
    relax[k] = nrelax


class WarpWaiterMPPI:
    """Drop-in for generic.CAMP2 on the waiter task (separable = joint: no physical rows)."""

    def __init__(self, chain, task, K=256, H=20, dt=0.02, sigma=1.0, eta=0.5, k1=4.0, k2=4.0, KP=100.0, KD=20.0,
                 seed=0, device="cuda:0", mode="hard", w_s=1e4, exec_project=False, average="projected",
                 noise_clip=3.0, nominal="raw"):
        """mode "hard": rows enforced in every rollout; mode "penalty": support rows as a cost of weight w_s
        (baseline A1); exec_project: exact projection of the executed command (baseline A2).
        average "projected": the update averages the projected samples (admissible by convexity);
        "raw": the standard MPPI update U + sum_k w_k eps_k on the raw inputs, the rollouts still projected,
        and the executed command projected once at the measured state (Algorithm 1, the unified controller).
        noise_clip: exploration noise truncated at this many standard deviations (bounded inputs, Thm. 2(vi))."""
        self.mode, self.w_s, self.exec_project = mode, w_s, exec_project or average == "raw"
        self.average, self.noise_clip, self.nominal = average, noise_clip, nominal  # nominal "filtered": warm start
        # from the raw average projected along one rollout (execution filtering, PR-MPPI Eq. 13), not the raw average
        self.K, self.H, self.dt, self.sigma, self.eta, self.dev = K, H, dt, sigma, eta, device
        self.task, self.n = task, 7
        f32 = lambda a: np.asarray(a, dtype=np.float32)  # noqa: E731
        self.Rx = wp.array(f32(chain.Rx), dtype=wp.mat33, device=device)
        self.P = wp.array(f32(chain.p), dtype=wp.vec3, device=device)
        self.COM = wp.array(f32(chain.com), dtype=wp.vec3, device=device)
        self.MASS = wp.array(f32(chain.mass), dtype=float, device=device)
        self.IL = wp.array(f32(chain.I), dtype=wp.mat33, device=device)
        self.ARM = vec7(*f32(chain.armature))
        self.base_rot, self.base_pos, self.tool = wp.mat33(*f32(chain.base_rot).ravel()), wp.vec3(*f32(chain.base_pos)), wp.vec3(*f32(chain.tool))
        self.qmin, self.qmax, self.qdmax = vec7(*f32(task.q_min)), vec7(*f32(task.q_max)), vec7(*f32(task.qd_max))
        self.gains = (k1, k2, KP, KD)
        self.U = np.zeros((H, 7), dtype=np.float32)
        self.Aout = wp.zeros((K, H), dtype=vec7, device=device)
        self.Sout = wp.zeros(K, dtype=float, device=device)
        self.relax = wp.zeros(K, dtype=wp.int32, device=device)
        self.gen = torch.Generator(device="cuda").manual_seed(seed)
        self.stats = {"time": [], "relaxed": 0}
        # persistent device buffers, refilled in place every plan (no allocation on the control path)
        self.prm_t = torch.zeros(20, device="cuda")
        self.pref_t = torch.zeros((H, 3), device="cuda")
        self.vref_t = torch.zeros((H, 3), device="cuda")
        self.U_t = torch.zeros((H, 7), device="cuda")
        self.eps_t = torch.zeros((K, H, 7), device="cuda")
        self.prm_w, self.pref_w = wp.from_torch(self.prm_t), wp.from_torch(self.pref_t, dtype=wp.vec3)
        self.vref_w, self.U_w = wp.from_torch(self.vref_t, dtype=wp.vec3), wp.from_torch(self.U_t, dtype=vec7)
        self.eps_w = wp.from_torch(self.eps_t, dtype=vec7)
        self.qref_w = vec7(*np.asarray(task.q_ref, np.float32))
        # final projection of the executed command: the same kernel with one thread, one step, zero noise and
        # every row hard (the support rows too in penalty mode)
        self.U1_t = torch.zeros((H, 7), device="cuda")
        self.eps1_t = torch.zeros((1, H, 7), device="cuda")
        self.prm1_t = torch.zeros(20, device="cuda")
        self.U1_w, self.eps1_w = wp.from_torch(self.U1_t, dtype=vec7), wp.from_torch(self.eps1_t, dtype=vec7)
        self.prm1_w = wp.from_torch(self.prm1_t)
        self.A1 = wp.zeros((1, H), dtype=vec7, device=device)
        self.S1 = wp.zeros(1, dtype=float, device=device)
        self.r1 = wp.zeros(1, dtype=wp.int32, device=device)
        self.stats["exec_relaxed"] = 0

    def _params_np(self):
        T = self.task
        from . import waiter as W
        k1, k2, KP, KD = self.gains
        return np.asarray([self.dt, T.h_safe, k1, k2, KP, KD, max(T.h_box), min(T.mu_box), W.R_BASE, W.C8, W.S_MIN,
                           T.w_p, T.w_pv, T.w_v, T.w_q, T.w_T, T.w_Tv, 1.0 if self.mode == "penalty" else 0.0,
                           self.w_s, getattr(T, "eps_exec", 0.0)], dtype=np.float32)

    def _params(self):
        return wp.array(self._params_np(), dtype=float, device=self.dev)

    def _filter(self, q0, qd0, seq):
        """Execution filtering: the sequence projected onto all rows (tightened as in the rollouts) along one
        rollout from the measured state, by the rollout kernel with one thread and zero noise; its first
        element is the projection of seq[0] at the measured state, the executed command."""
        self.U1_t.copy_(torch.from_numpy(np.asarray(seq, np.float32)))
        self.prm1_t.copy_(self.prm_t)
        self.prm1_t[17] = 0.0  # support rows hard, also for the penalty baseline
        wp.launch(rollout, dim=1, device=self.dev, inputs=[
            vec7(*np.asarray(q0, np.float32)), vec7(*np.asarray(qd0, np.float32)), self.U1_w, self.eps1_w,
            self.Rx, self.P, self.COM, self.MASS, self.IL, self.ARM, self.base_rot, self.base_pos, self.tool,
            self.qmin, self.qmax, self.qdmax, self.prm1_w, self.qref_w, self.pref_w, self.vref_w,
            self.H if self.nominal == "filtered" else 1, self.A1, self.S1, self.r1])  # the horizon only when it is used
        self.stats["exec_relaxed"] += int(self.r1.numpy()[0])
        return self.A1.numpy()[0].astype(np.float64)

    def plan(self, q0, qd0, t_now, eps=None, return_samples=False):
        import time as _t
        from . import waiter as W
        t0 = _t.perf_counter()
        T, K, H = self.task, self.K, self.H
        c = self.noise_clip
        if eps is None and getattr(self, "rng", None) is not None:  # numpy noise, the same draws as CAMP2
            z = self.rng.standard_normal((K, H, 7))
            eps = self.sigma * (z if c is None else np.clip(z, -c, c))
        if eps is None:
            torch.randn((K, H, 7), generator=self.gen, device="cuda", out=self.eps_t)
            if c is not None:
                self.eps_t.clamp_(-c, c)
            self.eps_t.mul_(self.sigma)
        else:
            self.eps_t.copy_(torch.from_numpy(np.asarray(eps, dtype=np.float32)))
        taus = T.t_now + (np.arange(H) + 1) * self.dt
        self.pref_t.copy_(torch.from_numpy(W.target(taus).astype(np.float32)))
        self.vref_t.copy_(torch.from_numpy(W.target_vel(taus).astype(np.float32)))
        self.U_t.copy_(torch.from_numpy(self.U.astype(np.float32)))
        self.prm_t.copy_(torch.from_numpy(self._params_np()))
        prof = getattr(self, "profile", False)
        if prof:
            wp.synchronize()
            tk = _t.perf_counter()
        wp.launch(rollout, dim=K, device=self.dev, inputs=[
            vec7(*np.asarray(q0, np.float32)), vec7(*np.asarray(qd0, np.float32)), self.U_w, self.eps_w,
            self.Rx, self.P, self.COM, self.MASS, self.IL, self.ARM, self.base_rot, self.base_pos, self.tool,
            self.qmin, self.qmax, self.qdmax, self.prm_w, self.qref_w, self.pref_w, self.vref_w,
            H, self.Aout, self.Sout, self.relax])
        if prof:
            wp.synchronize()
            self.stats.setdefault("kernel", []).append(_t.perf_counter() - tk)
        S = wp.to_torch(self.Sout)
        A = wp.to_torch(self.Aout).view(K, H, 7)
        beta = torch.clamp(self.eta * S.std(unbiased=False), min=1e-12)
        wgt = torch.exp(-(S - S.min()) / beta)
        wgt = wgt / wgt.sum()
        if self.average == "raw":
            As = self.U + torch.einsum("k,kti->ti", wgt, self.eps_t).cpu().numpy()
        else:
            As = torch.einsum("k,kti->ti", wgt, A).cpu().numpy()
        self.U = np.concatenate([As[1:], np.zeros((1, 7), dtype=np.float32)], 0).astype(np.float32)
        a0 = As[0].astype(np.float64)
        if self.exec_project:
            Af = self._filter(q0, qd0, As)
            a0 = Af[0]
            if self.nominal == "filtered":
                self.U = np.concatenate([Af[1:], np.zeros((1, 7))], 0).astype(np.float32)
        self.stats["relaxed"] += int(wp.to_torch(self.relax).sum().item())
        self.stats["time"].append(_t.perf_counter() - t0)
        out = {"a": a0}
        if return_samples:
            out.update(A=A.cpu().numpy(), S=S.cpu().numpy(), w=wgt.cpu().numpy())
        return out
