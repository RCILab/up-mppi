"""Baselines on the waiter task (h = 0.14 m, the seeds of the main runs).

A1  penalty MPPI: the robust support rows as a cost of weight w_s (motion rows kept hard), w_s swept
A2  penalty MPPI with the raw average and the executed command projected exactly onto all rows (safety filter):
    Algorithm 1 with the support rows penalised instead of projected in the rollouts
A3  one-step QP (task-space inverse dynamics with the same hard rows, no horizon); its PD gain omega
    is swept (--omega-sweep, one seed: the controller and the physics are deterministic) and the best
    value, OMEGA_BEST, is used everywhere else
B1  certainty-equivalence adaptation: the unified controller with a recursive least-squares estimate
    of (m, m h, m d) and the point estimate of h in the rows, started from the prior midpoint
    (adaptive-rls) or from the nominal model h = 0.07 (adaptive-rls-nom)
MPPI variants run on the GPU controller with the same noise draws as the numpy runs.
--sweep runs the tuned baselines over the h grid of the main sweep (seeds 0-2).
Writes results/waiter_baselines.json (or waiter_baselines_sweep.json, waiter_baselines_omega.json).
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import waiter_exp as X  # noqa: E402

W_SWEEP = (1e3, 1e4, 1e5, 1e6)
OMEGA_SWEEP = (1.5, 2.5, 4.0, 6.0, 9.0, 15.0)
OMEGA_BEST = 6.0  # smallest move-1 error without a tip over OMEGA_SWEEP at h = 0.14
TUNED = (("penalty", 1e5), ("penalty-exec", 1e4), ("onestep", OMEGA_BEST), ("adaptive-rls", None),
         ("adaptive-rls-nom", None))  # best w_s of each penalty variant at h = 0.14
H_SWEEP = (0.08, 0.11, 0.17)
EXEC_FILE = Path(__file__).resolve().parent / "results" / "waiter_exec_bound.json"


RAW = ("robust-rawavg", "adaptive-cop-rawavg", "oracle-rawavg")
PROJ = ("robust-projected", "adaptive-cop-projected", "oracle-projected")  # the average of CAMP-MPPI (ablation)


def _job(a):
    label, w, seed, h_true, T = a[:5]
    eps = a[5] if len(a) > 5 else 0.0  # execution-error tightening of the support rows
    import warnings
    warnings.filterwarnings("ignore")
    from umppi.baselines import OneStepQPWaiter
    from umppi.warp_mppi import WarpWaiterMPPI
    name = "robust"
    if label.removesuffix("-tight") in ("penalty", "penalty-exec"):
        # A1 executes its average; A2 is Algorithm 1 with the support rows as a penalty in the rollouts
        # (raw average, the executed command projected onto all rows)
        avg_ = "raw" if label.startswith("penalty-exec") else "projected"
        fac = lambda task: WarpWaiterMPPI(task.chain, task, K=X.K, H=X.H, dt=X.DT, mode="penalty", w_s=w,  # noqa: E731
                                         average=avg_)
    elif label.removesuffix("-tight") in RAW + PROJ:  # averaging ablation of the unified controller
        avg = "raw" if "-rawavg" in label else "projected"
        base = label.removesuffix("-tight").rsplit("-rawavg" if avg == "raw" else "-projected", 1)[0]
        name = {"robust": "robust", "adaptive-cop": X.COP, "oracle": "oracle"}[base]
        fac = lambda task: WarpWaiterMPPI(task.chain, task, K=X.K, H=X.H, dt=X.DT, average=avg)  # noqa: E731
    elif label == "onestep":
        fac = lambda task: OneStepQPWaiter(task, omega=w, dt=X.DT)  # noqa: E731
    else:  # adaptive-rls or adaptive-rls-nom: Algorithm 1 with the certainty-equivalence estimate in the rows
        name = X.RLS if label == "adaptive-rls" else X.RLS_NOM
        eps = X.EPS_EXEC
        fac = X.default_controller
    try:
        r, log = X.run(name, seed, h_true, T=T, controller_factory=fac, eps_exec=eps)
    except Exception as exc:
        return {"controller": label, "w_s": w, "h_true": h_true, "seed": seed, "error": repr(exc)}, {}
    r["controller"] = label
    r["omega" if label == "onestep" else "w_s"] = w
    return r, {k: np.asarray(v).tolist() for k, v in log.items() if k in ("t", "p", "tgt", "tilt", "hbox")}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--procs", type=int, default=6)
    ap.add_argument("--T", type=float, default=X.WT.T_RUN)
    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--omega-sweep", action="store_true")
    ap.add_argument("--rawavg", action="store_true")
    ap.add_argument("--calib-exec", action="store_true")
    ap.add_argument("--rawavg-tight", action="store_true")
    ap.add_argument("--penalty-only", action="store_true")
    ap.add_argument("--ablation", action="store_true")
    args = ap.parse_args()
    jobs = []
    if args.ablation:  # {projected, raw} average without tightening, and the projected average tightened
        eps = json.loads(EXEC_FILE.read_text())["eps_exec"]
        labs = [(c, 0.0) for c in PROJ + RAW] + [("robust-projected-tight", eps)]
        jobs = [(c, None, s, 0.14, args.T, e) for s in range(args.seeds) for c, e in labs]
        jobs += [(c, None, s, h, args.T, e) for h in H_SWEEP for s in range(3) for c, e in labs]
        tag = "_ablation"
    elif args.calib_exec:  # execution-error bound: oracle, raw average, ends of the prior, separate seeds
        jobs = [("oracle-rawavg", None, s, h, args.T) for h in (0.05, 0.115, 0.18) for s in (100, 101)]
        tag = "_calib_exec"
    elif args.rawavg_tight:
        eps = json.loads(EXEC_FILE.read_text())["eps_exec"]
        labs = [("robust-rawavg-tight", None), ("adaptive-cop-rawavg-tight", None), ("oracle-rawavg-tight", None),
                ("penalty-exec-tight", 1e4)]
        if args.penalty_only:  # penalty baseline with the tightened rows in its cost too: w_s sweep, then the best
            labs = [("penalty-exec-tight", w) for w in (1e3, 1e4, 1e5)]
            tag_extra = "_penalty"
        jobs = [(c, w, s, 0.14, args.T, eps) for s in range(args.seeds) for c, w in labs]
        jobs += [(c, w, s, h, args.T, eps) for h in H_SWEEP for s in range(3) for c, w in labs]
        tag = "_rawavg_tight" + (tag_extra if args.penalty_only else "")
    elif args.rawavg:
        jobs = [(c, None, s, 0.14, args.T) for s in range(args.seeds) for c in ("robust-rawavg", "adaptive-cop-rawavg")]
        jobs += [(c, None, s, h, args.T) for h in H_SWEEP for s in range(3) for c in ("robust-rawavg", "adaptive-cop-rawavg")]
        tag = "_rawavg"
    elif args.omega_sweep:
        jobs = [("onestep", om, 0, 0.14, args.T) for om in OMEGA_SWEEP]
        tag = "_omega"
    elif args.sweep:
        jobs = [(c, w, s, h, args.T) for h in H_SWEEP for s in range(3) for c, w in TUNED]
        tag = "_sweep"
    else:
        for s in range(args.seeds):
            jobs += [("penalty", w, s, 0.14, args.T) for w in W_SWEEP]
            jobs += [("penalty-exec", w, s, 0.14, args.T) for w in W_SWEEP]
            jobs += [("onestep", OMEGA_BEST, s, 0.14, args.T), ("adaptive-rls", None, s, 0.14, args.T),
                     ("adaptive-rls-nom", None, s, 0.14, args.T)]
        tag = ""
    out = Path(__file__).resolve().parent / "results" / f"waiter_baselines{tag}.json"
    rows, logs = [], {}
    with Pool(args.procs) as pool:
        for r, lg in pool.imap_unordered(_job, jobs):
            rows.append(r)
            logs[f"{r['controller']}|{r.get('w_s', r.get('omega'))}|{r.get('h_true')}|{r['seed']}"] = lg
            keys = ("controller", "w_s", "omega", "h_true", "seed", "tipped", "t_tip", "rmse1", "rmse2", "peak_ah", "oct_model_max", "cop_true_max", "h_final", "ms_per_step", "error")
            print(json.dumps({k: (round(r[k], 3) if isinstance(r.get(k), float) else r.get(k)) for k in keys if k in r}), flush=True)
            out.write_text(json.dumps({"rows": rows, "logs": logs}))
    if args.calib_exec:  # own file: waiter_bounds.json stays frozen (other studies hash it)
        dev = max(r["dev_max"] for r in rows)
        EXEC_FILE.write_text(json.dumps({"eps_exec": 1.5 * dev, "dev_max": dev, "margin": 1.5,
                                         "per_run": {f"{r['h_true']}|{r['seed']}": r["dev_max"] for r in rows}}, indent=1))
        print("eps_exec", 1.5 * dev)
