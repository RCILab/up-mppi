"""The Warp controller against the numpy reference (generic.CAMP2) on the waiter task, same noise.

Checks, for K samples and H steps from one state:
  step-0 projections (all samples share the state: pure model, rows and QP check),
  all projected inputs along the rollouts, the costs, and the executed command.
Run from the repo root: python -m umppi.tests.test_warp
"""
import time

import numpy as np

from umppi import waiter as WT
from umppi.generic import CAMP2, _weights
from umppi.warp_mppi import WarpWaiterMPPI

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])


def numpy_plan(ctrl, q0, qd0, eps):
    """The loop of CAMP2.plan, returning the samples."""
    T, K, H, n, dt = ctrl.task, ctrl.K, ctrl.H, ctrl.n, ctrl.dt
    q, qd = np.repeat(q0[None], K, 0), np.repeat(qd0[None], K, 0)
    S, Ap = np.zeros(K), np.empty((K, H, n))
    for t in range(H):
        mdl = ctrl._model(q, qd)
        a = ctrl._pi(q, qd, ctrl.U[t][None] + eps[:, t], mdl)
        qd = qd + dt * a
        q = q + dt * qd
        Ap[:, t] = a
        S += T.run_cost(q, qd, None, t) * dt
    S += T.term_cost(q, qd)
    w = _weights(S, ctrl.eta)
    return Ap, S, w, np.einsum("k,kti->ti", w, Ap)


def main(K=256, H=20, dt=0.02, seed=0):
    ch = WT.make_chain()
    q0 = WT.ik(ch, WT.A_PT, Q_READY)
    rng = np.random.default_rng(seed)
    task = WT.WaiterTask(ch, [0.05, 0.18], [0.4, 0.8], q_ref=q0, dt=dt, H=H)
    task.t_now = 0.5  # inside move 1: the tracking cost pushes the support rows
    qd0 = np.array([0.05, -0.1, 0.08, 0.1, -0.05, 0.1, 0.02])
    eps = rng.standard_normal((K, H, 7))
    ref = CAMP2(task, sigma=1.0, solver="separable", virtual="hard", dt=dt, H=H, K=K)
    t0 = time.perf_counter()
    Ap, S, w, As = numpy_plan(ref, q0, qd0, eps)
    t_np = time.perf_counter() - t0
    gpu = WarpWaiterMPPI(ch, task, K=K, H=H, dt=dt)
    out = gpu.plan(q0, qd0, 0.5, eps=eps, return_samples=True)
    A_g, S_g = out["A"], out["S"]
    scale = np.max(np.abs(Ap)) + 1e-12
    e0 = np.max(np.abs(A_g[:, 0] - Ap[:, 0]))
    eall = np.abs(A_g - Ap)
    print(f"step-0 projections: max |dA| = {e0:.2e} (scale {scale:.1f}), relative {e0 / scale:.1e}")
    print(f"all steps: median |dA| = {np.median(eall):.1e}, 99th pct {np.percentile(eall, 99):.1e}, max {eall.max():.2e}")
    print(f"costs: max relative error {np.max(np.abs(S_g - S) / np.abs(S)):.1e};  weights: max |dw| {np.max(np.abs(out['w'] - w)):.1e}")
    print(f"executed command: max |da| = {np.max(np.abs(out['a'] - As[0])):.2e}  (|a| = {np.max(np.abs(As[0])):.2f});  relaxed {gpu.stats['relaxed']}")
    # timing
    for Kt in (256, 1024, 4096):
        g = WarpWaiterMPPI(ch, task, K=Kt, H=H, dt=dt)
        g.plan(q0, qd0, 0.5)
        ts = []
        for _ in range(20):
            t0 = time.perf_counter()
            g.plan(q0, qd0, 0.5)
            ts.append(time.perf_counter() - t0)
        print(f"K={Kt:5d}: GPU plan {1e3 * np.median(ts):.2f} ms (median of 20), numpy reference K={K}: {1e3 * t_np:.0f} ms")
    ok = e0 / scale < 1e-3 and np.percentile(eall, 99) / scale < 1e-2
    ok = raw_check(ch, q0, qd0, K, H, dt) and ok
    print("PASS" if ok else "FAIL")
    return ok


def raw_check(ch, q0, qd0, K, H, dt, eps_exec=0.1, seed=3):
    """Algorithm 1 as run in the experiments: raw average, noise truncated at 3 sigma, rows tightened by
    eps_exec, the executed command projected once.  Two consecutive plans from the same state (the second
    uses each controller's own raw nominal), same numpy draws; the executed command must satisfy the
    tightened support rows at the measured state."""
    task = WT.WaiterTask(ch, [0.05, 0.18], [0.4, 0.8], q_ref=q0, dt=dt, H=H, eps_exec=eps_exec)
    task.t_now = 0.5
    ref = CAMP2(task, sigma=1.0, solver="separable", virtual="hard", dt=dt, H=H, K=K, average="raw", noise_clip=3.0)
    gpu = WarpWaiterMPPI(ch, task, K=K, H=H, dt=dt, average="raw", noise_clip=3.0)
    ref.rng, gpu.rng = np.random.default_rng(seed), np.random.default_rng(seed)
    ok = True
    for i in range(2):
        a_r, a_g = ref.plan(q0, qd0, 0.5)["a"], gpu.plan(q0, qd0, 0.5)["a"]
        du, da = np.max(np.abs(gpu.U - ref.U)), np.max(np.abs(a_g - a_r))
        K0 = task.kin(q0[None], qd0[None])
        C, d = task.extra_rows(K0, q0[None], qd0[None])
        viol = float(np.max(C[0] @ a_g - d[0]))
        print(f"raw average, plan {i + 1}: executed |da| = {da:.2e} (|a| = {np.max(np.abs(a_r)):.2f}), nominal |dU| = {du:.2e}, "
              f"largest tightened support row of the GPU command {viol:+.2e} (<= 0 admissible)")
        ok = ok and da / (np.max(np.abs(a_r)) + 1e-12) < 1e-3 and viol < 1e-4
    return ok


if __name__ == "__main__":
    main()
