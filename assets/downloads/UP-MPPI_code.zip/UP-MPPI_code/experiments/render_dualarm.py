"""Record and render the dual-arm videos: 2x2 grid, internal force drawn as an arrow at each grasp."""
import sys
from multiprocessing import Pool
from pathlib import Path

import imageio_ffmpeg
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiments.dualarm_exp as X  # noqa: E402
from umppi import dualarm as DA  # noqa: E402
from umppi.dualtask import configurations  # noqa: E402
from umppi.mjcf import scene_xml  # noqa: E402
from umppi.physics_dual import tray_xml  # noqa: E402

VID = Path(__file__).resolve().parent / "results" / "videos"
SCEN = [  # tag, controller, delta_b_mm, title
    ("dual_pr", "PR", 2.0, "PR-MPPI | right-base calibration error 2 mm"),
    ("dual_anchor", "PR-anchored", 2.0, "PR-MPPI anchored (Prop. 7) | error 2 mm"),
    ("dual_noineq", "PR-noineq", 0.0, "PR-MPPI without inequality projection | joint-4 bound"),
    ("dual_unified", "Unified", 2.0, "Unified (ours) | error 2 mm, reaction box 5 N"),
]
FPS, STEP = 25, 2  # control period 20 ms, one frame every 2 steps
Wd, Hd = 640, 480
FONT, FONTB = "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"
SKY = '<texture type="skybox" builtin="gradient" rgb1="0.93 0.94 0.96" rgb2="0.62 0.66 0.72" width="256" height="256"/>'


def record(sc):
    tag, name, dl, title = sc
    rec = {}
    r, _ = X.run(name, dl, rec=rec)
    VID.mkdir(parents=True, exist_ok=True)
    np.savez(VID / f"{tag}.npz", qpos=np.array(rec["qpos"]), W_int=np.array(rec["W_int"]), title=title,
             q4_min=r["q4_min"], diverged_t=-1.0 if r["diverged_t"] is None else r["diverged_t"])
    return tag, r["W_int_norm_mean"], r["bound_viol"]


def arrow(scene, p_from, p_to, rgba, width=0.012):
    if scene.ngeom >= scene.maxgeom or np.linalg.norm(p_to - p_from) < 1e-4:
        return
    g = scene.geoms[scene.ngeom]
    mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_ARROW, np.zeros(3), np.zeros(3), np.eye(3).reshape(9),
                        np.asarray(rgba, np.float32))
    mujoco.mjv_connector(g, mujoco.mjtGeom.mjGEOM_ARROW, width, np.asarray(p_from, float), np.asarray(p_to, float))
    scene.ngeom += 1


class Cell:
    def __init__(self, tag, model):
        z = np.load(VID / f"{tag}.npz")
        self.qpos, self.W, self.title = z["qpos"], z["W_int"], str(z["title"])
        self.q4_min, self.div = float(z["q4_min"]), float(z["diverged_t"])
        self.m, self.d = model, mujoco.MjData(model)
        self.r = mujoco.Renderer(model, Hd, Wd, max_geom=4000)
        self.cam = mujoco.MjvCamera()
        self.cam.type = mujoco.mjtCamera.mjCAMERA_FREE
        self.cam.lookat[:] = (0.50, 0.0, 0.32)
        self.cam.distance, self.cam.azimuth, self.cam.elevation = 1.15, 205.0, -20.0
        self.sid = [mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, f"{s}tool") for s in ("l_", "r_")]
        self.ft = ImageFont.truetype(FONTB, 16)
        self.fx = ImageFont.truetype(FONT, 16)
        self.fb = ImageFont.truetype(FONTB, 28)

    def render(self, k):
        kk = min(k, len(self.qpos) - 1)
        self.d.qpos[:] = self.qpos[kk]
        mujoco.mj_forward(self.m, self.d)
        self.r.update_scene(self.d, camera=self.cam)
        f = self.W[kk][:3]
        s = 0.02  # m per N
        for sid, sign in zip(self.sid, (1.0, -1.0)):  # internal force: +W_int on the left grasp, - on the right
            p = self.d.site_xpos[sid]
            arrow(self.r.scene, p, p + sign * s * f, (0.9, 0.12, 0.1, 1.0))
        img = Image.fromarray(self.r.render())
        dr = ImageDraw.Draw(img)
        dr.rectangle([0, 0, Wd, 28], fill=(250, 250, 250))
        dr.text((10, 5), self.title, font=self.ft, fill=(15, 15, 15))
        t = (kk + 1) * X.DT
        q4 = min(self.qpos[kk][3], self.qpos[kk][10])
        viol = q4 < self.q4_min
        dr.text((10, Hd - 50), f"t = {t:4.2f} s    internal force {np.linalg.norm(f):5.2f} N", font=self.fx, fill=(15, 15, 15))
        dr.text((10, Hd - 27), f"joint 4 - bound = {q4 - self.q4_min:+.3f} rad", font=self.fx,
                fill=(200, 30, 25) if viol else (20, 110, 40))
        if viol:
            dr.text((300, Hd - 27), "BOUND VIOLATED", font=self.fx, fill=(200, 30, 25))
        if self.div > 0 and t >= self.div:
            dr.rectangle([10, 38, 330, 76], fill=(255, 255, 255))
            dr.text((20, 42), f"DIVERGED at {self.div:.2f} s", font=self.fb, fill=(210, 30, 25))
        return np.asarray(img)


def main():
    import warnings
    warnings.filterwarnings("ignore")
    if "--render-only" not in sys.argv:
        with Pool(len(SCEN)) as p:
            for tag, w, bv in p.imap_unordered(record, SCEN):
                print(tag, f"mean internal force {w:.2f} N, bound violation {bv:.3f} rad", flush=True)
    arms = DA.make_arms()
    q_start, _ = configurations(arms)
    K = DA.kin_pair(arms, q_start[None], np.zeros((1, 14)))
    p_tray = 0.5 * (K[0]["p"][0] + K[1]["p"][0])
    model = mujoco.MjModel.from_xml_string(scene_xml([(arms[0], "l_"), (arms[1], "r_")],
                                                     extra_world=tray_xml(p_tray), extra_asset=SKY))
    cells = [Cell(tag, model) for tag, *_ in SCEN]
    n = int(round(X.T_RUN / X.DT)) // STEP
    g = imageio_ffmpeg.write_frames(str(VID / "dualarm_grid.mp4"), (2 * Wd, 2 * Hd), fps=FPS, codec="libx264",
                                    quality=8, pix_fmt_out="yuv420p", macro_block_size=16)
    g.send(None)
    for fi in range(n):
        k = fi * STEP + STEP - 1
        fr = [c.render(k) for c in cells]
        if fi == n // 2:
            Image.fromarray(np.concatenate([np.concatenate(fr[:2], 1), np.concatenate(fr[2:], 1)], 0)).save(
                VID / "dual_frame_mid.png")
        g.send(np.ascontiguousarray(np.concatenate([np.concatenate(fr[:2], 1), np.concatenate(fr[2:], 1)], 0)))
    g.close()
    print("wrote", VID / "dualarm_grid.mp4")


if __name__ == "__main__":
    main()
