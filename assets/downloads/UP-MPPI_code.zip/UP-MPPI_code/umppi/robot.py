"""Batched kinematics and dynamics of a Franka-like 7-DoF arm (numpy, float64).

Geometry: Franka Emika modified (Craig) DH parameters, joint limits from the datasheet.
Inertia: masses and centres of mass after Gaz et al. (RA-L 2019); diagonal inertia terms
only, plus 0.1 kg m^2 armature per joint (as in common MuJoCo models).  The controller
model and the MuJoCo physics are generated from the same parameters, so any mismatch is
deliberate (see Chain.perturbed).

All functions take q, qd of shape (B, n) and return batched arrays.
"""
from dataclasses import dataclass, field, replace

import numpy as np

# (a_{i-1}, d_i, alpha_{i-1}) per joint, Craig convention; flange d = 0.107
DH = np.array([
    [0.0, 0.333, 0.0],
    [0.0, 0.0, -np.pi / 2],
    [0.0, 0.316, np.pi / 2],
    [0.0825, 0.0, np.pi / 2],
    [-0.0825, 0.384, -np.pi / 2],
    [0.0, 0.0, np.pi / 2],
    [0.088, 0.0, np.pi / 2],
])
Q_MIN = np.array([-2.8973, -1.7628, -2.8973, -3.0718, -2.8973, -0.0175, -2.8973])
Q_MAX = np.array([2.8973, 1.7628, 2.8973, -0.0698, 2.8973, 3.7525, 2.8973])
QD_MAX = np.array([2.175, 2.175, 2.175, 2.175, 2.61, 2.61, 2.61])
TAU_MAX = np.array([87.0, 87.0, 87.0, 87.0, 12.0, 12.0, 12.0])
MASS = np.array([4.970684, 0.646926, 3.228604, 3.587895, 1.225946, 1.666555, 0.735522])
COM = np.array([
    [3.875e-03, 2.081e-03, -4.762e-02],
    [-3.141e-03, -2.872e-02, 3.495e-03],
    [2.7518e-02, 3.9252e-02, -6.6502e-02],
    [-5.317e-02, 1.04419e-01, 2.7454e-02],
    [-1.1953e-02, 4.1065e-02, -3.8437e-02],
    [6.0149e-02, -1.4117e-02, -1.0517e-02],
    [1.0517e-02, -4.252e-03, 6.1597e-02],
])
INERTIA_DIAG = np.array([
    [0.70337, 0.70661, 0.0091170],
    [0.0079620, 0.028110, 0.025995],
    [0.037242, 0.036155, 0.010830],
    [0.025853, 0.019552, 0.028323],
    [0.035549, 0.029474, 0.0086270],
    [0.0019640, 0.0043540, 0.0054330],
    [0.012516, 0.010027, 0.0048150],
])
GRAVITY = np.array([0.0, 0.0, -9.81])


def rotx(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


def cross(a, b):
    """Component-wise cross product on the last axis (much faster than np.cross for small arrays)."""
    a0, a1, a2 = a[..., 0], a[..., 1], a[..., 2]
    b0, b1, b2 = b[..., 0], b[..., 1], b[..., 2]
    return np.stack([a1 * b2 - a2 * b1, a2 * b0 - a0 * b2, a0 * b1 - a1 * b0], -1)


def mv(A, v):
    """Batched matrix-vector product (..., m, n) x (..., n) -> (..., m)."""
    return (A @ v[..., None])[..., 0]


def skew(v):
    """(..., 3) -> (..., 3, 3)."""
    z = np.zeros(v.shape[:-1])
    return np.stack([np.stack([z, -v[..., 2], v[..., 1]], -1),
                     np.stack([v[..., 2], z, -v[..., 0]], -1),
                     np.stack([-v[..., 1], v[..., 0], z], -1)], -2)


@dataclass
class Chain:
    tool: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 0.107 + 0.10]))  # pen tip in link-7 frame
    tool_mass: float = 0.5  # pen holder lumped into link 7 at the tool midpoint
    base_pos: np.ndarray = field(default_factory=lambda: np.zeros(3))
    base_rot: np.ndarray = field(default_factory=lambda: np.eye(3))
    armature: np.ndarray = field(default_factory=lambda: np.full(7, 0.1))
    mass: np.ndarray = field(default_factory=lambda: MASS.copy())
    com: np.ndarray = field(default_factory=lambda: COM.copy())
    inertia: np.ndarray = field(default_factory=lambda: INERTIA_DIAG.copy())
    n: int = 7

    def __post_init__(self):
        # fixed part of each joint transform:  R_{i-1,i}(q) = Rx(alpha) Rz(q),  p_i = Rx(alpha) (a, 0, d)
        self.Rx = np.stack([rotx(al) for al in DH[:, 2]])
        self.p = np.stack([rotx(al) @ np.array([a, 0.0, d]) for a, d, al in DH])
        # lump the tool mass into link 7
        m7, c7 = self.mass[6], self.com[6]
        ct = 0.5 * self.tool
        mt = self.tool_mass
        self.mass = self.mass.copy()
        self.com = self.com.copy()
        self.mass[6] = m7 + mt
        self.com[6] = (m7 * c7 + mt * ct) / (m7 + mt)
        self.I = np.stack([np.diag(v) for v in self.inertia])
        # parallel-axis shift of the two point masses to the new COM (tool as a point mass)
        d7, dt = c7 - self.com[6], ct - self.com[6]
        self.I[6] = self.I[6] + m7 * (d7 @ d7 * np.eye(3) - np.outer(d7, d7)) + mt * (dt @ dt * np.eye(3) - np.outer(dt, dt))
        self.LcT = np.stack([np.linalg.cholesky(Ii).T for Ii in self.I])  # I_i = Lc Lc^T
        self.sqrt_m = np.sqrt(self.mass)
        self.tri = np.tril(np.ones((self.n, self.n)))

    def perturbed(self, mass_scale=1.0):
        """Model with scaled link masses and inertias (controller-side model error)."""
        c = replace(self, mass=MASS * mass_scale, inertia=INERTIA_DIAG * mass_scale,
                    tool_mass=self.tool_mass * mass_scale)
        return c

    # ------------------------------------------------------------------ kinematics
    def joint_rot(self, q):
        """(B, n, 3, 3) rotation of frame i relative to frame i-1."""
        c, s = np.cos(q), np.sin(q)
        z, o = np.zeros_like(q), np.ones_like(q)
        Rz = np.stack([np.stack([c, -s, z], -1), np.stack([s, c, z], -1), np.stack([z, z, o], -1)], -2)
        return np.einsum("iab,kibc->kiac", self.Rx, Rz)

    def fk(self, q):
        """World rotations R (B, n, 3, 3) and origins o (B, n, 3) of the joint frames."""
        B = q.shape[0]
        Rrel = self.joint_rot(q)
        R = np.empty((B, self.n, 3, 3))
        o = np.empty((B, self.n, 3))
        Rc = np.broadcast_to(self.base_rot, (B, 3, 3))
        oc = np.broadcast_to(self.base_pos, (B, 3))
        for i in range(self.n):
            oc = oc + Rc @ self.p[i]
            Rc = Rc @ Rrel[:, i]
            R[:, i], o[:, i] = Rc, oc
        return R, o

    def tool_pose(self, q):
        R, o = self.fk(q)
        return R[:, -1], o[:, -1] + R[:, -1] @ self.tool

    def jacobian(self, q, local_point=None, link=None, R=None, o=None):
        """Geometric Jacobian (Jv, Jw), each (B, 3, n), of a point fixed in a link frame."""
        if R is None:
            R, o = self.fk(q)
        link = self.n - 1 if link is None else link
        lp = self.tool if local_point is None else local_point
        pt = o[:, link] + R[:, link] @ lp
        z = R[:, :, :, 2]  # (B, n, 3)
        Jv = cross(z, pt[:, None, :] - o)  # (B, n, 3)
        Jw = z.copy()
        mask = (np.arange(self.n) > link)
        Jv[:, mask] = 0.0
        Jw[:, mask] = 0.0
        return np.swapaxes(Jv, 1, 2), np.swapaxes(Jw, 1, 2), pt

    # ------------------------------------------------------------------ dynamics
    def mass_matrix(self, q, R=None, o=None):
        """M(q) = sum_i m_i Jci^T Jci + Jwi^T R_i I_i R_i^T Jwi + diag(armature), as A^T A + C^T C."""
        if R is None:
            R, o = self.fk(q)
        B, n = q.shape
        z = R[:, :, :, 2]
        pc = o + mv(R, np.broadcast_to(self.com, (B, n, 3)))  # (B, n, 3) COM of each link
        diff = pc[:, :, None, :] - o[:, None, :, :]  # (B, i, j, 3)
        Jc = cross(np.broadcast_to(z[:, None], diff.shape), diff) * self.tri[None, :, :, None]
        A = (self.sqrt_m[None, :, None, None] * np.swapaxes(Jc, 2, 3)).reshape(B, 3 * n, n)
        zb = np.swapaxes(R, 2, 3) @ np.swapaxes(z, 1, 2)[:, None]  # (B, i, 3, j) = R_i^T z_j
        C = (self.LcT[None] @ zb) * self.tri[None, :, None, :]
        C = C.reshape(B, 3 * n, n)
        return np.swapaxes(A, 1, 2) @ A + np.swapaxes(C, 1, 2) @ C + np.diag(self.armature)

    def rnea(self, q, qd, qdd, gravity=True):
        """Recursive Newton-Euler inverse dynamics, tau (B, n), armature included."""
        B = q.shape[0]
        Rrel = self.joint_rot(q)
        zax = np.array([0.0, 0.0, 1.0])
        w = np.zeros((B, 3))
        wd = np.zeros((B, 3))
        vd = np.broadcast_to(-self.base_rot.T @ GRAVITY if gravity else np.zeros(3), (B, 3)).copy()
        Fs, Ns = [], []
        for i in range(self.n):
            RT = np.swapaxes(Rrel[:, i], 1, 2)
            pi = self.p[i]
            vd = np.einsum("kab,kb->ka", RT, np.cross(wd, pi) + np.cross(w, np.cross(w, pi)) + vd)
            wp = np.einsum("kab,kb->ka", RT, w)
            w_new = wp + qd[:, i:i + 1] * zax
            wd = np.einsum("kab,kb->ka", RT, wd) + np.cross(wp, qd[:, i:i + 1] * zax) + qdd[:, i:i + 1] * zax
            w = w_new
            c = self.com[i]
            vdc = vd + np.cross(wd, c) + np.cross(w, np.cross(w, c))
            Fs.append(self.mass[i] * vdc)
            Iw = w @ self.I[i].T
            Ns.append(wd @ self.I[i].T + np.cross(w, Iw))
        tau = np.empty((B, self.n))
        f = np.zeros((B, 3))
        nn = np.zeros((B, 3))
        for i in range(self.n - 1, -1, -1):
            if i < self.n - 1:
                Rn = Rrel[:, i + 1]
                fc = np.einsum("kab,kb->ka", Rn, f)
                nc = np.einsum("kab,kb->ka", Rn, nn) + np.cross(self.p[i + 1], fc)
            else:
                fc = np.zeros((B, 3))
                nc = np.zeros((B, 3))
            f = Fs[i] + fc
            nn = Ns[i] + nc + np.cross(self.com[i], Fs[i])
            tau[:, i] = nn[:, 2] + self.armature[i] * qdd[:, i]
        return tau

    def bias(self, q, qd):
        return self.rnea(q, qd, np.zeros_like(q), gravity=True)

    def point_acc_bias(self, q, qd, local_point=None, link=None):
        """Jdot qd of a link point (linear, angular), world frame, from a qdd = 0 forward pass."""
        B = q.shape[0]
        link = self.n - 1 if link is None else link
        lp = self.tool if local_point is None else local_point
        Rrel = self.joint_rot(q)
        zax = np.array([0.0, 0.0, 1.0])
        w = np.zeros((B, 3))
        wd = np.zeros((B, 3))
        vd = np.zeros((B, 3))
        Rw = np.broadcast_to(self.base_rot, (B, 3, 3))
        for i in range(link + 1):
            RT = np.swapaxes(Rrel[:, i], 1, 2)
            pi = np.broadcast_to(self.p[i], (B, 3))
            vd = mv(RT, cross(wd, pi) + cross(w, cross(w, pi)) + vd)
            wp = mv(RT, w)
            w_new = wp + qd[:, i:i + 1] * zax
            wd = mv(RT, wd) + cross(wp, qd[:, i:i + 1] * zax)
            w = w_new
            Rw = Rw @ Rrel[:, i]
        lpb = np.broadcast_to(lp, (B, 3))
        a_pt = vd + cross(wd, lpb) + cross(w, cross(w, lpb))  # link frame
        return mv(Rw, a_pt), mv(Rw, wd)
