"""Dual-arm closed chain holding a tray (PR-MPPI Sec. III, Eq. 17), batched model-side quantities.

Two Franka-like arms side by side, both tools pointing down, rigidly grasping the ends of a tray.
  physical rows (6)  relative pose of the right tool w.r.t. the left tool + grasp transform
                     e_p = p_r - (p_l + R_l lp)   e_R = log(R_r (R_l lR)^T)
  virtual rows  (2)  tray level: n_o . e_x = n_o . e_y = 0, n_o = tray normal = -z of the left tool
The controller's model of the right-arm base may carry a calibration offset.
"""
import numpy as np

from .robot import Chain, cross, mv

BASE_Y = 0.35  # arm bases at y = +-BASE_Y
GRIP_Y = 0.15  # grasp points at y = +-GRIP_Y relative to the tray centre
EX, EY, EZ = np.eye(3)


def make_arms(right_base_offset=np.zeros(3)):
    left = Chain(base_pos=np.array([0.0, BASE_Y, 0.0]), tool=np.array([0.0, 0.0, 0.107 + 0.05]), tool_mass=0.3)
    right = Chain(base_pos=np.array([0.0, -BASE_Y, 0.0]) + right_base_offset,
                  tool=np.array([0.0, 0.0, 0.107 + 0.05]), tool_mass=0.3)
    return left, right


def so3_log(R):
    """Rotation vector of a batch of rotations (B,3,3)."""
    tr = np.clip((np.trace(R, axis1=1, axis2=2) - 1) / 2, -1.0, 1.0)
    th = np.arccos(tr)
    v = np.stack([R[:, 2, 1] - R[:, 1, 2], R[:, 0, 2] - R[:, 2, 0], R[:, 1, 0] - R[:, 0, 1]], 1)
    s = np.where(th < 1e-8, 0.5, th / (2 * np.sin(np.maximum(th, 1e-12))))
    return v * s[:, None]


def kin_pair(arms, q, qd):
    """Tool kinematics of both arms for q = [q_l, q_r] (B,14)."""
    out = []
    for arm, qi, qdi in ((arms[0], q[:, :7], qd[:, :7]), (arms[1], q[:, 7:], qd[:, 7:])):
        R, o = arm.fk(qi)
        Jv, Jw, p = arm.jacobian(qi, R=R, o=o)
        acc_v, acc_w = arm.point_acc_bias(qi, qdi)
        out.append(dict(R=R, o=o, Rt=R[:, -1], p=p, Jv=Jv, Jw=Jw, v=mv(Jv, qdi), w=mv(Jw, qdi), jdv=acc_v, jdw=acc_w))
    return out


def chain_rows(K, grasp):
    """Physical rows: c (B,6), J (B,6,14), Jdot qd (B,6).  grasp = (lp, lR): right tool in left tool frame."""
    L, Rr = K
    lp, lR = grasp
    B = L["p"].shape[0]
    r = mv(L["Rt"], np.broadcast_to(lp, (B, 3)))  # world lever arm from the left tool to the right grasp
    e_p = Rr["p"] - (L["p"] + r)
    e_R = so3_log(Rr["Rt"] @ np.swapaxes(L["Rt"] @ lR, 1, 2))
    c = np.concatenate([e_R, e_p], 1)
    # d e_p/dt = v_r - v_l - w_l x r ;  d e_R/dt = w_r - w_l  (exact at e_R = 0, used for GN and Gauss)
    rx = np.zeros((B, 3, 3))
    rx[:, 0, 1], rx[:, 0, 2], rx[:, 1, 0] = -r[:, 2], r[:, 1], r[:, 2]
    rx[:, 1, 2], rx[:, 2, 0], rx[:, 2, 1] = -r[:, 0], -r[:, 1], r[:, 0]
    J = np.zeros((B, 6, 14))
    J[:, :3, :7], J[:, :3, 7:] = -L["Jw"], Rr["Jw"]
    J[:, 3:, :7] = -L["Jv"] + rx @ L["Jw"]  # -w_l x r = r x w_l
    J[:, 3:, 7:] = Rr["Jv"]
    # Jdot qd: second derivatives with qdd = 0
    wl = L["w"]
    rdot = cross(wl, r)
    jd_R = Rr["jdw"] - L["jdw"]
    jd_p = Rr["jdv"] - L["jdv"] - cross(L["jdw"], r) - cross(wl, rdot)
    return c, J, np.concatenate([jd_R, jd_p], 1)


def tilt_rows(K, lRo_z=np.array([0.0, 0.0, -1.0])):
    """Virtual rows: tray normal n_o = R_l lRo_z kept vertical.  e (B,2), J (B,2,14), Jdot qd (B,2)."""
    L = K[0]
    B = L["p"].shape[0]
    n = mv(L["Rt"], np.broadcast_to(lRo_z, (B, 3)))
    e = np.stack([n[:, 0], n[:, 1]], 1)
    ax, ay = cross(n, np.broadcast_to(EX, (B, 3))), cross(n, np.broadcast_to(EY, (B, 3)))
    J = np.zeros((B, 2, 14))
    J[:, 0, :7] = np.einsum("bi,bij->bj", ax, L["Jw"])
    J[:, 1, :7] = np.einsum("bi,bij->bj", ay, L["Jw"])
    w = L["w"]
    nd = cross(w, n)
    jd = np.stack([np.sum(cross(nd, np.broadcast_to(EX, (B, 3))) * w, 1) + np.sum(ax * L["jdw"], 1),
                   np.sum(cross(nd, np.broadcast_to(EY, (B, 3))) * w, 1) + np.sum(ay * L["jdw"], 1)], 1)
    return e, J, jd


def ik_pair(arms, p_tray, q_init, iters=300):
    """Both tools at the tray ends (y = +-GRIP_Y), pointing straight down; returns q (14,)."""
    q = q_init.copy()[None]
    targets = [p_tray + np.array([0.0, GRIP_Y, 0.0]), p_tray - np.array([0.0, GRIP_Y, 0.0])]
    down = np.array([0.0, 0.0, -1.0])
    for _ in range(iters):
        K = kin_pair(arms, q, np.zeros_like(q))
        dq = np.zeros(14)
        err_n = 0.0
        for i, (Ki, tgt) in enumerate(zip(K, targets)):
            z = Ki["Rt"][0][:, 2]
            x = Ki["Rt"][0][:, 0]
            err = np.concatenate([Ki["p"][0] - tgt, z - down, [x[1]]])  # also fix the yaw: tool x along world x
            Jz = -np.cross(z[None, :].repeat(7, 0), Ki["Jw"][0].T).T
            Jx = -np.cross(x[None, :].repeat(7, 0), Ki["Jw"][0].T).T
            J = np.concatenate([Ki["Jv"][0], Jz, Jx[1:2]], 0)
            dq[7 * i:7 * i + 7] = -J.T @ np.linalg.solve(J @ J.T + 1e-6 * np.eye(7), err)
            err_n = max(err_n, np.linalg.norm(err))
        q = q + dq[None]
        if err_n < 1e-12:
            break
    return q[0]


def grasp_from(arms, q):
    """Relative pose (lp, lR) of the right tool in the left tool frame at configuration q (14,)."""
    K = kin_pair(arms, q[None], np.zeros((1, 14)))
    Rl, pl, Rr, pr = K[0]["Rt"][0], K[0]["p"][0], K[1]["Rt"][0], K[1]["p"][0]
    return Rl.T @ (pr - pl), Rl.T @ Rr
