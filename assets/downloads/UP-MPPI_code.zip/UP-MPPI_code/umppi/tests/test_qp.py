"""Batched projector == exact per-sample solver, incl. equalities and dependent rows."""
import numpy as np

from umppi.qp import _ldp_single, project


def main():
    rng = np.random.default_rng(1)
    B, n, ne, m = 300, 7, 3, 16
    Q = rng.standard_normal((B, n, n))
    W = Q @ np.swapaxes(Q, 1, 2) + 0.1 * np.eye(n)
    E = rng.standard_normal((B, ne, n))
    uf = rng.standard_normal((B, n))
    e = np.einsum("bij,bj->bi", E, uf)
    A = rng.standard_normal((B, m, n))
    A[:, 1] = -A[:, 0]  # dependent pair (like lower/upper limits of one joint)
    d = np.einsum("bij,bj->bi", A, uf) + rng.uniform(0.0, 0.5, (B, m))
    x = uf + 2.0 * rng.standard_normal((B, n))
    u, info = project(x, W, E, e, A, d, return_info=True)
    err = max(np.linalg.norm(u[b] - _ldp_single(x[b], W[b], E[b], e[b], A[b], d[b], 1e-9)) for b in range(B))
    feas = np.max(np.einsum("bij,bj->bi", A, u) - d)
    eq = np.max(np.abs(np.einsum("bij,bj->bi", E, u) - e))
    ok = err < 1e-8 and feas < 1e-8 and eq < 1e-10
    print(f"  max |u - exact| {err:.1e}, max row violation {feas:.1e}, max eq residual {eq:.1e}, "
          f"fallbacks {info['fallback']}/{B}, active-set sizes {np.bincount(info['active'])}")
    print("PASS" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    main()
