"""Fill tier2/writing_section.tex from results/writing.json and writing_summary.json."""
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
DELTAS = [-1.0, -0.5, 0.0, 0.5, 1.0]
LABEL = {
    "PR": "PR-MPPI", "PR-anchored": "PR-MPPI anchored", "CAMP": "CAMP-MPPI (cost)",
    "CAMP-manifold": "CAMP-MPPI (manifold)", "Unified": "Unified", "Unified-joint": "Unified-joint",
    "Unified-W=I": "Unified $W=I$",
}


def sci(x):
    """LaTeX scientific notation, e.g. 4.4e-16 -> $4.4\\times10^{-16}$."""
    m, e = f"{x:.1e}".split("e")
    return f"${m}\\times10^{{{int(e)}}}$"


def weight_sentence():
    """Sensitivity of the orientation-as-cost baseline (camp_weight_check.py, seed 0)."""
    p = HERE / "results/camp_weight_check.json"
    if not p.exists():
        return ""
    W = {r["w_o"]: r for r in json.loads(p.read_text())}
    a, b, c = W[5e3], W[5e4], W[5e5]
    return (f"Its tilt depends on the weight: for seed~0 it was {a['ori_rms_deg']:.2f}, {b['ori_rms_deg']:.2f} and "
            f"{c['ori_rms_deg']:.2f}\\,deg at $w_o=5\\times10^3$, $5\\times10^4$ and $5\\times10^5$, with tracking errors of "
            f"{a['track_rmse_mm']:.1f}, {b['track_rmse_mm']:.1f} and {c['track_rmse_mm']:.1f}\\,mm.")


def main():
    D = json.loads((HERE / "results/writing.json").read_text())
    S = json.loads((HERE / "results/writing_summary.json").read_text())
    rows = [r for r in D["rows"] if "error" not in r]
    g = defaultdict(list)
    for r in rows:
        g[(r["controller"], r["delta_mm"])].append(r)

    def done(rs):
        return [r for r in rs if r.get("diverged_t") is None]

    def mean(nm, dl, key, scale=1.0):
        rs = done(g[(nm, dl)])
        return np.mean([r[key] for r in rs]) * scale if rs else np.nan

    gain = S["pred_gain_N_per_mm"]
    force_rows = ["Prop.~\\ref{prop:physvirt}(b), PR-MPPI & " + " & ".join(
        f"{gain * -dl:.2f}" if dl < 0 else "0 (lift-off)" for dl in DELTAS) + " \\\\"]
    for nm in ["PR", "PR-anchored", "CAMP", "Unified", "Unified-W=I"]:
        force_rows.append(LABEL[nm] + " & " + " & ".join(f"{mean(nm, dl, 'force_mean'):.2f}" for dl in DELTAS) + " \\\\")

    perf_rows = []
    for nm in ["PR", "PR-anchored", "CAMP", "CAMP-manifold", "Unified", "Unified-joint", "Unified-W=I"]:
        rs = g[(nm, 0.0)]
        div = [r["diverged_t"] for r in rs if r.get("diverged_t") is not None]
        outcome = f"{len(rs) - len(div)}/{len(rs)}" + (f" ({np.mean(div):.1f}\\,s)" if div else "")
        def m(key, scale=1.0, fmt="{:.1f}"):
            v = [r[key] * scale for r in rs]
            return fmt.format(np.mean(v))
        perf_rows.append(f"{LABEL[nm]} & {m('in_band', 100)} & {m('contact', 100)} & {m('track_rmse_mm', 1, '{:.2f}')} & "
                         f"{m('ori_rms_deg', 1, '{:.2f}')} & {outcome} \\\\")

    pr_m1, pr_m05 = mean("PR", -1.0, "force_mean"), mean("PR", -0.5, "force_mean")
    uni = {k: mean("Unified", 0.0, k) for k in ("in_band", "track_rmse_mm", "ori_rms_deg", "force_mean", "force_std")}
    wi = {k: mean("Unified-W=I", 0.0, k) for k in ("in_band", "track_rmse_mm", "force_std")}
    # the same pair with the average of the projected samples (before Algorithm 1 averaged raw inputs)
    old_rows = json.loads((HERE / "results/v4_projected/writing.json").read_text())["rows"]
    OLD = {c: float(np.mean([r["in_band"] for r in old_rows if r["controller"] == c and r["delta_mm"] == 0.0 and "error" not in r]))
           for c in ("Unified", "Unified-W=I")}
    camp = {k: mean("CAMP", 0.0, k) for k in ("ori_rms_deg", "track_rmse_mm", "in_band")}
    cm = g[("CAMP-manifold", 0.0)]
    cm_div = [r["diverged_t"] for r in cm if r.get("diverged_t") is not None]
    cm_done = [r for r in cm if r.get("diverged_t") is None]
    cm_done_band = np.mean([r["in_band"] for r in cm_done]) if cm_done else float("nan")
    cm_done_tilt = np.mean([r["ori_rms_deg"] for r in cm_done]) if cm_done else float("nan")
    order2 = ["CAMP", "Unified", "Unified-joint", "Unified-W=I"]
    spread = max(np.ptp([mean(nm, dl, "force_mean") for dl in DELTAS]) for nm in order2)
    lam_ranges = [r["lam_cmd_range"] for r in rows if r["controller"] == "Unified" and r.get("lam_cmd_range")]
    lam_lo, lam_hi = min(x[0] for x in lam_ranges), max(x[1] for x in lam_ranges)
    relaxed = sum(r.get("relaxed", 0) for r in rows if r["controller"] == "Unified")
    # W = I against the inertia metric, seed by seed at delta = 0
    by_seed = {nm: {r["seed"]: r["in_band"] for r in g[(nm, 0.0)]} for nm in ("Unified", "Unified-W=I")}
    seeds = sorted(set(by_seed["Unified"]) & set(by_seed["Unified-W=I"]))
    n_lower = sum(by_seed["Unified-W=I"][s_] < by_seed["Unified"][s_] for s_ in seeds)
    verb = "lowered" if wi["in_band"] < uni["in_band"] else "changed"
    seed_txt = "in every seed" if n_lower == len(seeds) else f"in {n_lower} of {len(seeds)} seeds"
    findings = [
        "\\begin{enumerate}",
        f"\\item Proposition~\\ref{{prop:physvirt}}(b) predicts the force of PR-MPPI.",
        f"It pressed with {pr_m1:.2f}\\,N at $\\delta=-1$\\,mm and {pr_m05:.2f}\\,N at $-0.5$\\,mm, against the predicted {gain:.2f} and {gain / 2:.2f}\\,N, and it lost contact for $\\delta\\ge0$.",
        "The prediction uses the period-averaged stiffness $K_{\\mathrm{eff}}=M(\\omega^2/2+2\\omega/\\Delta t)$ of the interpolated computed-torque loop; the proportional stiffness $M\\omega^2$ alone underestimates the slope by a factor of 1.5.",
        "\\item Anchoring (Proposition~\\ref{prop:anchor}) removed the offset-driven force for every $\\delta$, and with it every contact: the anchored order-1 controller has no force feedback and cannot write.",
        f"\\item The order-2 controllers are offset invariant, as Proposition~\\ref{{prop:physvirt}}(a) states: their mean force varies by at most {sci(spread)}\\,N across the five offsets.",
        f"\\item The separable and joint solvers produced identical force traces (largest difference {sci(S['separable_vs_joint_max_force_diff'])}\\,N), as Theorem~\\ref{{thm:sep}}(iii) requires.",
        (f"Replacing the inertia metric by $W=I$ {verb} the in-band fraction from {100 * uni['in_band']:.1f}\\% to {100 * wi['in_band']:.1f}\\% (lower {seed_txt}), a small effect on this task because the band and the motion rows are rarely active together."
         if uni["in_band"] - wi["in_band"] < 0.1 else
         f"Replacing the inertia metric by $W=I$ {verb} the in-band fraction from {100 * uni['in_band']:.1f}\\% to {100 * wi['in_band']:.1f}\\% (lower {seed_txt}), with a force standard deviation of {wi['force_std']:.1f}\\,N against {uni['force_std']:.2f}\\,N.\n"
         f"Without separation, the projection of the raw average corrects the reaction partly through the tangential motion, so the exploration noise along the contact normal (remark after Proposition~\\ref{{prop:avg}}) reaches the pen; with the average of the projected samples the same change of metric cost only {100 * (OLD['Unified'] - OLD['Unified-W=I']):.1f} points ({100 * OLD['Unified']:.1f} to {100 * OLD['Unified-W=I']:.1f}\\%).\n"
         f"The averaging of Algorithm~\\ref{{alg:unified}} relies on the inertia metric."),
        (f"\\item Treating the virtual orientation as physical failed as Proposition~\\ref{{prop:physvirt}} predicts: CAMP-MPPI with the orientation in its manifold diverged in {len(cm_div)} of {len(cm)} runs, at {np.mean(cm_div) if cm_div else float('nan'):.1f}\\,s on average, and the remaining run held the band only {100 * cm_done_band:.0f}\\% of the time with a tilt of {cm_done_tilt:.0f}\\,deg."
         if cm_done else
         f"\\item Treating the virtual orientation as physical failed as Proposition~\\ref{{prop:physvirt}} predicts: CAMP-MPPI with the orientation in its manifold diverged in all {len(cm)} runs, at {np.mean(cm_div):.1f}\\,s on average, and until then it held the band only {100 * np.mean([r['in_band'] for r in cm]):.0f}\\% of the time with a tilt of {np.mean([r['ori_rms_deg'] for r in cm]):.0f}\\,deg."),
        f"Keeping the orientation as a cost worked once the null space was damped, with a tilt of {camp['ori_rms_deg']:.1f}\\,deg (RMS over seeds) against {uni['ori_rms_deg']:.2f}\\,deg for the virtual rows of the unified controller.",
        weight_sentence(),
        "The virtual rows need no weight.",
        f"\\item Every executed reaction of the unified controller stayed in the band (commanded range {lam_lo:.2f}--{lam_hi:.2f}\\,N), as Theorem~\\ref{{thm:main}}(i) states; the priority fallback of Proposition~\\ref{{prop:priority}} was needed in {relaxed} of its projections.",
        "\\end{enumerate}",
    ]
    tpl = (HERE / "writing_section.tex.in").read_text(encoding="utf-8")
    out = tpl.replace("@@FORCE_ROWS@@", "\n".join(force_rows)).replace("@@PERF_ROWS@@", "\n".join(perf_rows))
    out = out.replace("@@FINDINGS@@", "\n".join(findings))
    (HERE.parent / "tier2" / "writing_section.tex").write_text(out, encoding="utf-8")
    print(out[-2500:])


if __name__ == "__main__":
    main()
