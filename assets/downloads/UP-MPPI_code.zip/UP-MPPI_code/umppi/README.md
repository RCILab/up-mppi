# umppi — PR-MPPI, CAMP-MPPI and the unified controller

Re-implementation from the two manuscripts, PR-MPPI and CAMP-MPPI (not included; no original code). numpy, float64, CPU; the GPU controllers are in `warp_mppi.py` and `warp_writing.py`.
The top-level `README.md` lists every experiment and the note section it feeds.

| File | Content |
|---|---|
| `robot.py` | Franka-like 7-DoF arm: batched FK, Jacobians, mass matrix, RNEA, `J̇q̇`. Datasheet DH/limits, Gaz et al. masses/COMs (diagonal inertias), 0.1 kg m² armature. |
| `mjcf.py` | MJCF from the same parameters (ground-truth physics). |
| `qp.py` | Exact batched metric projection onto polyhedra (candidate active sets + Lawson–Hanson LDP fallback) and the priority relaxation of Prop. 8. |
| `writing.py` | CAMP writing task: spherical board, lemniscate path, physical contact row, virtual pen-orientation rows. |
| `physics.py` | MuJoCo physics with explicit contact (k = 2e4 N/m, μ = 0.2); computed-torque loop (order 1) and `τ = M a + b` (order 2). |
| `controllers.py` | `PRMPPI` (order 1: nested projection, execution filtering, GN retraction; `anchor=True` = Prop. 7) and `CAMPMPPI` (order 2: Gauss dynamics, wrench + HOCBF rows; `solver="separable"`, `virtual="hard"` = unified controller; `virtual="physical"` = orientation inside the manifold). |
| `generic.py` | Task-agnostic `PR1` (order 1) and `CAMP2` (order 2); a task supplies `kin`, `mass`, `phys`, `virt`, optional `extra_rows` (hard rows `C q̈ ≤ d`) and costs. |
| `dualarm.py`, `dualtask.py`, `physics_dual.py` | PR-MPPI dual-arm closed chain (tray between two arms, base calibration error), grasp springs in MuJoCo. |
| `warp_mppi.py`, `warp_writing.py` | GPU controllers (NVIDIA Warp, `pip install warp-lang`) for the waiter and the writing task (separable and joint solvers): one thread per sample runs the whole rollout (model, rows, exact dual active-set inertia-metric projection, step, cost), float32, persistent device buffers. Drop-ins for `CAMP2` / `CAMPMPPI`. `average="raw"` is Algorithm 1 of the note (raw-input MPPI update, the rollouts projected, the executed command projected once by a one-thread launch of the same kernel); `noise_clip=3.0` (default) clips the exploration noise at ±3σ. RTX 4060, K = 1024, plan time (kernel time): writing 4.4 (1.2) ms separable / 7.6 (2.8) ms joint, waiter 8.7 (7.0) ms; numpy K = 256: 184 / 200 / 293 ms (`results/gpu_timing.json`, measured on a shared workstation). Agree with numpy to ~5e-5 and reproduce closed-loop waiter runs (`python -m umppi.tests.test_warp`, `test_warp_writing`); timing: `experiments/gpu_timing.py` → `fill_timing_section.py`. |
| `waiter.py` | Tier 1(a) waiter task: box on a tray, robust support rows over the (h, μ) vertices in the tray frame, set-membership estimates of h (direct from F/T impulses on (m, m h), or from COP differences), MuJoCo physics with real contact (corner feet, elliptic cone). `WaiterTask(eps_exec=…)` tightens every support row by ‖L_i‖·eps_exec (Prop. tighten); default 0 leaves the rows unchanged. `RLSEstimate` is the certainty-equivalence baseline. |
| `safe_mppi.py` | Safe-MPPI methods from the literature on the unified model and rows (numpy, subclasses of `CAMP2`; waiter, writing and dual-arm): `ShieldMPPI` (CBF-condition penalty in the rollouts, fixed-step gradient repair of the first N controls; Yin et al. RA-L 2023), `DualGuardMPPI` (least-restrictive filter of every sample and of the output with the HJ value of a braking double integrator per joint and zero tangential tray acceleration as the safe input; Borquez et al. RA-L 2025), `GSMPPI` (closed-form filter onto a soft-min composite of all rows, repeated until it holds, raw average; Rabiee and Hoagg 2025). All keep the equality rows by the projection of Algorithm 1. |
| `robust_plan.py` | Gradient-based baselines after Heins and Schoellig (CasADi/IPOPT): `plan` (offline robust trajectory optimisation over the run, vertex rows softened by an L2 slack) with `PlanTracker` (PD tracking), and `OnlineNMPC` (receding horizon with the MPPI cost, rows hard at the first knot, jerk penalty; about 0.45 s per step on the waiter). |
| `writing_task.py` | The writing task in the generic interface of `CAMP2` (contact as a physical row, band [2, 4] N, the costs of `CAMPMPPI`), so that the safe-MPPI methods run on it. |
| `baselines.py` | Non-MPPI baselines (A3): `OneStepQPWaiter` and `OneStepQPWriting`, one-step task-space inverse dynamics with the same hard rows, solved exactly in the metric of the objective. The MPPI baselines are options of the GPU controllers: `mode="penalty", w_s=…` (A1: support rows or reaction band as a cost), `average="raw"` with `mode="penalty"` (A2: Algorithm 1 with the support rows or the band penalised in the rollouts), and `average="projected"` (the average of the earlier controllers, the ablation). |

Tests (`python -m umppi.tests.<name>` from the repo root):

- `test_robot` — model vs MuJoCo: M, bias, Jacobians to 2e-15.
- `test_qp` — batched projector vs exact solver.
- `test_theorem2` — Theorem 2 (i)–(iii) on the arm: band, motion rows, virtual rows, separable = joint.
- `test_dualarm` — dual-arm rows: Jacobians and `J̇q̇` against finite differences, IK consistency.
- `test_warp`, `test_warp_writing` — GPU controllers against the numpy references with the same noise (NVIDIA GPU).

Experiments (`experiments/`):

- `writing_exp.py` — offset sweep, 7 controllers × 5 offsets × 3 seeds, parallel (`--procs`).
- `summarize_writing.py` → `results/writing_summary.json` (incl. the Prop. 2(b) prediction).
- `plot_writing.py` → `tier2/figs/writing_force.pdf`; `fill_writing_section.py` → `tier2/writing_section.tex`.
- `camp_weight_check.py` — sensitivity of the CAMP (orientation as cost) baseline to its weight.
- `waiter_baselines.py` — waiter baselines and the averaging ablation: default run (h = 0.14, w_s sweep, RLS), `--omega-sweep` (one-step QP gain), `--sweep` (tuned baselines over h), `--rawavg`, `--calib-exec` (execution-error bound → `results/waiter_exec_bound.json`), `--rawavg-tight [--penalty-only]`.
- `safe_baselines.py` — Shield-MPPI, DualGuard MPPI and GS-MPPI on the waiter: `--tune` (parameter at h = 0.14, rows as they are and tightened), `--sweep` (best parameter over h), `--gs1` (GS-MPPI with one application of its safe law, as published).
- `heins_baselines.py` — offline robust plan with tracking and online robust NMPC on the waiter (tightened and not).
- `writing_baselines.py` — writing baselines (penalty, penalty + filter, one-step QP, unified GPU) over δ ∈ {−1, 0, 1} mm × 3 seeds.
- `safe_writing.py` — the safe-MPPI methods on the writing task.
- `corner_exp.py` — the waiter with several binding rows (low friction, diagonal move): `--calib` (its execution-error bound), default run, `--rho-check`, `--diag`.
- `fill_baselines_section.py` → `tier2/baselines_section.tex` (tables and findings, all numbers from the result files).
- `waiter_calibrate.py` (measurement bounds → `results/waiter_bounds.json`), `waiter_exp.py` (robust, adaptive, oracle, nominal over h → `results/waiter.json`), `waiter_inst_diag.py` (1-ms deviations), `report_waiter.py` → `tier2/robust_section.tex` and `tier2/figs/waiter.pdf`.
- `dualarm_exp.py` (`--calib-exec`, `--safe`) → `results/dualarm.json`; `summarize_dualarm.py`, `fill_dualarm_section.py` → `tier2/dualarm_section.tex`.
- `gpu_timing.py` → `results/gpu_timing.json`; `fill_timing_section.py` → `tier2/timing_section.tex`.

Settings that matter (found during implementation):

- Order 2 needs joint-velocity limits as motion rows and a real velocity cost (`w_v = 5`): with pure feed-forward `τ = M a + b`, MPPI noise in the null space (e.g. joint 7 about the pen axis) otherwise random-walks until the arm leaves the path. The physics adds 1 N m s/rad viscous joint friction (not modelled by any controller).
- The Prop. 2(b) stiffness of the interpolated computed-torque loop is the period average `M(ω²/2 + 2ω/Δt)`, not `Mω²`.
- Waiter: hard wrench rows only certify the *commanded* acceleration, so the execution must realise it. `WaiterPhysics` compensates the known joint damping and the measured tray load (`τ = M a + b + D q̇ − τ_load`); without either, the tray drifts ~2° off level and the oracle tips the box.
- Waiter: hold the tray heading as a third virtual row; with level only, the heading drifts by ~40° over a run.
- Waiter: the box creeps ~1.6 mm on the tray during a run under sustained tangential load (MuJoCo soft friction; no-slip iterations and elliptic cones barely change it). The direct (m, m h) estimator must therefore bound the moment of the load about an unknown offset, which dominates its torque bound. `COPDifference` cancels the offset: the COP is p_c = d − h ν_t/ν_n, so differences between windows are linear in h.
- Waiter: gate sticking on the period-averaged COP, not on per-1-ms values. Soft-contact force jitter otherwise rejects every high-acceleration window, which are the informative ones.
- Waiter: the rigid-box measurement model neglects rocking on the compliant contact. The resulting impulse error is a change of angular momentum, so its per-time error falls as 1/T_w; use 100 ms windows (8.0 → 3.2 mN·m).
- Waiter: error bounds come from `experiments/waiter_calibrate.py` (oracle runs at the ends of the prior, separate seeds, 1.5 × the largest residual) and are loaded by `waiter_exp.py` from `results/waiter_bounds.json`; the evaluation then reports residual/bound ratios.
- Warm start everywhere is PR-MPPI Alg. 1 line 23 (shift, append zero). Repeating the last input made the dual-arm joint 4 drift to its bound.
- The unified controller is Algorithm 1: raw average for the motion part with one final projection, the reaction as the average of the clamped sample reactions (`reaction="clamped"`, default with `average="raw"`), rows tightened by the calibrated execution-error bound (`results/waiter_exec_bound.json`, ε = 0.165 m/s²), noise clipped at ±3σ; `waiter_exp.default_controller`, and `average="raw", noise_clip=3.0` in `writing_exp` and `dualarm_exp`. Averaging projected samples (the earlier controllers) is conservative: the executed command stays inside the rows, which silently absorbed the execution error (waiter robust 46.8 mm). The raw average rides the boundary (30.2 mm) and the real box reaches its edge, so it needs the tightening (39.2 mm, true COP ≤ 0.79). Old results: `experiments/results/v4_projected/`.
- Do not average the raw reaction: along the contact normal the exploration noise (about 3 N per sample in writing) exceeds the band and the cost is flat, so the raw average passes the noise to the contact force and its reaction component drifts where every sample saturates (measured force 3.0 → 2.1 N, 49 % in band). Averaging after the clamp truncates it; separation lets the motion and reaction parts be averaged differently.
- The dual-arm joint rows need their own execution-error bounds (`results/dualarm_exec_bound.json`, per joint): with ε = 0 the raw average rides the joint-4 barrier and the unmodelled tray pushes the joint 0.008 rad past the bound.
- A penalty on the reaction band ruins MPPI in writing: the normal component of the noise moves every sample's reaction by newtons, and the penalty ranks samples by it (5–68 mm). The clamp removes it from the costs.
- The waiter reference (3.6 m/s² peak) exceeds every admissible acceleration of the sweep, so a one-step QP overshoots (ω = 15 tips the box; best ω = 6 gives 76.5 mm). In writing, where no row binds, the one-step QP beats MPPI (1.0 vs 1.6 mm).
