"""Curved-surface writing: PR-MPPI vs CAMP-MPPI vs the unified controller under surface-model offset.

Predictions (Tier-2 note):
  Prop. 2(b)  PR-MPPI's contact force follows the offset at the series stiffness; lift-off for
              a model surface above the real one.
  Prop. 7     anchoring removes the offset-driven force, and with it the writing force.
  Prop. 2(a)  order-2 controllers keep the commanded reaction in the band for every offset.
  Thm. 1      W = I lets force corrections leak into the tangential motion.
"""
import argparse
import json
import sys
import time
from pathlib import Path

import mujoco
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import writing as W_  # noqa: E402
from umppi.controllers import CAMPMPPI, PRMPPI  # noqa: E402
from umppi.physics import Physics  # noqa: E402
from umppi.robot import Q_MAX, Q_MIN, Chain  # noqa: E402

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])

DT, H, K = 0.01, 15, 256  # common to all controllers (100 Hz, as in CAMP-MPPI)
O1 = dict(dt=DT, H=H, K=K, sigma=0.1, w_p=2e4, w_T=2e3)
O2 = dict(dt=DT, H=H, K=K, sigma=0.8, w_p=1e5, w_T=1e4, w_v=5.0)
ALG1 = dict(average="raw", noise_clip=3.0)  # Algorithm 1; CAMP-MPPI and PR-MPPI run as published
CONTROLLERS = {
    "PR": lambda ch, dl: PRMPPI(ch, metric="I", anchor=False, delta=dl, **O1),
    "PR-anchored": lambda ch, dl: PRMPPI(ch, metric="I", anchor=True, delta=dl, **O1),
    "CAMP": lambda ch, dl: CAMPMPPI(ch, metric="M", solver="joint", virtual="soft", delta=dl, **O2),
    "CAMP-manifold": lambda ch, dl: CAMPMPPI(ch, metric="M", solver="joint", virtual="physical", delta=dl, **O2),
    "Unified": lambda ch, dl: CAMPMPPI(ch, metric="M", solver="separable", virtual="hard", delta=dl, **O2, **ALG1),
    "Unified-joint": lambda ch, dl: CAMPMPPI(ch, metric="M", solver="joint", virtual="hard", delta=dl, **O2, **ALG1),
    "Unified-W=I": lambda ch, dl: CAMPMPPI(ch, metric="I", solver="joint", virtual="hard", delta=dl, **O2, **ALG1),
}


def run(name, delta_mm, T=W_.T_PATH, dt=DT, seed=0, rec=None, controller_factory=None):
    """rec: optional dict filled with qpos per control step and ink samples every 5 ms (for videos)."""
    chain = Chain()
    phys = Physics(chain)
    q_init = W_.ik_on_surface(chain, W_.path_point(0.0)[0], Q_READY)
    phys.reset(q_init)
    ctrl = (CONTROLLERS[name] if controller_factory is None else controller_factory)(chain, delta_mm * 1e-3)
    ctrl.rng = np.random.default_rng(seed)
    order = 1 if isinstance(ctrl, PRMPPI) else 2
    fn_log, err_log, ori_log, lam_cmd, margin = [], [], [], [], np.inf
    diverged_t = None
    t_wall = time.perf_counter()
    for step in range(int(round(T / dt))):
        t_now = step * dt
        q0, qd0 = phys.q, phys.qd
        try:
            cmd = ctrl.plan(q0, qd0, t_now)
        except (ValueError, np.linalg.LinAlgError, FloatingPointError):  # controller state went non-finite
            diverged_t = t_now
            break
        logs = phys.step_order1(q0, cmd["q_plus"], dt) if order == 1 else phys.step_order2(cmd["a"], dt)
        if order == 2:
            lam_cmd.append(float(np.ravel(cmd["lam_cmd"])[0]))
        ts = t_now + phys.dt * np.arange(1, len(logs) + 1)
        tgt = W_.path_point(ts)
        if rec is not None:
            rec.setdefault("t", []).append(t_now + dt)
            rec.setdefault("qpos", []).append(phys.q)
            for j in range(4, len(logs), 5):
                rec.setdefault("ink_p", []).append(logs[j][2])
                rec.setdefault("ink_f", []).append(logs[j][0])
            if order == 2:
                rec.setdefault("lam_cmd", []).append(float(np.ravel(cmd["lam_cmd"])[0]))
        for (fn, gap, p), pt in zip(logs, tgt):
            fn_log.append(fn)
            err_log.append(np.linalg.norm(p - pt))
        zt = phys.d.site_xmat[phys.sid].reshape(3, 3)[:, 2]
        ori_log.append(np.degrees(np.arccos(np.clip(-zt[2], -1, 1))))
        margin = min(margin, np.min(phys.q - Q_MIN), np.min(Q_MAX - phys.q))
        unstable = phys.d.warning[mujoco.mjtWarning.mjWARN_BADQACC].number > 0
        if unstable or not np.all(np.isfinite(phys.q)) or err_log[-1] > 0.10:
            diverged_t = t_now + dt  # stop: metrics are reported over the executed portion
            break
    fn = np.array(fn_log)
    settle = int(0.5 / phys.dt)  # skip the first 0.5 s (force build-up)
    if fn.size <= settle:  # diverged before the settling window: report over what ran
        settle = 0
    fs = fn[settle:] if fn.size else np.full(1, np.nan)
    if not err_log:
        err_log, ori_log = [np.nan], [np.nan]
    res = dict(
        controller=name, delta_mm=delta_mm,
        track_rmse_mm=1e3 * float(np.sqrt(np.mean(np.array(err_log)[settle:] ** 2))),
        force_mean=float(fs.mean()), force_std=float(fs.std()), force_max=float(fs.max()),
        in_band=float(np.mean((fs >= W_.LAM_BAND[0]) & (fs <= W_.LAM_BAND[1]))),
        contact=float(np.mean(fs > 0.1)),
        ori_rms_deg=float(np.sqrt(np.mean(np.array(ori_log) ** 2))),
        joint_margin=float(margin),
        lam_cmd_range=[float(min(lam_cmd)), float(max(lam_cmd))] if lam_cmd else None,
        ms_per_step=1e3 * float(np.mean(ctrl.stats["time"])),
        fallback_rate=ctrl.stats["fallback"] / max(ctrl.stats["calls"], 1),
        relaxed=ctrl.stats["relaxed"],
        wall_s=time.perf_counter() - t_wall,
        diverged_t=diverged_t,
    )
    return res, fn


def _job(args):
    name, dl, seed, T = args
    try:
        r, fn = run(name, dl, T=T, seed=seed)
    except Exception as exc:  # record, do not abort the sweep
        return {"controller": name, "delta_mm": dl, "seed": seed, "error": repr(exc)}, []
    r["seed"] = seed
    return r, fn[::10].tolist()


if __name__ == "__main__":
    from multiprocessing import Pool
    import warnings
    warnings.filterwarnings("ignore")
    ap = argparse.ArgumentParser()
    ap.add_argument("--T", type=float, default=W_.T_PATH)
    ap.add_argument("--controllers", nargs="*", default=list(CONTROLLERS))
    ap.add_argument("--deltas", nargs="*", type=float, default=[-1.0, -0.5, 0.0, 0.5, 1.0])
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--procs", type=int, default=24)
    ap.add_argument("--out", default="results/writing.json")
    ap.add_argument("--merge", action="store_true", help="keep the rows of the other controllers in --out")
    args = ap.parse_args()
    out = Path(__file__).resolve().parent / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    jobs = [(nm, dl, s, args.T) for nm in args.controllers for dl in args.deltas for s in range(args.seeds)]
    rows, traces = [], {}
    if args.merge and out.exists():
        old = json.loads(out.read_text())
        rows = [r for r in old["rows"] if r["controller"] not in args.controllers]
        traces = {k: v for k, v in old["traces"].items() if k.split("|")[0] not in args.controllers}
    with Pool(args.procs) as pool:
        for r, tr in pool.imap_unordered(_job, jobs):
            rows.append(r)
            traces[f"{r['controller']}|{r['delta_mm']}|{r['seed']}"] = tr
            print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()}), flush=True)
            out.write_text(json.dumps({"rows": rows, "traces": traces}))
