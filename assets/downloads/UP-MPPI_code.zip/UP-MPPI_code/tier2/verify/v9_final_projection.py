"""Algorithm 1 -- raw average, one final projection, tightened rows (Prop. exec(a), Thm. 2(vi), Prop. avg remark).

1. Raw SNIS with clipped noise.  Proposal: N(0, I_d) clipped at +-3 per coordinate (as the controllers); cost
   S(v) = |v - c|^2 / 2, temperature lam.  Everything factorises over coordinates, so the target
   E_Q*[V] and rho = E_P[g^2] / E_P[g]^2 follow from one-dimensional quadrature.  Lemma 2(b) with the
   identity map and u_bar = 3:  MSE <= 4 rho u_bar^2 / K per coordinate.
2. The final projection inherits the error: |Pi(U_hat) - Pi(U*)|_W <= |U_hat - U*|_W (W-nonexpansive).
3. Tightened rows: Pi onto {L y <= b - eps |L|} leaves every y' with |y' - y| <= eps inside {L y <= b}.
4. Distortion direction: for every row binding at Pi(v_hat), L_i (projected average - Pi(v_hat)) <= 0.
5. Raw nominal bound: shift-and-update with clipped noise keeps every raw input within 3 sigma H.
"""
import numpy as np
from scipy.integrate import quad
from scipy.stats import norm

from common import Report, loglog_slope, qp_project, rand_spd, wnorm

rng = np.random.default_rng(9)
d, lam, CLIP = 4, 1.0, 3.0
c = np.array([1.5, -0.5, 2.0, 0.0])
KS = np.array([32, 128, 512, 2048])
REPS = 2000


def truncated_normal(shape):
    """The controllers' noise: N(0, 1) clipped at +-3 (point masses on the bounds, bounded as the lemma needs)."""
    return np.clip(rng.standard_normal(shape), -CLIP, CLIP)


def exact_clipped():
    """Target mean and rho for the clipped normal (point masses at +-3), per coordinate."""
    pm = norm.sf(CLIP)  # mass at each bound
    mean, rho = np.empty(d), 1.0
    for i in range(d):
        g = lambda v: np.exp(-0.5 * (v - c[i]) ** 2 / lam)  # noqa: E731
        m0 = quad(lambda v: g(v) * norm.pdf(v), -CLIP, CLIP)[0] + pm * (g(CLIP) + g(-CLIP))
        m1 = quad(lambda v: v * g(v) * norm.pdf(v), -CLIP, CLIP)[0] + pm * CLIP * (g(CLIP) - g(-CLIP))
        m2 = quad(lambda v: g(v) ** 2 * norm.pdf(v), -CLIP, CLIP)[0] + pm * (g(CLIP) ** 2 + g(-CLIP) ** 2)
        mean[i] = m1 / m0
        rho *= m2 / m0 ** 2
    return mean, rho


def main():
    rep = Report("Algorithm 1 final projection")
    # ---------------------------------------------------------------- 1. raw SNIS, clipped noise
    mu, rho = exact_clipped()
    rep.info("closed form (quadrature)", f"rho = {rho:.2f}, target {np.array2string(mu, precision=3)}")
    W = rand_spd(d, rng, spread=0.5)
    A = rng.standard_normal((6, d))
    b = 0.3 + rng.uniform(0.0, 0.5, 6)  # polytope containing 0; the target lies outside it
    pi_mu = qp_project(mu, W, Ain=A, bin_=b)[0]
    mse, mse_pi, ratio_max = [], [], 0.0
    for K in KS:
        est = np.empty((REPS, d))
        dpi = np.empty(REPS)
        for r in range(REPS):
            V = truncated_normal((K, d))
            logw = -0.5 * np.sum((V - c) ** 2, axis=1) / lam
            w = np.exp(logw - logw.max())
            w /= w.sum()
            est[r] = w @ V
            if r < 200:  # the projection of the estimate against the projection of the target
                p_est = qp_project(est[r], W, Ain=A, bin_=b)[0]
                dpi[r] = wnorm(p_est - pi_mu, W) ** 2
                ratio_max = max(ratio_max, np.sqrt(dpi[r]) / max(wnorm(est[r] - mu, W), 1e-15))
        mse.append(np.max(np.mean((est - mu) ** 2, axis=0)))
        mse_pi.append(np.mean(dpi[:200]))
    mse, mse_pi = np.array(mse), np.array(mse_pi)
    bound = 4 * rho * CLIP ** 2 / KS
    rep.check("raw SNIS, clipped noise: MSE <= 4 rho u_bar^2 / K (every K, worst coordinate)", np.all(mse <= bound),
              f"MSE/bound {np.array2string(mse / bound, precision=4)}")
    s = loglog_slope(KS, mse)
    rep.check("raw SNIS, clipped noise: MSE ~ 1/K (consistency)", abs(s + 1) < 0.15, f"slope {s:.2f}")
    rep.check("final projection is W-nonexpansive: |Pi(U) - Pi(U*)|_W <= |U - U*|_W", ratio_max <= 1 + 1e-9,
              f"largest ratio {ratio_max:.4f}")
    lmax = np.linalg.eigvalsh(W).max()
    rep.check("executed command: E|Pi(U) - Pi(U*)|_W^2 <= lambda_max(W) d 4 rho u_bar^2 / K",
              np.all(mse_pi <= lmax * d * bound), f"ratio {np.array2string(mse_pi / (lmax * d * bound), precision=4)}")
    # ---------------------------------------------------------------- 3. tightened rows
    worst = -np.inf
    eps = 0.2
    for _ in range(300):
        x = 2.0 * rng.standard_normal(d)
        y = qp_project(x, W, Ain=A, bin_=b - eps * np.linalg.norm(A, axis=1))[0]
        worst = max(worst, float(np.max(A @ y + eps * np.linalg.norm(A, axis=1) - b)))  # worst |y'-y| <= eps
    rep.check("tightened final projection: every y' within eps satisfies the untightened rows", worst <= 1e-9,
              f"largest worst-case row value {worst:.1e}")
    # ---------------------------------------------------------------- 4. distortion direction
    worst_dir, moved = -np.inf, 0
    for _ in range(300):
        v = rng.standard_normal((64, d)) * 1.5 + rng.standard_normal(d)
        wk = rng.dirichlet(np.ones(64) * 0.3)
        vh = wk @ v
        p_hat, act, _ = qp_project(vh, W, Ain=A, bin_=b)
        p_avg = wk @ np.array([qp_project(vk, W, Ain=A, bin_=b)[0] for vk in v])
        if act:
            dirv = A[list(act)] @ (p_avg - p_hat)
            worst_dir = max(worst_dir, float(dirv.max()))
            moved += int(np.min(dirv) < -1e-9)
    rep.check("distortion points to the feasible side of every row binding at Pi(v_hat)", worst_dir <= 1e-8,
              f"largest L_i (avg - Pi(v_hat)) {worst_dir:.1e}; strictly inside in {moved} of 300 draws")
    # ---------------------------------------------------------------- 6. separated reaction (Algorithm 1)
    # Gauss dynamics with one contact: a -> qdd = F a + f, lambda(a) = -Lam (Jc a + jcd).  Replacing the reaction
    # of a command by lam_bar through a += MiJt (lambda(a) - lam_bar) must leave F a unchanged.
    worst_lam, worst_motion = 0.0, 0.0
    for _ in range(300):
        n_ = 7
        Mm = rand_spd(n_, rng, spread=1.0)
        Jc = rng.standard_normal(n_)
        jcd = rng.standard_normal()
        Mi = np.linalg.inv(Mm)
        Lam = 1.0 / (Jc @ Mi @ Jc)
        MiJt = Mi @ Jc
        F = np.eye(n_) - np.outer(MiJt, Jc) * Lam
        a = rng.standard_normal(n_)
        react = lambda x: -Lam * (Jc @ x + jcd)  # noqa: E731
        lam_bar = rng.uniform(2.0, 4.0)
        a2 = a + MiJt * (react(a) - lam_bar)
        worst_lam = max(worst_lam, abs(react(a2) - lam_bar))
        worst_motion = max(worst_motion, float(np.max(np.abs(F @ (a2 - a)))))
    rep.check("reaction replacement sets the reaction exactly", worst_lam < 1e-9, f"largest |lambda - lam_bar| {worst_lam:.1e}")
    rep.check("reaction replacement leaves the motion F a unchanged (separation)", worst_motion < 1e-9,
              f"largest |F (a' - a)| {worst_motion:.1e}")
    # ---------------------------------------------------------------- 5. raw nominal bound
    H, n, sigma = 20, 7, 1.0
    U = np.zeros((H, n))
    vmax = 0.0
    for _ in range(500):
        eps_k = sigma * np.clip(rng.standard_normal((64, H, n)), -CLIP, CLIP)
        wk = rng.dirichlet(np.ones(64) * 0.1)
        vmax = max(vmax, float(np.max(np.abs(U[None] + eps_k))))
        vh = U + np.einsum("k,kti->ti", wk, eps_k)
        U = np.concatenate([vh[1:], np.zeros((1, n))], 0)
    rep.check("raw inputs stay within 3 sigma H under shift-and-update", vmax <= CLIP * sigma * H + 1e-12,
              f"largest |V| {vmax:.2f} <= {CLIP * sigma * H:.0f}")
    return rep


if __name__ == "__main__":
    main()
