"""Figure for the Tier-2 note: contact force vs surface-model offset, and force traces.

Colours: reference categorical palette, fixed slot order, one colour per controller in both
panels.  Unified-joint is omitted (identical to Unified, Thm. 1).
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import writing as W_  # noqa: E402

HERE = Path(__file__).resolve().parent
INK, INK2, GRID, BAND = "#0b0b0b", "#52514e", "#e4e3df", "#f0efec"
SERIES = [  # (controller, label, slot colour, marker, filled) -- markers are secondary encoding
    ("Unified", "Unified (ours)", "#2a78d6", "o", True),
    ("PR", "PR-MPPI", "#eb6834", "s", True),
    ("CAMP", "CAMP-MPPI, orientation as cost", "#1baf7a", "D", False),
    ("PR-anchored", "PR-MPPI, anchored (Prop. 7)", "#eda100", "s", False),
    ("Unified-W=I", "Unified, $W=I$", "#e87ba4", "^", False),
]
Z = {"Unified": 6, "PR": 5, "CAMP": 4, "PR-anchored": 3, "Unified-W=I": 4}


def style(ax):
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(INK2)
        ax.spines[s].set_linewidth(0.6)
    ax.tick_params(colors=INK2, labelsize=7.5, width=0.6)
    ax.xaxis.label.set_color(INK)
    ax.yaxis.label.set_color(INK)


def main():
    D = json.loads((HERE / "results/writing.json").read_text())
    S = json.loads((HERE / "results/writing_summary.json").read_text())
    rows = [r for r in D["rows"] if "error" not in r and r.get("diverged_t") is None]
    g = defaultdict(list)
    for r in rows:
        g[(r["controller"], r["delta_mm"])].append(r["force_mean"])
    deltas = np.array([-1.0, -0.5, 0.0, 0.5, 1.0])
    plt.rcParams.update({"font.size": 8, "font.family": "serif", "mathtext.fontset": "cm"})
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.4, 2.55), gridspec_kw={"width_ratios": [1.0, 1.25]})

    # (a) mean contact force vs offset
    a.axhspan(*W_.LAM_BAND, color=BAND, zorder=0)
    gain = S["pred_gain_N_per_mm"]
    xs = np.linspace(-1.05, 1.05, 50)
    a.plot(xs, np.where(xs < 0, -gain * xs, 0.0), ls=(0, (4, 2)), lw=1.0, color=INK, zorder=7)
    for name, label, col, mk, filled in SERIES:
        m = [np.mean(g[(name, dl)]) if g[(name, dl)] else np.nan for dl in deltas]
        a.plot(deltas, m, "-", color=col, lw=1.5, zorder=Z[name])
        a.plot(deltas, m, mk, ms=5.5 if filled else 6.5, color=col, mfc=col if filled else "white",
               mec=col if not filled else "white", mew=1.2 if not filled else 0.8, zorder=Z[name] + 0.5)
    a.set_xlabel(r"board-model offset $\delta$ [mm]  ($\delta<0$: model below the real board)")
    a.set_ylabel("mean contact force [N]")
    a.set_xticks(deltas)
    a.set_ylim(-0.6, 17.5)
    style(a)

    # (b) force traces at delta = 0
    b.axhspan(*W_.LAM_BAND, color=BAND, zorder=0)
    for name, _, col, _, _ in [SERIES[4], SERIES[0]]:
        if f"{name}|0.0|0" not in D["traces"]:
            continue
        tr = np.array(D["traces"][f"{name}|0.0|0"])
        t = 0.01 * np.arange(1, tr.size + 1)
        b.plot(t, tr, color=col, lw=0.9)
    b.set_xlabel("time [s]")
    b.set_ylabel("contact force [N]")
    b.set_xlim(0, W_.T_PATH)
    b.set_ylim(0, 6.5)
    style(b)
    handles = [plt.Line2D([], [], color=c, lw=1.5, marker=mk, ms=5.5 if f else 6.5, mfc=c if f else "white",
                          mec="white" if f else c, mew=0.8 if f else 1.2) for _, _, c, mk, f in SERIES]
    handles += [plt.Line2D([], [], color=INK, lw=1.0, ls=(0, (4, 2))),
                matplotlib.patches.Patch(color=BAND)]
    labels = [lab for _, lab, _, _, _ in SERIES] + [f"Prop. 2(b) prediction, {gain:.1f} N/mm", "admissible band 2-4 N"]
    fig.legend(handles, labels, loc="upper center", ncol=4, frameon=False, fontsize=6.8,
               bbox_to_anchor=(0.5, 1.08), labelcolor=INK, handlelength=2.2)
    a.set_title("(a) offset sweep, mean over 3 seeds", fontsize=8, color=INK, loc="left")
    b.set_title(r"(b) $\delta=0$: Unified vs. $W=I$", fontsize=8, color=INK, loc="left")
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    out = HERE.parents[0] / "tier2" / "figs"
    out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / "writing_force.pdf", bbox_inches="tight")
    fig.savefig(out / "writing_force.png", dpi=200, bbox_inches="tight")
    print("saved", out / "writing_force.pdf")


if __name__ == "__main__":
    main()
