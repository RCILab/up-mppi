"""Offline robust trajectory optimisation and tracking, after Heins and Schoellig, RA-L 2025 (arXiv:2411.07079).

Their controller plans the whole motion once with the robust sticking constraints at the vertices of the
parameter set, softened by an L2 slack penalty (OCS2 SQP, jerk input, 0.1 s knots), and tracks the plan online.
Here the same structure on the waiter: one IPOPT solve (CasADi) over the run with the robust support rows of
WaiterTask (tray frame, h_hi tipping and mu_lo slip over eight directions, lift-off; optionally tightened by eps),
the tray level and heading as equality constraints, joint position and velocity limits, piecewise-constant
joint accelerations on 0.05 s knots, a tracking cost on the tray point and small velocity, acceleration and jerk
regularisation.  PlanTracker then executes a = qdd_plan + K_D (qd_plan - qd) + K_P (q_plan - q).
"""
import time

import casadi as ca
import numpy as np

from . import waiter as WT


def fk_casadi(chain):
    """Rotation of the last frame and position of the tool point, as a CasADi function of q."""
    q = ca.SX.sym("q", chain.n)
    Rc, oc = ca.DM(chain.base_rot), ca.DM(chain.base_pos)
    for i in range(chain.n):
        oc = oc + Rc @ ca.DM(chain.p[i])
        c, s = ca.cos(q[i]), ca.sin(q[i])
        Rz = ca.vertcat(ca.horzcat(c, -s, 0), ca.horzcat(s, c, 0), ca.horzcat(0, 0, 1))
        Rc = Rc @ ca.DM(chain.Rx[i]) @ Rz
    return ca.Function("fk", [q], [Rc, oc + Rc @ ca.DM(chain.tool)])


def knot_functions(chain, h_hi, mu_lo, eps=0.0):
    """Support rows (<= 0), virtual rows (= 0) and the tray point, per knot, as CasADi functions."""
    n = chain.n
    q, qd, a = ca.SX.sym("q", n), ca.SX.sym("qd", n), ca.SX.sym("a", n)
    R7, p = fk_casadi(chain)(q)
    J = ca.jacobian(p, q)
    s = J @ a + ca.jacobian(J @ qd, q) @ qd - ca.DM(WT.G)
    nrm = -R7[:, 2]
    x7 = R7[:, 0]
    t1 = x7 - ca.dot(x7, nrm) * nrm
    t1 = t1 / ca.norm_2(t1)
    t2 = ca.cross(nrm, t1)
    rc = WT.R_BASE * WT.C8
    rows = []
    Lt = np.hypot(h_hi, rc)
    Ls = np.hypot(1.0, mu_lo * WT.C8)
    for k in range(WT.N_DIR):
        th = 2 * np.pi * k / WT.N_DIR
        u = np.cos(th) * t1 + np.sin(th) * t2
        rows.append(h_hi * ca.dot(u, s) - rc * ca.dot(nrm, s) + eps * Lt)
        rows.append(ca.dot(u, s) - mu_lo * WT.C8 * ca.dot(nrm, s) + eps * Ls)
    rows.append(WT.S_MIN + eps - ca.dot(nrm, s))
    virt = ca.vertcat(nrm[0], nrm[1], x7[1])
    return (ca.Function("rows", [q, qd, a], [ca.vertcat(*rows)]), ca.Function("virt", [q], [virt]),
            ca.Function("tray", [q], [p]))


def plan(chain, q0, h_box=(0.05, 0.18), mu_box=(0.4, 0.8), eps=0.0, T=WT.T_RUN, dt=0.05, q_min=None, q_max=None,
         qd_max=None, h_safe=0.05, w_r=1e3, w_v=1e-2, w_a=1e-3, w_j=1e-5, w_s=1e6, max_iter=3000, verbose=False):
    """Solve the robust plan once; returns dict(t, Q, Qd, A, info)."""
    from .robot import Q_MAX, Q_MIN, QD_MAX
    q_min = Q_MIN if q_min is None else q_min
    q_max = Q_MAX if q_max is None else q_max
    qd_max = QD_MAX if qd_max is None else qd_max
    n, N = chain.n, int(round(T / dt))
    rows_f, virt_f, tray_f = knot_functions(chain, max(h_box), min(mu_box), eps)
    m = rows_f.size1_out(0)
    opti = ca.Opti()
    Q, Qd, A, Sl = opti.variable(n, N + 1), opti.variable(n, N + 1), opti.variable(n, N), opti.variable(m, N)
    tk = dt * np.arange(N + 1)
    P_ref = WT.target(tk).T  # (3, N+1)
    cost = 0
    for k in range(N):
        opti.subject_to(Q[:, k + 1] == Q[:, k] + dt * Qd[:, k] + 0.5 * dt ** 2 * A[:, k])
        opti.subject_to(Qd[:, k + 1] == Qd[:, k] + dt * A[:, k])
    rows_all = rows_f.map(N)(Q[:, :N], Qd[:, :N], A)
    opti.subject_to(ca.vec(rows_all) <= ca.vec(Sl))
    opti.subject_to(ca.vec(Sl) >= 0)
    opti.subject_to(ca.vec(virt_f.map(N)(Q[:, 1:])) == 0)
    trays = tray_f.map(N + 1)(Q)
    cost += w_r * dt * ca.sumsqr(trays - P_ref)
    cost += w_v * dt * ca.sumsqr(Qd) + w_a * dt * ca.sumsqr(A) + w_j * dt * ca.sumsqr((A[:, 1:] - A[:, :-1]) / dt)
    cost += w_s * dt * ca.sumsqr(Sl)
    opti.subject_to(Q[:, 0] == q0)
    opti.subject_to(Qd[:, 0] == 0)
    lo, hi = q_min + h_safe, q_max - h_safe
    for k in range(N + 1):
        opti.subject_to(opti.bounded(lo, Q[:, k], hi))
        opti.subject_to(opti.bounded(-qd_max, Qd[:, k], qd_max))
    opti.minimize(cost)
    # initial guess: inverse kinematics along the reference, tray level
    Qg = np.empty((N + 1, n))
    qs = q0.copy()
    for k in range(N + 1):
        qs = WT.ik(chain, P_ref[:, k], qs)
        Qg[k] = qs
    Qdg = np.gradient(Qg, dt, axis=0)
    Ag = np.gradient(Qdg, dt, axis=0)[:N]
    opti.set_initial(Q, Qg.T)
    opti.set_initial(Qd, Qdg.T)
    opti.set_initial(A, Ag.T)
    opti.set_initial(Sl, 0.0)
    opts = {"print_time": verbose, "ipopt.print_level": 5 if verbose else 0, "ipopt.max_iter": max_iter,
            "ipopt.tol": 1e-6}
    opti.solver("ipopt", opts)
    t0 = time.perf_counter()
    try:
        sol = opti.solve()
        status = "solved"
    except RuntimeError:
        sol = opti.debug
        status = "not solved: " + opti.stats()["return_status"]
    info = dict(status=status, solve_s=time.perf_counter() - t0, iters=opti.stats()["iter_count"],
                max_slack=float(np.max(sol.value(Sl))), cost=float(sol.value(cost)))
    return dict(t=tk, Q=np.array(sol.value(Q)).T, Qd=np.array(sol.value(Qd)).T, A=np.array(sol.value(A)).T,
                dt=dt, info=info)


class PlanTracker:
    """Execute a plan: a = A_k + K_D (qd_plan(t) - qd) + K_P (q_plan(t) - q), constant plan acceleration per knot."""

    def __init__(self, pl, KP=100.0, KD=20.0):
        self.pl, self.KP, self.KD = pl, KP, KD
        self.rng = None
        self.stats = {"time": [], "relaxed": 0}

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        pl = self.pl
        k = int(np.clip(np.floor(t_now / pl["dt"] + 1e-9), 0, len(pl["A"]) - 1))
        tau = t_now - k * pl["dt"]
        a_k = pl["A"][k]
        q_ref = pl["Q"][k] + tau * pl["Qd"][k] + 0.5 * tau ** 2 * a_k
        qd_ref = pl["Qd"][k] + tau * a_k
        a = a_k + self.KD * (qd_ref - qd0) + self.KP * (q_ref - q0)
        self.stats["time"].append(time.perf_counter() - t0)
        return {"a": a}


def virt_acc_function(chain, KP=100.0, KD=20.0):
    """Stabilised virtual rows at the acceleration level, as in Algorithm 1: J_e a + d/dt(J_e) qd + K_D J_e qd + K_P e = 0."""
    n = chain.n
    q, qd, a = ca.SX.sym("q", n), ca.SX.sym("qd", n), ca.SX.sym("a", n)
    R7, _ = fk_casadi(chain)(q)
    nrm, x7 = -R7[:, 2], R7[:, 0]
    e = ca.vertcat(nrm[0], nrm[1], x7[1])
    Je = ca.jacobian(e, q)
    res = Je @ a + ca.jacobian(Je @ qd, q) @ qd + KD * (Je @ qd) + KP * e
    return ca.Function("virt_acc", [q, qd, a], [res])


class OnlineNMPC:
    """Receding-horizon robust NMPC with the waiter cost of the MPPI controllers (same weights, horizon and step):
    joint accelerations on H knots, robust support rows hard at the first knot and softened by an L2 slack beyond,
    the stabilised virtual rows as equalities, joint position (with the margin h_safe) and velocity bounds.  IPOPT,
    warm-started from the shifted previous solution; the executed command is the first acceleration."""

    def __init__(self, task, h_box=None, mu_box=None, eps=0.0, H=20, dt=0.02, w_s=1e6, w_j=1e-3, max_iter=200,
                 KP=100.0, KD=20.0):
        from .robot import Q_MAX, Q_MIN, QD_MAX
        self.task, self.H, self.dt = task, H, dt
        ch, n = task.chain, task.chain.n
        h_box = task.h_box if h_box is None else h_box
        mu_box = task.mu_box if mu_box is None else mu_box
        rows_f, _, tray_f = knot_functions(ch, max(h_box), min(mu_box), eps)
        vel_f = self._tray_vel_function(ch)
        va_f = virt_acc_function(ch, KP, KD)
        m = rows_f.size1_out(0)
        opti = ca.Opti()
        Q, Qd, A, Sl = opti.variable(n, H + 1), opti.variable(n, H + 1), opti.variable(n, H), opti.variable(m, H)
        q0, qd0, a_prev = opti.parameter(n), opti.parameter(n), opti.parameter(n)
        Pr, Vr = opti.parameter(3, H), opti.parameter(3, H)
        for k in range(H):
            opti.subject_to(Q[:, k + 1] == Q[:, k] + dt * Qd[:, k + 1])  # semi-implicit, as the MPPI rollouts
            opti.subject_to(Qd[:, k + 1] == Qd[:, k] + dt * A[:, k])
        opti.subject_to(Q[:, 0] == q0)
        opti.subject_to(Qd[:, 0] == qd0)
        rows_all = rows_f.map(H)(Q[:, :H], Qd[:, :H], A)
        opti.subject_to(ca.vec(rows_all) <= ca.vec(Sl))
        opti.subject_to(ca.vec(Sl) >= 0)
        opti.subject_to(Sl[:, 0] == 0)  # hard at the first knot: the executed command satisfies the rows
        opti.subject_to(ca.vec(va_f.map(H)(Q[:, :H], Qd[:, :H], A)) == 0)
        lo, hi = Q_MIN + task.h_safe, Q_MAX - task.h_safe
        for k in range(1, H + 1):
            opti.subject_to(opti.bounded(lo, Q[:, k], hi))
            opti.subject_to(opti.bounded(-QD_MAX, Qd[:, k], QD_MAX))
        T = task
        P = tray_f.map(H)(Q[:, 1:])
        V = vel_f.map(H)(Q[:, 1:], Qd[:, 1:])
        cost = dt * (T.w_p * ca.sumsqr(P - Pr) + T.w_pv * ca.sumsqr(V - Vr) + T.w_v * ca.sumsqr(Qd[:, 1:])
                     + T.w_q * ca.sumsqr(Q[:, 1:] - ca.repmat(ca.DM(T.q_ref), 1, H)))
        cost += T.w_T * ca.sumsqr(P[:, -1] - Pr[:, -1]) + T.w_Tv * ca.sumsqr(V[:, -1] - Vr[:, -1])
        cost += w_s * dt * ca.sumsqr(Sl)
        # jerk penalty, including the step from the previously executed command (as the smoothness of Heins et al.)
        cost += w_j * dt * (ca.sumsqr((A[:, 0] - a_prev) / dt) + ca.sumsqr((A[:, 1:] - A[:, :-1]) / dt))
        opti.minimize(cost)
        opti.solver("ipopt", {"print_time": False, "expand": True, "ipopt.print_level": 0, "ipopt.max_iter": max_iter,
                              "ipopt.tol": 1e-6, "ipopt.warm_start_init_point": "yes"})
        self.opti, self.Q, self.Qd, self.A, self.Sl, self.q0, self.qd0, self.Pr, self.Vr = opti, Q, Qd, A, Sl, q0, qd0, Pr, Vr
        self.a_prev_p, self.a_prev = a_prev, np.zeros(n)
        self.prev = None
        self.rng = None
        self.stats = {"time": [], "relaxed": 0, "fail": 0}

    @staticmethod
    def _tray_vel_function(ch):
        q, qd = ca.SX.sym("q", ch.n), ca.SX.sym("qd", ch.n)
        _, p = fk_casadi(ch)(q)
        return ca.Function("vel", [q, qd], [ca.jacobian(p, q) @ qd])

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        H, dt, n = self.H, self.dt, len(q0)
        taus = self.task.t_now + dt * (np.arange(H) + 1)
        o = self.opti
        o.set_value(self.q0, q0)
        o.set_value(self.qd0, qd0)
        o.set_value(self.a_prev_p, self.a_prev)
        o.set_value(self.Pr, WT.target(taus).T)
        o.set_value(self.Vr, WT.target_vel(taus).T)
        if self.prev is None:
            o.set_initial(self.Q, np.repeat(q0[:, None], H + 1, 1))
            o.set_initial(self.Qd, np.zeros((n, H + 1)))
            o.set_initial(self.A, np.zeros((n, H)))
        else:
            Qp, Qdp, Ap = self.prev
            o.set_initial(self.Q, np.concatenate([Qp[:, 1:], Qp[:, -1:]], 1))
            o.set_initial(self.Qd, np.concatenate([Qdp[:, 1:], Qdp[:, -1:]], 1))
            o.set_initial(self.A, np.concatenate([Ap[:, 1:], np.zeros((n, 1))], 1))
        try:
            sol = o.solve()
            Qs, Qds, As = sol.value(self.Q), sol.value(self.Qd), sol.value(self.A)
        except RuntimeError:  # keep the last solution, shifted
            self.stats["fail"] += 1
            if self.prev is None:
                Qs, Qds, As = np.repeat(q0[:, None], H + 1, 1), np.zeros((n, H + 1)), np.zeros((n, H))
            else:
                Qs, Qds, As = o.debug.value(self.Q), o.debug.value(self.Qd), o.debug.value(self.A)
        self.prev = (np.asarray(Qs), np.asarray(Qds), np.asarray(As))
        self.a_prev = np.asarray(As)[:, 0].copy()
        self.stats["time"].append(time.perf_counter() - t0)
        return {"a": self.a_prev.copy()}
