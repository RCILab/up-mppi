# UP-MPPI 코드 (연구노트 재현용)

이 코드는 연구노트 *Tier-2 theory note: one geometry for PR-MPPI and CAMP-MPPI*(2026-09-27판, `UP-MPPI_research_note_2026-09-27.pdf`)에 나오는 수치, 표, 그림을 모두 만들어 낸 코드입니다.
PR-MPPI(order 1)와 CAMP-MPPI(order 2)를 두 원고를 보고 다시 구현했습니다(원 저자 코드가 아닙니다).
노트의 통합 컨트롤러(Algorithm 1), 비교 기법, 노트의 정리와 명제를 수치로 확인하는 검증 스크립트가 함께 들어 있습니다.

## 폴더 구성

| 경로 | 내용 |
|---|---|
| `umppi/` | 라이브러리: 로봇 모델, 정확한 metric projection, 세 과제(writing, dual-arm, waiter), numpy와 GPU 컨트롤러, 비교 기법. 파일별 설명은 `umppi/README.md` |
| `umppi/tests/` | 단위 테스트: 모델 대 MuJoCo, projector, Theorem 2, GPU 대 numpy |
| `experiments/` | 실험 스크립트와 노트의 각 절을 만드는 스크립트(`fill_*.py`, `report_waiter.py`) |
| `experiments/results/` | 노트에 쓰인 결과 파일(JSON). 실험을 다시 돌리지 않아도 이것만으로 노트의 표와 본문 수치를 다시 만들 수 있습니다 |
| `tier2/verify/` | 노트의 정리와 명제를 확인하는 수치 검사 63개. 마지막 실행 기록은 `run_all.log` |
| `tier2/*.md` | 실기 실험 인수인계(`HARDWARE_HANDOFF.md`), waiter 실기 프로토콜(`HARDWARE.md`), 추가 분석 목록(`PENDING.md`) |

## 설치

Python 3.12에서 확인했습니다.

```
pip install -r requirements.txt
```

- GPU 컨트롤러(`umppi/warp_mppi.py`, `umppi/warp_writing.py`)에는 NVIDIA GPU, CUDA판 PyTorch, `warp-lang`이 필요합니다. waiter 실험의 기본 컨트롤러가 GPU 버전입니다.
- numpy 컨트롤러, writing과 dual-arm 실험, 검증 스크립트는 CPU만으로 돌아갑니다.
- CasADi는 Heins and Schoellig식 비교 기법(`umppi/robust_plan.py`)에만 씁니다.

## 빠른 확인

저장소 루트에서 실행합니다.

```
python -m umppi.tests.test_robot
python -m umppi.tests.test_qp
python -m umppi.tests.test_theorem2
python -m umppi.tests.test_dualarm
python -m umppi.tests.test_warp            # GPU 필요
python -m umppi.tests.test_warp_writing    # GPU 필요
```

노트의 수치 검사 63개는 `tier2/verify`에서 실행합니다(다른 작업이 없으면 1분 정도).

```
cd tier2/verify
python run_all.py
```

## 결과 파일로 노트의 절 다시 만들기

`experiments/`에서 실행합니다. 몇 초면 끝나고, `tier2/` 아래에 노트의 각 절(`.tex`)과 그림(`tier2/figs/`)이 생깁니다.

```
python summarize_writing.py
python plot_writing.py
python fill_writing_section.py
python summarize_dualarm.py
python fill_dualarm_section.py
python report_waiter.py
python fill_timing_section.py
python fill_baselines_section.py
```

## 실험 다시 돌리기

`experiments/`에서 실행합니다. 결과는 `experiments/results/`에 덮어씁니다.
옵션은 각 파일 첫머리의 docstring에 설명되어 있습니다.

| 노트의 절 | 순서대로 실행 | 결과 파일 |
|---|---|---|
| Writing | `writing_exp.py`, `camp_weight_check.py` | `writing.json`, `camp_weight_check.json` |
| Dual-arm | `dualarm_exp.py --calib-exec`, `dualarm_exp.py`, `dualarm_exp.py --safe` | `dualarm_exec_bound.json`, `dualarm.json` |
| Robust/adaptive waiter | `waiter_calibrate.py`, `waiter_calibrate.py --n-win 2`, `waiter_baselines.py --calib-exec`, `waiter_exp.py`, `waiter_inst_diag.py` | `waiter_bounds.json`, `waiter_bounds_w40.json`, `waiter_exec_bound.json`, `waiter.json`, `waiter_inst_diag.json` |
| Real-time | `gpu_timing.py` | `gpu_timing.json` |
| Baselines, waiter | `waiter_baselines.py` (기본, `--omega-sweep`, `--sweep`, `--ablation`, `--rawavg-tight`), `safe_baselines.py --tune`, `--sweep`, `--gs1`, `heins_baselines.py` | `waiter_baselines*.json`, `safe_baselines_*.json`, `heins_baselines.json` |
| Baselines, writing | `writing_baselines.py`, `safe_writing.py` | `writing_baselines.json`, `safe_writing.json` |
| Several binding rows | `corner_exp.py --calib`, `corner_exp.py`, `--rho-check`, `--diag` | `corner*.json` |

- 보정(calibration) 단계를 먼저 돌려야 합니다. 다른 실험이 그 결과 파일을 읽습니다.
- 병렬 프로세스 수는 `--procs`로 정합니다. 몇몇 스크립트의 기본값(24)은 연구실 워크스테이션 기준이니 컴퓨터에 맞게 줄이세요.
- 전체를 다시 돌리면 수 시간이 걸립니다.

## 선택: 영상

`render_waiter.py`, `render_writing.py`(먼저 `record_writing.py`), `render_dualarm.py`는 프로젝트 페이지 영상을 만든 스크립트입니다.
OpenGL이 되는 환경에서 `experiments/results/videos/`에 영상을 씁니다. 글꼴 경로가 Windows 기준입니다.

## 넣지 않은 것

심사 중인 두 원고의 PDF, 논문 초안, 옛 결과, 영상, 캐시, 로그, 일회성 점검 스크립트는 넣지 않았습니다.
병렬로 진행한 별도 baseline 연구의 코드도 빠져 있습니다.
