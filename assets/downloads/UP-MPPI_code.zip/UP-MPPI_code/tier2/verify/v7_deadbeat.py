"""Theorem 2(v) -- virtual-row error dynamics on the Franka-like arm model.

Model: Gauss dynamics with the pen-contact physical row, semi-implicit Euler, command
a = M-minimum-norm solution of the stabilised virtual row  J_v qdd + Jvdot qd = -K_D e_dot - K_P e
(pen axis vertical).  Initial tilt 3 deg and a nonzero tangential velocity (curvature forcing).
Checks: deadbeat gains K_P = 1/dt^2, K_D = 1/dt give a steady residual O(dt^2) (the transient
is governed by the correction velocity |e|/dt, so it is not O(dt^2)); moderate gains inside the
Jury region decay monotonically.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common import Report, loglog_slope  # noqa: E402
from umppi import writing as W_  # noqa: E402
from umppi.qp import project  # noqa: E402
from umppi.robot import Chain  # noqa: E402

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])


def simulate(dt, KP, KD, T=0.2):
    ch = Chain()
    q = W_.ik_on_surface(ch, W_.path_point(0.0)[0], Q_READY)
    # tilt the pen by ~3 deg about a horizontal axis via the wrist, and give a tangential velocity
    q = q.copy()
    q[5] += np.radians(3.0)
    k = W_.kin(ch, q[None], np.zeros((1, 7)))
    _, Jc, _, _ = W_.contact(k)
    t_dir = np.linalg.lstsq(k["Jv"][0], np.array([0.05, 0.02, 0.0]), rcond=None)[0]
    qd = t_dir - Jc[0].T @ np.linalg.solve(Jc[0] @ Jc[0].T, Jc[0] @ t_dir)  # tangent to the contact row
    errs = []
    for _ in range(int(round(T / dt))):
        k = W_.kin(ch, q[None], qd[None])
        M = ch.mass_matrix(q[None], k["R"], k["o"])
        Mi = np.linalg.inv(M)
        _, Jc, jcd, _ = W_.contact(k)
        Lam = 1.0 / (Jc @ Mi @ np.swapaxes(Jc, 1, 2))
        F = np.eye(7) - Mi @ np.swapaxes(Jc, 1, 2) @ Lam @ Jc
        f = -(Mi @ np.swapaxes(Jc, 1, 2) @ Lam @ jcd[..., None])[..., 0]
        e, Jo, jod = W_.orientation(k)
        edot = (Jo @ qd[None, :, None])[..., 0]
        rhs = -KD * edot - KP * e - (Jo @ f[..., None])[..., 0] - jod
        a = project(np.zeros((1, 7)), M, Jo @ F, rhs)[0]
        qdd = F[0] @ a + f[0]
        qd = qd + dt * qdd
        q = q + dt * qd
        errs.append(np.linalg.norm(W_.orientation(W_.kin(ch, q[None], qd[None]))[0][0]))
    return np.array(errs)


def main():
    rep = Report("Thm 2(v) virtual rows")
    dts = np.array([0.02, 0.01, 0.005, 0.0025])
    steady = []
    for dt in dts:
        e = simulate(dt, 1 / dt ** 2, 1 / dt, T=0.3)
        steady.append(np.mean(e[len(e) // 2:]))
    steady = np.array(steady)
    s = loglog_slope(dts, steady)
    rep.check("deadbeat gains: steady residual is O(dt^2)", abs(s - 2) < 0.2,
              f"|e| {np.array2string(steady, precision=2)}  slope {s:.2f}")
    e = simulate(0.01, 100.0, 20.0, T=0.6)
    mono = np.all(np.diff(e) <= 1e-12)
    rep.check("moderate gains (K_D dt=0.2, K_P dt^2=0.01): monotone decay", mono and e[-1] < 0.05 * e[0],
              f"|e| {e[0]:.1e} -> {e[-1]:.1e} over 0.6 s")
    return rep


if __name__ == "__main__":
    main()
