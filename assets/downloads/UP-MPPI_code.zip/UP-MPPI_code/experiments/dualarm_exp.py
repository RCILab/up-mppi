"""Dual-arm closed chain (PR-MPPI Exp. 1 analogue) and a right-base calibration-error sweep.

E1  joint-limit stress test, no calibration error: PR-MPPI full / without retraction / without
    inequality projection (cost penalty instead), and the unified order-2 controller.
E2  calibration error delta_b of the right-arm base (model only, along y): PR-MPPI, PR-MPPI
    anchored (Prop. 7) and the unified controller.  Prediction (Prop. 2(b) for the chain):
    W_int = (C_l + C_r + 2 C_g)^-1 [delta_b; 0], C = operational compliances of the two
    interpolated computed-torque loops and of the grasp springs.
"""
import argparse
import json
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import mujoco
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import dualarm as DA  # noqa: E402
from umppi.dualtask import DualTask, configurations  # noqa: E402
from umppi.generic import CAMP2, PR1  # noqa: E402
from umppi.physics_dual import DualPhysics  # noqa: E402

DT, H, K = 0.02, 15, 256
T_RUN = 6.0
# execution-error bound of the joint accelerations (period average, per joint): calibrated by --calib-exec
EXEC_FILE = Path(__file__).resolve().parent / "results" / "dualarm_exec_bound.json"
EPS_Q = np.array(json.loads(EXEC_FILE.read_text())["eps_qdd_joint"]) if EXEC_FILE.exists() else 0.0  # per joint


def controller(name, task):
    common = dict(dt=DT, H=H, K=K)
    if name == "PR":
        return PR1(task, sigma=0.05, retract="all", **common)
    if name == "PR-anchored":
        return PR1(task, sigma=0.05, retract="anchored", **common)
    if name == "PR-noretract":
        return PR1(task, sigma=0.05, retract="none", **common)
    if name == "PR-noineq":
        return PR1(task, sigma=0.05, retract="all", inequality=False, **common)
    if name == "PR-noineq-Mretract":
        return PR1(task, sigma=0.05, retract="all", inequality=False, retract_metric="M", **common)
    if name == "PR-noineq-anchored":
        return PR1(task, sigma=0.05, retract="anchored", inequality=False, **common)
    if name == "PR-Mretract":
        return PR1(task, sigma=0.05, retract="all", retract_metric="M", **common)
    if name in ("Shield", "DualGuard", "GS"):  # safe-MPPI methods from the literature (umppi/safe_mppi.py), eps = 0
        from umppi.safe_mppi import DualGuardMPPI, GSMPPI, ShieldMPPI
        cls = {"Shield": ShieldMPPI, "DualGuard": DualGuardMPPI, "GS": GSMPPI}[name]
        prm = {"Shield": {"C": 1e3}, "DualGuard": {}, "GS": {"rho": 20.0}}[name]
        return cls(task, sigma=0.8, **prm, **common)
    if name in ("Unified", "Unified-eps0"):  # Algorithm 1; eps0: joint rows not tightened (calibration, ablation)
        return CAMP2(task, sigma=0.8, solver="separable", virtual="hard", average="raw", noise_clip=3.0,
                     eps_motion=EPS_Q if name == "Unified" else 0.0, **common)
    raise KeyError(name)


def run(name, delta_b_mm, seed=0, T=T_RUN, rec=None):
    true_arms = DA.make_arms()
    model_arms = DA.make_arms(right_base_offset=np.array([0.0, delta_b_mm * 1e-3, 0.0]))
    q_start, _ = configurations(true_arms)
    _, q_goal_model = configurations(model_arms)
    grasp = DA.grasp_from(true_arms, q_start)  # nominal grasp (CAD)
    q4_min = min(q_goal_model[3], q_goal_model[10]) + 0.06
    task = DualTask(model_arms, grasp, q_goal_model, q4_min, penalty=name.startswith("PR-noineq"),
                    lam_box=(1.0, 5.0) if name == "Unified" else None)
    ctrl = controller(name, task)
    ctrl.rng = np.random.default_rng(seed)
    phys = DualPhysics(true_arms, q_start)
    order = 1 if isinstance(ctrl, PR1) else 2
    true_task = DualTask(true_arms, grasp, q_goal_model, q4_min)
    logs = dict(W_int=[], q=[], cmd_model=[], cmd_true=[], meas=[], tilt=[], lam=[], dev_qdd=[])
    diverged_t = None
    t_wall = time.perf_counter()
    for step in range(int(round(T / DT))):
        t_now = step * DT
        q0, qd0 = phys.q, phys.qd
        try:
            cmd = ctrl.plan(q0, qd0, t_now)
        except (ValueError, np.linalg.LinAlgError):
            diverged_t = t_now
            break
        if order == 1:
            qp = cmd["q_plus"]
            for tk, key in ((task, "cmd_model"), (true_task, "cmd_true")):
                Kc = tk.kin(qp[None], np.zeros((1, 14)))
                c = np.concatenate([tk.phys(Kc)[0][0], tk.virt(Kc)[0][0]])
                logs[key].append(c)
            L = phys.step_order1(q0, qp, DT)
        else:
            logs["lam"].append(cmd["lam_cmd"])
            mdl0 = ctrl._model(q0[None], qd0[None])
            qdd_model = mdl0["F"][0] @ cmd["a"] + mdl0["f"][0]
            L = phys.step_order2(cmd["a"], DT)
            if t_now >= 0.1:  # period-averaged joint acceleration against the model, per joint
                logs["dev_qdd"].append(np.abs((phys.qd - qd0) / DT - qdd_model))
        Km = true_task.kin(phys.q[None], np.zeros((1, 14)))
        logs["meas"].append(np.concatenate([true_task.phys(Km)[0][0], true_task.virt(Km)[0][0]]))
        logs["W_int"].append(np.mean([l["W_int"] for l in L], 0))
        logs["q"].append(phys.q)
        logs["tilt"].append(np.degrees(np.arccos(np.clip(L[-1]["tray_R"][2, 2], -1, 1))))
        if rec is not None:
            rec.setdefault("qpos", []).append(phys.d.qpos.copy())
            rec.setdefault("W_int", []).append(logs["W_int"][-1])
        if phys.d.warning[mujoco.mjtWarning.mjWARN_BADQACC].number > 0 or not np.all(np.isfinite(phys.q)):
            diverged_t = t_now + DT
            break
    q = np.array(logs["q"])
    W = np.array(logs["W_int"])
    meas = np.array(logs["meas"])
    settle = min(len(W) - 1, int(1.0 / DT))
    res = dict(
        controller=name, delta_b_mm=delta_b_mm, seed=seed, diverged_t=diverged_t, q4_min=q4_min,
        bound_viol=float(max(0.0, np.max(q4_min - q[:, [3, 10]]))),
        margin_pen=float(max(0.0, np.max(q4_min + 0.05 - q[:, [3, 10]]))),
        goal_err=float(np.max(np.abs(q[-1] - q_goal_model))),
        W_int_y_mean=float(np.mean(W[settle:, 1])), W_int_norm_max=float(np.max(np.linalg.norm(W[:, :3], axis=1))),
        W_int_norm_mean=float(np.mean(np.linalg.norm(W[settle:, :3], axis=1))),
        Tq_int_norm_mean=float(np.mean(np.linalg.norm(W[settle:, 3:], axis=1))),
        meas_chain_trans_mm=1e3 * float(np.mean(np.linalg.norm(meas[:, 3:6], axis=1))),
        meas_chain_rot_mrad=1e3 * float(np.mean(np.linalg.norm(meas[:, 0:3], axis=1))),
        meas_tilt_deg=float(np.mean(logs["tilt"])),
        cmd_model_max=float(np.max(np.abs(np.array(logs["cmd_model"])))) if logs["cmd_model"] else None,
        cmd_true_trans_mm=(1e3 * float(np.mean(np.linalg.norm(np.array(logs["cmd_true"])[:, 3:6], axis=1)))
                           if logs["cmd_true"] else None),
        lam_cmd_max=float(np.max(np.abs(np.array(logs["lam"])))) if logs["lam"] else None,
        ms_per_step=1e3 * float(np.mean(ctrl.stats["time"])), relaxed=ctrl.stats["relaxed"],
        dev_qdd_max=float(np.max(logs["dev_qdd"])) if logs["dev_qdd"] else None,
        dev_qdd_joint_max=np.max(logs["dev_qdd"], 0).tolist() if logs["dev_qdd"] else None,
        eps_qdd=(np.asarray(EPS_Q).tolist() if name == "Unified" else (0.0 if name == "Unified-eps0" else None)),
        wall_s=time.perf_counter() - t_wall,
    )
    return res, W


def predicted_internal_force(delta_b_mm, omega=2 * np.pi * 10, K_t=3.0e4, K_r=300.0):
    """Series compliance of the two interpolated computed-torque loops and the two grasp springs."""
    arms = DA.make_arms()
    q_start, _ = configurations(arms)
    C = 2 * np.diag([1 / K_t] * 3 + [1 / K_r] * 3)
    for i, arm in enumerate(arms):
        qi = q_start[None, 7 * i:7 * i + 7]
        Jv, Jw, _ = arm.jacobian(qi)
        J6 = np.concatenate([Jv[0], Jw[0]], 0)
        Keff = arm.mass_matrix(qi)[0] * (omega ** 2 / 2 + 2 * omega / DT)
        C += J6 @ np.linalg.solve(Keff, J6.T)
    W = np.linalg.solve(C, np.array([0.0, delta_b_mm * 1e-3, 0.0, 0.0, 0.0, 0.0]))
    return W  # internal wrench (force, torque) for a relative translation of delta_b along y


def _job(a):
    name, dl, seed = a
    try:
        r, W = run(name, dl, seed)
    except Exception as exc:
        return {"controller": name, "delta_b_mm": dl, "seed": seed, "error": repr(exc)}, []
    return r, W[:, :3].tolist()


if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", default="all")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--procs", type=int, default=24)
    ap.add_argument("--only", nargs="*", default=None, help="rerun these controllers and merge into dualarm.json")
    ap.add_argument("--calib-exec", action="store_true", help="calibrate the joint-acceleration bound (seeds 100, 101)")
    ap.add_argument("--safe", action="store_true", help="the safe-MPPI methods at delta_b = 0, merged into dualarm.json")
    args = ap.parse_args()
    if args.safe:
        args.only = ["Shield", "DualGuard", "GS"]
        args.exp = "safe"
    if args.calib_exec:
        jobs = [("Unified-eps0", dl, s) for dl in (0.0, 2.0) for s in (100, 101)]
        with Pool(min(args.procs, len(jobs))) as pool:
            res = [r for r, _ in pool.imap_unordered(_job, jobs)]
        dev = max(r["dev_qdd_max"] for r in res)
        devj = np.max([r["dev_qdd_joint_max"] for r in res], 0)
        EXEC_FILE.write_text(json.dumps({"eps_qdd_joint": (1.5 * devj).tolist(), "dev_joint_max": devj.tolist(),
                                         "eps_qdd": 1.5 * dev, "dev_max": dev, "margin": 1.5,
                                         "per_run": {f"{r['delta_b_mm']}|{r['seed']}": r["dev_qdd_max"] for r in res},
                                         "bound_viol": {f"{r['delta_b_mm']}|{r['seed']}": r["bound_viol"] for r in res}}, indent=1))
        print("eps_qdd", 1.5 * dev, {f"{r['delta_b_mm']}|{r['seed']}": round(r["dev_qdd_max"], 4) for r in res})
        raise SystemExit
    jobs = []
    if args.exp in ("all", "E1"):
        jobs += [(nm, 0.0, s) for nm in ("PR", "PR-noretract", "PR-noineq", "Unified", "Unified-eps0") for s in range(args.seeds)]
    if args.exp == "safe":
        jobs += [(nm, 0.0, s) for nm in ("Shield", "DualGuard", "GS") for s in range(args.seeds)]
    if args.exp in ("all", "E2"):
        jobs += [(nm, dl, s) for nm in ("PR", "PR-anchored", "Unified", "Unified-eps0") for dl in (0.5, 1.0, 2.0)
                 for s in range(args.seeds)]
    out = Path(__file__).resolve().parent / "results" / "dualarm.json"
    rows, traces = [], {}
    if args.only:
        jobs = [j for j in jobs if j[0] in args.only]
        old = json.loads(out.read_text())
        rows = [r for r in old["rows"] if r["controller"] not in args.only]
        traces = {k: v for k, v in old["traces"].items() if k.split("|")[0] not in args.only}
    with Pool(args.procs) as pool:
        for r, tr in pool.imap_unordered(_job, jobs):
            rows.append(r)
            traces[f"{r['controller']}|{r['delta_b_mm']}|{r['seed']}"] = tr
            print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()}), flush=True)
            out.write_text(json.dumps({"rows": rows, "traces": traces,
                                       "pred": {str(d): predicted_internal_force(d).tolist() for d in (0.5, 1.0, 2.0)}}))
