"""Corner scenario on the waiter: several support rows bind at the same time.

A low-friction box (mu = 0.12, prior [0.10, 0.15]) makes the slip rows bind together with the tipping rows, and a
diagonal move at 67.5 deg from the tray axes points at a vertex of both octagons, so two tipping and two slip rows
are active at once; the move takes 0.6 s instead of 0.8 s.  An exact projection onto the polyhedron lands on that
vertex; a single soft-min composite (GS-MPPI) blends the active rows into one half-space.

--calib   execution-error bound for this scenario (oracle, raw average, untightened; h in {0.05, 0.115, 0.18},
          seeds 100 and 101), written to results/corner_exec_bound.json
(default) the controllers at h = 0.14 m, 5 seeds, with the rows as they are and tightened by that bound
--rho-check  GS-MPPI with rho = 1000 (5 and 20 applications of the law) and rho = 100 with 20 applications
--diag       one-step GS-MPPI, tightened rows, seed 0: the rows violated at every plan before and after the law;
             GS-MPPI to convergence against the exact projection at the same states (the rows active at each);
             DualGuard MPPI, seed 0: the fraction of replaced samples and the overshoot of the first target
Writes results/corner.json (results/corner_rho.json, corner_gs1_diag.json, corner_vertex_diag.json,
corner_dg_diag.json).
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

HERE = Path(__file__).resolve().parent
EXEC = HERE / "results" / "corner_exec_bound.json"
THETA, LENGTH, T_MOVE = np.deg2rad(67.5), 0.4, 0.6
MU_TRUE, MU_PRIOR = 0.12, (0.10, 0.15)
KEYS = ("tipped", "t_tip", "rmse1", "rmse2", "reach1", "reach2", "peak_ah", "oct_model_max", "slip_model_max",
        "cop_true_max", "dev_max", "box_shift_mm", "ms_per_step", "h_true", "seed")


def setup():
    """Install the scenario in this process (the workers re-import the modules)."""
    import waiter_exp as X
    from umppi import waiter as WT
    A = np.array([0.45, -0.20, 0.35])
    WT.A_PT, WT.B_PT = A, A + LENGTH * np.array([np.cos(THETA), np.sin(THETA), 0.0])
    WT.T_MOVE = T_MOVE
    WT.T_RUN = 2 * (WT.T_MOVE + WT.T_HOLD) + WT.T0
    X.T_MOVE2 = WT.T0 + WT.T_MOVE + WT.T_HOLD
    X.TRUE["mu"] = MU_TRUE
    X.PRIOR_MU = MU_PRIOR
    return X, WT


def _job(a):
    label, name, h, seed, eps = a
    import warnings
    warnings.filterwarnings("ignore")
    X, WT = setup()
    from umppi.safe_mppi import DualGuardMPPI, GSMPPI, ShieldMPPI
    from umppi.warp_mppi import WarpWaiterMPPI
    if label.startswith("alg1") or label.startswith("oracle") or label.startswith("projected"):
        avg = "projected" if label.startswith("projected") else "raw"
        fac = lambda task: WarpWaiterMPPI(task.chain, task, K=X.K, H=X.H, dt=X.DT, sigma=1.0, average=avg)  # noqa: E731
    else:
        method, *prm = label.split("@")
        kw = {k: float(v) for k, v in (p.split("=") for p in prm)}
        if "iters" in kw:
            kw["iters"] = int(kw["iters"])
        cls = {"shield": ShieldMPPI, "dualguard": DualGuardMPPI, "gs": GSMPPI}[method]
        fac = lambda task: cls(task, sigma=1.0, dt=X.DT, H=X.H, K=X.K, **kw)  # noqa: E731
    try:
        r, _ = X.run(name, seed, h, T=WT.T_RUN, controller_factory=fac, eps_exec=eps)
    except Exception as exc:
        return {"label": label, "eps": eps, "h_true": h, "seed": seed, "error": repr(exc)}
    out = {k: r[k] for k in KEYS}
    out.update(label=label, eps=eps)
    return out


def diag(seed=0):
    """One-step GS-MPPI with the tightened rows: at every plan, the rows violated by the executed command before the
    safe law and after 1, 2 and 5 applications of it, and how many rows lie within 1/rho of the smallest margin."""
    import warnings
    warnings.filterwarnings("ignore")
    X, WT = setup()
    from umppi.safe_mppi import GSMPPI
    rec = []

    class Diag(GSMPPI):
        def _output(self, q0, qd0, u0, mdl0):
            a_eq = self._eq_proj(q0[None], qd0[None], u0[None], mdl0)
            om0, _ = self._margins(q0[None], qd0[None], a_eq, mdl0)
            after = {}
            for it in (1, 2, 5):
                self.iters = it
                om, _ = self._margins(q0[None], qd0[None], self._filter(q0[None], qd0[None], a_eq, mdl0), mdl0)
                after[it] = dict(n_viol=int(np.sum(om[0] < -1e-9)), min=float(om.min()))
            self.iters = 1
            rec.append(dict(t=float(self.task.t_now), n_viol0=int(np.sum(om0[0] < -1e-9)), min0=float(om0.min()),
                            n_near=int(np.sum(om0[0] - om0[0].min() < 1.0 / self.rho)), after=after))
            return super()._output(q0, qd0, u0, mdl0)

    eps = json.loads(EXEC.read_text())["eps_exec"]
    fac = lambda task: Diag(task, sigma=1.0, dt=X.DT, H=X.H, K=X.K, rho=20.0, iters=1)  # noqa: E731
    r, _ = X.run("robust", seed, 0.14, T=WT.T_RUN, controller_factory=fac, eps_exec=eps)
    out = dict(seed=seed, eps=eps, slip_model_max=r["slip_model_max"], oct_model_max=r["oct_model_max"], plans=rec)
    (HERE / "results" / "corner_gs1_diag.json").write_text(json.dumps(out))
    bad = [d for d in rec if d["after"][1]["n_viol"]]
    print(len(rec), "plans,", len(bad), "violated after one application; max rows violated before",
          max(d["n_viol0"] for d in rec), "after 1/2/5:", [max(d["after"][k]["n_viol"] for d in rec) for k in (1, 2, 5)])


def diag_vertex(seed=0):
    """GS-MPPI applied until the composite holds (rho = 1000, up to 20 applications) against the exact M-metric
    projection of the same raw mean onto the same (tightened) rows, at every plan where the raw mean violates them:
    the rows active at each output and the M-distance each moves the command."""
    import warnings
    warnings.filterwarnings("ignore")
    X, WT = setup()
    from umppi.safe_mppi import GSMPPI
    rec = []

    class Diag(GSMPPI):
        def _output(self, q0, qd0, u0, mdl0):
            Q, QD = q0[None], qd0[None]
            a_eq = self._eq_proj(Q, QD, u0[None], mdl0)
            om0, _ = self._margins(Q, QD, a_eq, mdl0)
            if om0.min() < -1e-6:
                a_gs, a_pi = self._filter(Q, QD, a_eq, mdl0)[0], self._pi(Q, QD, u0[None], mdl0)[0]
                og, op = (self._margins(Q, QD, a[None], mdl0)[0][0] for a in (a_gs, a_pi))
                viol = om0[0] < -1e-6
                dM = lambda a: float(np.sqrt((a - a_eq[0]) @ mdl0["M"][0] @ (a - a_eq[0])))  # noqa: E731
                rec.append(dict(t=float(self.task.t_now), dist_gs=dM(a_gs), dist_pi=dM(a_pi),
                                act_gs=int(np.sum(np.abs(og) < 1e-3)), act_pi=int(np.sum(np.abs(op) < 1e-3)),
                                second_gs=float(np.sort(og[viol])[1]) if viol.sum() > 1 else None,
                                second_pi=float(np.sort(op[viol])[1]) if viol.sum() > 1 else None))
            return super()._output(q0, qd0, u0, mdl0)

    eps = json.loads(EXEC.read_text())["eps_exec"]
    fac = lambda task: Diag(task, sigma=1.0, dt=X.DT, H=X.H, K=X.K, rho=1000.0, iters=20)  # noqa: E731
    X.run("robust", seed, 0.14, T=WT.T_RUN, controller_factory=fac, eps_exec=eps)
    (HERE / "results" / "corner_vertex_diag.json").write_text(json.dumps(dict(seed=seed, eps=eps, plans=rec)))
    v = [d for d in rec if d["act_pi"] >= 2]
    print(len(rec), "plans with a violated raw mean,", len(v), "with the projection on a vertex; there GS had",
          np.bincount([d["act_gs"] for d in v]), "active rows, second margin up to", max(d["second_gs"] for d in v))


def diag_dualguard(seed=0):
    """DualGuard MPPI, rows as they are: the fraction of samples its filter replaces, and how far the tray passes
    the first target (the distance beyond it along the move while it should hold there)."""
    import warnings
    warnings.filterwarnings("ignore")
    X, WT = setup()
    from umppi.safe_mppi import DualGuardMPPI
    frac = []

    class Diag(DualGuardMPPI):
        def _filter(self, q, qd, a, mdl):
            if q.shape[0] > 1 and mdl["ex"] is not None:
                frac.append(float(np.any(self._input_viol(q, qd, a, mdl) > 0, 1).mean()))
            return super()._filter(q, qd, a, mdl)

    fac = lambda task: Diag(task, sigma=1.0, dt=X.DT, H=X.H, K=X.K)  # noqa: E731
    r, log = X.run("robust", seed, 0.14, T=WT.T_RUN, controller_factory=fac, eps_exec=0.0)
    t, p = np.array(log["t"]), np.array(log["p"])
    u = (WT.B_PT - WT.A_PT) / np.linalg.norm(WT.B_PT - WT.A_PT)
    hold = (t >= WT.T0 + WT.T_MOVE) & (t < X.T_MOVE2)
    out = dict(seed=seed, rmse1=r["rmse1"], rmse2=r["rmse2"], reach1=r["reach1"], reach2=r["reach2"],
               switched_mean=float(np.mean(frac)), switched_max=float(np.max(frac)),
               overshoot_mm=1e3 * float(np.max((p[hold] - WT.B_PT) @ u)))
    (HERE / "results" / "corner_dg_diag.json").write_text(json.dumps(out, indent=1))
    print(out)


def run_jobs(jobs, out, procs):
    rows = []
    with Pool(procs) as pool:
        for r in pool.imap_unordered(_job, jobs):
            rows.append(r)
            print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}, default=float), flush=True)
            out.write_text(json.dumps({"rows": rows}, default=float))
    return rows


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--calib", action="store_true")
    ap.add_argument("--rho-check", action="store_true", help="GS-MPPI with a sharper soft-min and more applications")
    ap.add_argument("--diag", action="store_true", help="rows violated by one-step GS-MPPI, per plan")
    ap.add_argument("--procs", type=int, default=6)
    args = ap.parse_args()
    if args.diag:
        diag()
        diag_vertex()
        diag_dualguard()
        raise SystemExit
    if args.rho_check:
        eps = json.loads(EXEC.read_text())["eps_exec"]
        labels = ("gs@rho=1000", "gs@rho=1000@iters=20", "gs@rho=100@iters=20")
        run_jobs([(lab, "robust", 0.14, s, e) for e in (0.0, eps) for lab in labels for s in range(5)],
                 HERE / "results" / "corner_rho.json", args.procs)
        raise SystemExit
    if args.calib:
        rows = run_jobs([("oracle", "oracle", h, s, 0.0) for h in (0.05, 0.115, 0.18) for s in (100, 101)],
                        HERE / "results" / "corner_calib.json", args.procs)
        dev = max(r["dev_max"] for r in rows if "error" not in r)
        EXEC.write_text(json.dumps({"eps_exec": 1.5 * dev, "dev_max": dev}, indent=1))
        print("eps_exec", 1.5 * dev)
        raise SystemExit
    eps = json.loads(EXEC.read_text())["eps_exec"]
    labels = [("alg1", "robust"), ("projected", "robust"), ("oracle", "oracle"), ("gs@rho=20", "robust"),
              ("gs@rho=100", "robust"), ("gs@rho=20@iters=1", "robust"), ("shield@C=1000", "robust"),
              ("dualguard", "robust")]
    jobs = [(lab, nm, 0.14, s, e) for e in (0.0, eps) for lab, nm in labels for s in range(5)]
    jobs.sort(key=lambda j: not (j[0].startswith("alg1") or j[0].startswith("projected") or j[0].startswith("oracle")))
    run_jobs(jobs, HERE / "results" / "corner.json", args.procs)
