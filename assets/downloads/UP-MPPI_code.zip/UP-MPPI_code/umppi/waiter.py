"""Waiter task (Tier 1(a)): a tall passive box on a tray, carried fast, with uncertain COM height
and friction.  Robust support-wrench rows over the vertices of the parameter box, and an
online set-membership estimate that shrinks the box while keeping the certificate.

Object: square base of half-width R_BASE; COM height h above the base; friction mu; mass m.
With the tray level (virtual rows) and s = a_b - g the base acceleration relative to gravity:
  no tipping   h |s_h| <= R_BASE s_z          (inscribed disk, 8-sided inner polygon)
  no slipping  |s_h|   <= mu s_z
  no lift-off  s_z >= S_MIN
Each row is affine in (h, mu) for fixed command, so the robust set is the intersection over the
vertices of the parameter box (Prop. R1 of the note).
Measurements (sticking object): F = m s,  tau_base = (m h) z x s  ->  interval bounds on m and m h.
"""
import mujoco
import numpy as np

from .mjcf import _fmt, scene_xml
from .robot import Q_MAX, Q_MIN, QD_MAX, Chain, cross, mv

R_BASE, HALF_H = 0.02, 0.12
B_LOCAL = np.array([0.15, 0.0, 0.167])  # object base point in the link-7 frame (tray surface)
S_MIN = 3.0
N_DIR = 8
DIRS = np.stack([np.cos(2 * np.pi * np.arange(N_DIR) / N_DIR), np.sin(2 * np.pi * np.arange(N_DIR) / N_DIR)], 1)
C8 = np.cos(np.pi / N_DIR)  # inner polygon of the cone
G = np.array([0.0, 0.0, -9.81])
A_PT, B_PT = np.array([0.45, -0.20, 0.35]), np.array([0.45, 0.20, 0.35])
T0, T_MOVE, T_HOLD = 0.3, 0.8, 1.2
T_RUN = 2 * (T_MOVE + T_HOLD) + T0


def make_chain():
    return Chain(tool=B_LOCAL.copy(), tool_mass=0.2)


def quintic(s):
    s = np.clip(s, 0.0, 1.0)
    return 10 * s ** 3 - 15 * s ** 4 + 6 * s ** 5


def quintic_d(s):
    inside = (s > 0.0) & (s < 1.0)
    return np.where(inside, 30 * s ** 2 - 60 * s ** 3 + 30 * s ** 4, 0.0)


def target(t):
    """A -> B (move 1), hold, B -> A (move 2), hold."""
    t = np.atleast_1d(t)
    s1 = quintic((t - T0) / T_MOVE)
    s2 = quintic((t - T0 - T_MOVE - T_HOLD) / T_MOVE)
    return A_PT + (B_PT - A_PT) * (s1 - s2)[:, None]


def quintic_dd(s):
    inside = (s > 0.0) & (s < 1.0)
    return np.where(inside, 60 * s - 180 * s ** 2 + 120 * s ** 3, 0.0)


def target_acc(t):
    t = np.atleast_1d(t)
    d1 = quintic_dd((t - T0) / T_MOVE)
    d2 = quintic_dd((t - T0 - T_MOVE - T_HOLD) / T_MOVE)
    return (B_PT - A_PT) * ((d1 - d2) / T_MOVE ** 2)[:, None]


def target_vel(t):
    t = np.atleast_1d(t)
    d1 = quintic_d((t - T0) / T_MOVE)
    d2 = quintic_d((t - T0 - T_MOVE - T_HOLD) / T_MOVE)
    return (B_PT - A_PT) * ((d1 - d2) / T_MOVE)[:, None]


def ik(chain, p, q_init, iters=300):
    """Tray point at p, tool z pointing down, tool x along world x."""
    q = q_init.copy()[None]
    for _ in range(iters):
        R, o = chain.fk(q)
        Jv, Jw, pt = chain.jacobian(q, R=R, o=o)
        z, x = R[0, -1][:, 2], R[0, -1][:, 0]
        err = np.concatenate([pt[0] - p, z - np.array([0, 0, -1.0]), [x[1]]])
        Jz = -np.cross(z[None].repeat(7, 0), Jw[0].T).T
        Jx = -np.cross(x[None].repeat(7, 0), Jw[0].T).T
        J = np.concatenate([Jv[0], Jz, Jx[1:2]], 0)
        q = q - (J.T @ np.linalg.solve(J @ J.T + 1e-6 * np.eye(7), err))[None]
        if np.linalg.norm(err) < 1e-12:
            break
    return q[0]


def torque_bound(eps_t, m_hi, d_max, S, Tw):
    """Bound on the torque-impulse error: noise and model error eps_t, plus the moment m d x S of the
    load about an unknown offset |d| <= d_max of the box on the tray (m <= m_hi)."""
    return eps_t * Tw + m_hi * d_max * float(np.linalg.norm(S))


class SetMembership:
    """Interval bounds on m and phi = m h from bounded-error impulse measurements over a window Tw:
    Y_F = m S + v_F and Y_tau = phi (n x S) + v_tau, with S = dv_B - g Tw the tray-point velocity
    change relative to gravity, |v_F| <= eps_f Tw and |v_tau| <= torque_bound(...) componentwise.
    An empty intersection invalidates the model; the update is then rejected and counted."""

    def __init__(self, m_box=(0.2, 1.5), h_box=(0.05, 0.18), eps_f=0.2, eps_t=0.005, d_max=0.002):
        self.m = list(m_box)
        self.phi = [m_box[0] * h_box[0], m_box[1] * h_box[1]]
        self.h_prior = list(h_box)
        self.eps_f, self.eps_t, self.d_max = eps_f, eps_t, d_max
        self.n_invalid = 0

    def update(self, YF, YT, S, n, Tw):
        ef = self.eps_f * Tw
        (m_lo, m_hi), (p_lo, p_hi) = self.m, self.phi
        for i in range(3):
            if abs(S[i]) > 0.5 * Tw:
                lo, hi = sorted([(YF[i] - ef) / S[i], (YF[i] + ef) / S[i]])
                m_lo, m_hi = max(m_lo, lo), min(m_hi, hi)
        et = torque_bound(self.eps_t, m_hi, self.d_max, S, Tw)  # m_hi of this update still bounds the true m
        nS = cross(n, S)
        for i in range(3):
            if abs(nS[i]) > 0.3 * Tw:
                lo, hi = sorted([(YT[i] - et) / nS[i], (YT[i] + et) / nS[i]])
                p_lo, p_hi = max(p_lo, lo), min(p_hi, hi)
        if m_lo > m_hi or p_lo > p_hi:
            self.n_invalid += 1
            return False
        self.m, self.phi = [m_lo, m_hi], [p_lo, p_hi]
        return True

    @property
    def h(self):
        lo = max(self.h_prior[0], self.phi[0] / self.m[1])
        hi = min(self.h_prior[1], self.phi[1] / self.m[0])
        return [lo, max(lo, hi)]


class COPDifference:
    """Interval of h from centre-of-pressure differences between windows; needs no box position.

    For a sticking box and window impulses Y_F, Y_tau (torque about the tray point B), with
    S = dv_B - g Tw the tray-point velocity change relative to gravity,
        p_c = (n x Y_tau) / (n . Y_F) = d - h S_t / S_n,
    where d is the (unknown, creeping) position of the box on the tray.  Two windows j, k give
        p_c(k) - p_c(j) = -h (q_k - q_j) + (d_k - d_j),   q = S_t / S_n (from kinematics, exact),
    linear in h, with |d_k - d_j| <= d0 + rho_d (t_k - t_j + Tw) and the COP error of each window
    bounded from the force and torque bounds by the quotient bound."""

    def __init__(self, h_box=(0.05, 0.18), eps_f=0.2, eps_t=0.005, d0=1e-4, rho_d=4e-3, span=0.6, q_min=0.02):
        self.h, self.h_prior = list(h_box), list(h_box)
        self.eps_f, self.eps_t, self.d0, self.rho_d, self.span, self.q_min = eps_f, eps_t, d0, rho_d, span, q_min
        self.buf, self.n_invalid = [], 0

    def cop(self, YF, YT, S, n, t1, t2, Tw):
        """Measured COP (tray axes), its error bound, and q = S_t / S_n; None without load."""
        eF = self.eps_f * Tw * float(np.abs(n).sum())
        Fn = float(YF @ n)
        if Fn - eF <= 0.5 * Tw:
            return None
        pc3 = cross(n, YT) / Fn
        pc = np.array([pc3 @ t1, pc3 @ t2])
        et = self.eps_t * Tw * np.array([np.abs(cross(t1, n)).sum(), np.abs(cross(t2, n)).sum()])
        ec = (et + np.abs(pc) * eF) / (Fn - eF)
        Sn = float(S @ n)
        St = S - Sn * n
        return pc, ec, np.array([St @ t1, St @ t2]) / Sn

    def update(self, t, YF, YT, S, n, t1, t2, Tw):
        m = self.cop(YF, YT, S, n, t1, t2, Tw)
        if m is None:
            return True
        pc, ec, q = m
        lo, hi = self.h
        self.buf = [b for b in self.buf if t - b[0] <= self.span]
        for tj, pcj, ecj, qj in self.buf:
            dq, dp = q - qj, pc - pcj
            bound = ec + ecj + self.d0 + self.rho_d * (t - tj + Tw)
            for i in range(2):
                if abs(dq[i]) >= self.q_min:
                    a, b = sorted([(-dp[i] - bound[i]) / dq[i], (-dp[i] + bound[i]) / dq[i]])
                    lo, hi = max(lo, a), min(hi, b)
        self.buf.append((t, pc, ec, q))
        if lo > hi:
            self.n_invalid += 1
            return False
        self.h = [lo, hi]
        return True


class RLSEstimate:
    """Certainty-equivalence baseline (B1): recursive least squares on the same windowed impulses.

    Y_F = m S and Y_tau = phi (n x S) + psi_1 (t1 x S) + psi_2 (t2 x S), with phi = m h and
    psi = m d the unknown offset of the box on the tray (so the estimator uses the same information
    as the COP differences).  The rows then use the point estimate h = phi / m, with no margin."""

    def __init__(self, m0=0.85, h0=0.115, h_box=(0.05, 0.18), var_m=0.4 ** 2, var_phi=0.07 ** 2, var_psi=1e-3 ** 2,
                 sig_f=0.1, sig_t=0.003):
        self.m, self.Pm = m0, var_m
        self.th = np.array([m0 * h0, 0.0, 0.0])
        self.P = np.diag([var_phi, var_psi, var_psi])
        self.h_prior = list(h_box)
        self.sig_f, self.sig_t = sig_f, sig_t
        self.n_invalid = 0

    def update(self, t, YF, YT, S, n, t1, t2, Tw):
        rf = (self.sig_f * Tw) ** 2  # measurement variance of an impulse component (per window)
        for i in range(3):  # scalar RLS on m
            s = S[i]
            k = self.Pm * s / (s * self.Pm * s + rf)
            self.m += k * (YF[i] - s * self.m)
            self.Pm *= (1.0 - k * s)
        Phi = np.stack([cross(n, S), cross(t1, S), cross(t2, S)], 1)  # (3 components, 3 parameters)
        rt = (self.sig_t * Tw) ** 2
        for i in range(3):
            phi_i = Phi[i]
            Pp = self.P @ phi_i
            k = Pp / (phi_i @ Pp + rt)
            self.th = self.th + k * (YT[i] - phi_i @ self.th)
            self.P = self.P - np.outer(k, Pp)
        return True

    @property
    def h(self):
        hh = float(np.clip(self.th[0] / max(self.m, 1e-3), *self.h_prior))
        return [hh, hh]


class WaiterTask:
    n = 7

    def __init__(self, chain, h_box, mu_box, q_ref, w_p=1e5, w_pv=2e3, w_v=5.0, w_q=5.0, w_T=1e4, w_Tv=1e3,
                 dt=0.02, H=20, eps_exec=0.0):
        self.chain, self.h_box, self.mu_box = chain, list(h_box), list(mu_box)
        self.eps_exec = eps_exec  # tightening of the support rows by an execution-error bound (Prop. tighten)
        self.q_min, self.q_max, self.qd_max, self.h_safe = Q_MIN, Q_MAX, QD_MAX, 0.05
        self.lam_lo = self.lam_hi = None
        self.q_ref, self.w_p, self.w_pv, self.w_v, self.w_q = q_ref, w_p, w_pv, w_v, w_q
        self.w_T, self.w_Tv, self.dt, self.H = w_T, w_Tv, dt, H
        self.t_now = 0.0

    def kin(self, q, qd):
        R, o = self.chain.fk(q)
        Jv, Jw, p = self.chain.jacobian(q, R=R, o=o)
        jdv, jdw = self.chain.point_acc_bias(q, qd)
        return dict(R=R, o=o, p=p, Jv=Jv, Jw=Jw, jdv=jdv, jdw=jdw, w=mv(Jw, qd), zt=R[:, -1][:, :, 2])

    def mass(self, q, K):
        return self.chain.mass_matrix(q, K["R"], K["o"])

    def phys(self, K):
        return None

    def virt(self, K):
        """Tray orientation held: the normal n = -z_7 stays vertical (level) and the tray x axis x_7
        keeps no world-y component (heading), rows e = (n_x, n_y, x_7,y) = 0."""
        n, x7 = -K["zt"], K["R"][:, -1][:, :, 0]
        B = n.shape[0]
        ex, ey = np.broadcast_to([1.0, 0, 0], (B, 3)), np.broadcast_to([0, 1.0, 0], (B, 3))
        e = np.stack([n[:, 0], n[:, 1], x7[:, 1]], 1)
        w = K["w"]
        rows_J, rows_jd = [], []
        for v, u in ((n, ex), (n, ey), (x7, ey)):  # d/dt (v.u) = w.(v x u)
            a = cross(v, u)
            rows_J.append(np.einsum("bi,bij->bj", a, K["Jw"]))
            rows_jd.append(np.sum(cross(cross(w, v), u) * w, 1) + np.sum(a * K["jdw"], 1))
        return e, np.stack(rows_J, 1), np.stack(rows_jd, 1)

    def extra_rows(self, K, q, qd):
        """Robust support-wrench rows C qdd <= d over the vertices of the (h, mu) box, written in the
        tray frame (normal n, in-plane directions u_k) so a small tray tilt does not bias them.
        Each row L s <= b is tightened to L s <= b - |L| eps_exec: it then holds for every realised
        s' with |s' - s| <= eps_exec."""
        Jb, jd = K["Jv"], K["jdv"] - G  # s = Jb qdd + jd
        n = -K["zt"]
        x7 = K["R"][:, -1][:, :, 0]
        t1 = x7 - np.sum(x7 * n, 1, keepdims=True) * n
        t1 = t1 / np.linalg.norm(t1, axis=1, keepdims=True)
        t2 = cross(n, t1)
        U = DIRS[None, :, 0:1] * t1[:, None] + DIRS[None, :, 1:2] * t2[:, None]  # (B, N_DIR, 3)
        rows = [h * U - R_BASE * C8 * n[:, None] for h in self.h_box]  # tipping: h u.s - R c n.s <= 0
        rows += [U - mu * C8 * n[:, None] for mu in self.mu_box]  # slipping: u.s - mu c n.s <= 0
        rows.append(-n[:, None])  # lift-off: -n.s <= -S_MIN
        L = np.concatenate(rows, 1)  # (B, m, 3) acting on s
        C = L @ Jb
        d = -np.einsum("bij,bj->bi", L, jd)
        d[:, -1] -= S_MIN
        d -= self.eps_exec * np.linalg.norm(L, axis=2)
        return C, d

    def _tray(self, q, qd):
        Jv, _, p = self.chain.jacobian(q)
        return p, mv(Jv, qd)

    def run_cost(self, q, qd, lam, t):
        p, v = self._tray(q, qd)
        tau = self.t_now + (t + 1) * self.dt
        return (self.w_p * np.sum((p - target(tau)[0]) ** 2, 1) + self.w_pv * np.sum((v - target_vel(tau)[0]) ** 2, 1)
                + self.w_v * np.sum(qd * qd, 1) + self.w_q * np.sum((q - self.q_ref) ** 2, 1))

    def term_cost(self, q, qd):
        p, v = self._tray(q, qd)
        tau = self.t_now + self.H * self.dt
        return self.w_T * np.sum((p - target(tau)[0]) ** 2, 1) + self.w_Tv * np.sum((v - target_vel(tau)[0]) ** 2, 1)


def tray_xml(mu):
    return (f'<geom name="tray" type="box" size="0.13 0.09 0.005" pos="0.10 0 0.172" rgba="0.55 0.38 0.22 1" '
            f'friction="{mu} 0.005 0.0001" solref="0.004 1" contype="1" conaffinity="1"/>'
            f'<geom type="capsule" fromto="0 0 0.107 0 0 0.167" size="0.012" rgba="0.3 0.3 0.3 1" contype="0" conaffinity="0"/>')


FEET = True  # contact through four small spheres at the base corners (stable point contacts)
FOOT_R = 0.001


def object_xml(pos, quat, m, h, mu, feet=None):
    """Box of base half-width R_BASE.  With feet, contact is carried by four spheres whose contact
    points are the base corners, so the support polygon is the same square; box-on-box contact
    instead switches between contact sets and produces sporadic torque spikes."""
    feet = FEET if feet is None else feet
    Ix = m * ((2 * R_BASE) ** 2 + (2 * HALF_H) ** 2) / 12
    Iz = m * (2 * (2 * R_BASE) ** 2) / 12
    con = 'contype="0" conaffinity="0"' if feet else f'friction="{mu} 0.005 0.0001" solref="0.004 1" contype="1" conaffinity="1"'
    xml = (f'<body name="obj" pos="{_fmt(pos)}" quat="{_fmt(quat)}"><freejoint/>'
           f'<inertial pos="0 0 {h}" mass="{m}" diaginertia="{Ix} {Ix} {Iz}"/>'
           f'<geom name="obj" type="box" size="{R_BASE} {R_BASE} {HALF_H}" pos="0 0 {HALF_H + (FOOT_R if feet else 0)}" '
           f'rgba="0.15 0.45 0.85 1" {con}/>'
           f'<geom type="box" size="{R_BASE + 0.002} {R_BASE + 0.002} 0.02" pos="0 0 {h}" rgba="0.85 0.25 0.2 1" '
           f'contype="0" conaffinity="0"/>')  # marks the COM height
    if feet:
        for i, (sx, sy) in enumerate(((1, 1), (1, -1), (-1, 1), (-1, -1))):
            xml += (f'<geom name="foot{i}" type="sphere" size="{FOOT_R}" pos="{sx * R_BASE} {sy * R_BASE} {FOOT_R}" '
                    f'rgba="0.1 0.1 0.1 1" friction="{mu} 0.005 0.0001" solref="0.004 1" contype="1" conaffinity="1"/>')
    return xml + '</body>'


class WaiterPhysics:
    """Arm + tray + free object with real contact, 1 kHz.  Execution tau = M a + b + D qd - tau_load:
    the known joint damping is compensated and tau_load is the arm-side generalized force of the tray
    contact from the previous substep (a wrist F/T sensor mapped through J^T).  Each step also returns
    the noisy contact impulse on the object about the tray point B (the F/T measurement)."""

    def __init__(self, chain, q0, m=0.6, h=0.14, mu=0.6, dt=0.001, joint_damping=1.0, extra_asset="",
                 load_comp=1.0, noise=(0.0, 0.0), rng=None, noslip=10, elliptic=True):
        self.load_comp, self.noise, self.chain = load_comp, noise, chain
        self.rng = rng if rng is not None else np.random.default_rng(0)
        R, o = chain.fk(q0[None])
        R7 = R[0, -1]
        pos = o[0, -1] + R7 @ B_LOCAL + R7 @ np.array([0, 0, -0.0005])  # rest just above the tray
        Robj = R7 @ np.diag([1.0, -1.0, -1.0])
        quat = np.zeros(4)
        mujoco.mju_mat2Quat(quat, Robj.reshape(9))
        xml = scene_xml([(chain, "")], extra_world=object_xml(pos, quat, m, h, mu), timestep=dt, contact=True,
                        tool_extra=tray_xml(mu), extra_asset=extra_asset)
        self.m = mujoco.MjModel.from_xml_string(xml)
        self.m.opt.noslip_iterations = noslip
        if elliptic:  # exact friction cone, stiffer friction: 10x less contact-force jitter than the pyramid
            self.m.opt.cone = mujoco.mjtCone.mjCONE_ELLIPTIC
            self.m.opt.impratio = 10.0
        self.m.dof_damping[:7] = joint_damping
        self.D = self.m.dof_damping[:7].copy()
        self.d = mujoco.MjData(self.m)
        self.d.qpos[:7] = q0
        mujoco.mj_forward(self.m, self.d)
        self.bid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, "obj")
        self.gid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_GEOM, "obj")
        self.obj_geoms = {g for g in range(self.m.ngeom) if self.m.geom_bodyid[g] == self.bid and self.m.geom_contype[g]}
        self.sid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SITE, "tool")
        self.dt = dt
        self._M = np.zeros((self.m.nv, self.m.nv))
        self._f6 = np.zeros(6)

    @property
    def q(self):
        return self.d.qpos[:7].copy()

    @property
    def qd(self):
        return self.d.qvel[:7].copy()

    def tray_normal(self):
        return -self.d.site_xmat[self.sid].reshape(3, 3)[:, 2]

    def obj_tilt_deg(self):
        R = self.d.xmat[self.bid].reshape(3, 3)
        return float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1))))

    def contact_wrench(self):
        """Force on the object from the tray and its torque about the tray point B (world frame)."""
        d, m = self.d, self.m
        base = d.site_xpos[self.sid]
        F, T = np.zeros(3), np.zeros(3)
        for i in range(d.ncon):
            c = d.contact[i]
            if c.geom1 not in self.obj_geoms and c.geom2 not in self.obj_geoms:
                continue
            mujoco.mj_contactForce(m, d, i, self._f6)
            frame = c.frame.reshape(3, 3)  # rows: normal, tangent1, tangent2
            f = frame.T @ self._f6[:3]  # force on geom2 from geom1, world frame
            if c.geom2 not in self.obj_geoms:
                f = -f
            F += f
            T += np.cross(c.pos - base, f)
        return F, T

    def step(self, a, T):
        """Hold the command a for T.  Returns the object tilts [deg] and the measurement
        dict(YF, YT, cop, cop_true):
          YF, YT    noisy contact impulses over T (torque about the tray point B), the F/T measurement;
          cop       measured COP over T (from the impulses, about B) over the base half-width, disk norm;
          cop_true  noise-free COP over T relative to the box's own base, over the square half-width
                    (1 = at an edge), averaged over T (the box's rotation responds to the integrated torque);
          cop_true_inst  the same at every 1-ms substep, largest value (inf if contact was lost);
          n_loss    substeps without normal load;
          s_inst    (n, 3) realized tray-point acceleration relative to gravity at every substep."""
        n = int(round(T / self.dt))
        tilts, YF, YT, YF0, YT0 = [], np.zeros(3), np.zeros(3), np.zeros(3), np.zeros(3)
        cop_inst, n_loss, s_inst = 0.0, 0, np.empty((n, 3))
        for j in range(n):
            mujoco.mj_fullM(self.m, self.d, self._M)
            self.d.qfrc_applied[:] = 0.0
            self.d.qfrc_applied[:7] = (self._M[:7, :7] @ a + self.d.qfrc_bias[:7] + self.D * self.d.qvel[:7]
                                       - self.load_comp * self.d.qfrc_constraint[:7])
            q_pre, qd_pre = self.d.qpos[:7].copy(), self.d.qvel[:7].copy()
            mujoco.mj_step(self.m, self.d)
            tilts.append(self.obj_tilt_deg())
            # realized acceleration of the tray point in this substep (qacc belongs to the pre-step state)
            Jv, _, _ = self.chain.jacobian(q_pre[None])
            jdv, _ = self.chain.point_acc_bias(q_pre[None], qd_pre[None])
            s_inst[j] = Jv[0] @ self.d.qacc[:7] + jdv[0] - G
            F0, T0 = self.contact_wrench()
            Rs = self.d.site_xmat[self.sid].reshape(3, 3)
            ns = -Rs[:, 2]
            fn = float(F0 @ ns)
            if fn > 1e-6:
                dvs = self.d.xpos[self.bid] - self.d.site_xpos[self.sid]
                ps = np.cross(ns, T0) / fn - (dvs - (dvs @ ns) * ns)
                cop_inst = max(cop_inst, max(abs(float(ps @ Rs[:, 0])), abs(float(ps @ Rs[:, 1]))) / R_BASE)
            else:
                n_loss += 1
                cop_inst = np.inf
            YF0 += F0 * self.dt
            YT0 += T0 * self.dt
            YF += (F0 + self.rng.uniform(-self.noise[0], self.noise[0], 3)) * self.dt
            YT += (T0 + self.rng.uniform(-self.noise[1], self.noise[1], 3)) * self.dt
        R7 = self.d.site_xmat[self.sid].reshape(3, 3)
        nz, t1, t2 = -R7[:, 2], R7[:, 0], R7[:, 1]
        Fn, Fn0 = float(YF @ nz), float(YF0 @ nz)
        cop = float(np.linalg.norm(np.cross(nz, YT))) / (R_BASE * Fn) if Fn > 1e-6 else np.inf
        if Fn0 > 1e-6:
            dv = self.d.xpos[self.bid] - self.d.site_xpos[self.sid]
            p = np.cross(nz, YT0) / Fn0 - (dv - (dv @ nz) * nz)
            cop_true = max(abs(float(p @ t1)), abs(float(p @ t2))) / R_BASE
        else:
            cop_true = np.inf
        return tilts, dict(YF=YF, YT=YT, cop=cop, cop_true=cop_true, cop_true_inst=cop_inst, n_loss=n_loss, s_inst=s_inst)

