"""Record and render the waiter video: 2x2 grid (nominal, robust, adaptive, oracle), true h = 0.14 m, seed 0.
Shown at half speed; each cell reports the horizontal tray acceleration against the limit the rows admit."""
import sys
from multiprocessing import Pool
from pathlib import Path

import imageio_ffmpeg
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiments.waiter_exp as X  # noqa: E402
from umppi import waiter as WT  # noqa: E402

VID = Path(__file__).resolve().parent / "results" / "videos"
SCEN = [  # tag, controller, title
    ("waiter_nominal", "nominal", "Nominal model (assumes h = 0.07 m)"),
    ("waiter_robust", "robust", "Robust rows (h in [0.05, 0.18] m)"),
    ("waiter_cop", "adaptive-cop", "Adaptive (F/T only, COP differences)"),
    ("waiter_oracle", "oracle", "Oracle (true h = 0.14 m)"),
]
TRUE_LIM = WT.R_BASE * 9.81 / X.TRUE["h"]  # tipping limit along the base axes
FPS, STEP = 25, 1  # control period 20 ms -> 50 Hz data shown at 25 fps = 0.5x speed
Wd, Hd = 640, 480
FONT, FONTB = "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"
SKY = '<texture type="skybox" builtin="gradient" rgb1="0.93 0.94 0.96" rgb2="0.62 0.66 0.72" width="256" height="256"/>'
G0 = 9.81


def record(sc):
    tag, name, title = sc
    rec = {}
    r, log = X.run(name, 0, X.TRUE["h"], rec=rec)
    VID.mkdir(parents=True, exist_ok=True)
    np.savez(VID / f"{tag}.npz", qpos=np.array(rec["qpos"]), hbox=np.array(log["hbox"]), ah=np.array(log["ah"]),
             tilt=np.array(log["tilt"]), title=title, t_tip=-1.0 if r["t_tip"] is None else r["t_tip"])
    return tag, r["tipped"], r["max_tilt"], r["rmse2"]


class Cell:
    def __init__(self, tag, model):
        z = np.load(VID / f"{tag}.npz")
        self.qpos, self.hbox, self.ah, self.tilt = z["qpos"], z["hbox"], z["ah"], z["tilt"]
        self.title, self.t_tip = str(z["title"]), float(z["t_tip"])
        self.m, self.d = model, mujoco.MjData(model)
        self.r = mujoco.Renderer(model, Hd, Wd, max_geom=4000)
        self.cam = mujoco.MjvCamera()
        self.cam.type = mujoco.mjtCamera.mjCAMERA_FREE
        self.cam.lookat[:] = (0.50, 0.0, 0.40)
        self.cam.distance, self.cam.azimuth, self.cam.elevation = 1.05, 195.0, -12.0
        self.ft = ImageFont.truetype(FONTB, 17)
        self.fx = ImageFont.truetype(FONT, 16)
        self.fb = ImageFont.truetype(FONTB, 30)

    def render(self, k):
        kk = min(k, len(self.qpos) - 1)
        self.d.qpos[:] = self.qpos[kk]
        mujoco.mj_forward(self.m, self.d)
        self.r.update_scene(self.d, camera=self.cam)
        img = Image.fromarray(self.r.render())
        dr = ImageDraw.Draw(img)
        dr.rectangle([0, 0, Wd, 30], fill=(250, 250, 250))
        dr.text((10, 5), self.title, font=self.ft, fill=(15, 15, 15))
        t = (kk + 1) * X.DT
        h_hi = self.hbox[kk][1]
        lim = WT.R_BASE * WT.C8 * G0 / h_hi
        dr.rectangle([0, Hd - 76, Wd, Hd], fill=(250, 250, 250))
        dr.text((10, Hd - 72), f"t = {t:4.2f} s  (0.5x speed)    object tilt {self.tilt[kk]:5.1f} deg", font=self.fx, fill=(15, 15, 15))
        dr.text((10, Hd - 49), f"tray |a_h| {self.ah[kk]:4.2f} m/s^2    rows admit {lim:4.2f}    true limit {TRUE_LIM:4.2f}", font=self.fx,
                fill=(200, 30, 25) if self.ah[kk] > TRUE_LIM else (15, 15, 15))
        lo, hi = self.hbox[kk]
        hs = f"h = {lo:.3f} m" if abs(hi - lo) < 1e-9 else f"h in [{lo:.3f}, {hi:.3f}] m"
        dr.text((10, Hd - 26), f"model: {hs}", font=self.fx, fill=(15, 15, 15))
        if self.t_tip > 0 and t >= self.t_tip:
            dr.rectangle([10, 40, 190, 80], fill=(255, 255, 255))
            dr.text((20, 44), "TIPPED", font=self.fb, fill=(210, 30, 25))
        return np.asarray(img)


def main():
    import warnings
    warnings.filterwarnings("ignore")
    if "--render-only" not in sys.argv:
        with Pool(len(SCEN)) as p:
            for tag, tipped, mt, r2 in p.imap_unordered(record, SCEN):
                print(tag, f"tipped {tipped}, max tilt {mt:.1f} deg, move-2 RMSE {r2}", flush=True)
    chain = WT.make_chain()
    q0 = WT.ik(chain, WT.A_PT, X.Q_READY)
    model = WT.WaiterPhysics(chain, q0, **X.TRUE, extra_asset=SKY).m
    cells = [Cell(tag, model) for tag, *_ in SCEN]
    n = int(round(WT.T_RUN / X.DT))
    g = imageio_ffmpeg.write_frames(str(VID / "waiter_grid.mp4"), (2 * Wd, 2 * Hd), fps=FPS, codec="libx264",
                                    quality=8, pix_fmt_out="yuv420p", macro_block_size=16)
    g.send(None)
    for fi in range(0, n, STEP):
        fr = [c.render(fi) for c in cells]
        grid = np.concatenate([np.concatenate(fr[:2], 1), np.concatenate(fr[2:], 1)], 0)
        if fi == int(round(0.95 / X.DT)):
            Image.fromarray(grid).save(VID / "waiter_frame.png")
        g.send(np.ascontiguousarray(grid))
    g.close()
    print("wrote", VID / "waiter_grid.mp4")


if __name__ == "__main__":
    main()
