"""Safe-MPPI methods from the literature on the curved-surface writing task (umppi/safe_mppi.py on the generic
writing task umppi/writing_task.py): Shield-MPPI (band as a CBF-type penalty, gradient repair), DualGuard MPPI
(reaction outside the band reset to its centre, filtered samples averaged) and GS-MPPI (band and motion rows in the
soft-min composite, Euclidean safe law, raw average), with the model, rows, costs, horizon and clipped noise of
Algorithm 1.  The order-2 controllers do not depend on the surface offset, so delta = 0; three seeds.
Writes results/safe_writing.json.
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import writing_exp as X  # noqa: E402

HERE = Path(__file__).resolve().parent
VARIANTS = [("shield", {"C": 10.0}), ("shield", {"C": 100.0}), ("shield", {"C": 1000.0}), ("dualguard", {}),
            ("gs", {"rho": 5.0}), ("gs", {"rho": 20.0}), ("gs", {"rho": 100.0})]
KEYS = ("track_rmse_mm", "force_mean", "force_std", "force_max", "in_band", "contact", "ori_rms_deg", "lam_cmd_range",
        "ms_per_step", "diverged_t", "delta_mm")


def _job(a):
    method, prm, seed = a
    import warnings
    warnings.filterwarnings("ignore")
    from umppi.safe_mppi import DualGuardMPPI, GSMPPI, ShieldMPPI
    from umppi.writing_task import WritingTask
    cls = {"shield": ShieldMPPI, "dualguard": DualGuardMPPI, "gs": GSMPPI}[method]
    fac = lambda ch, dl: cls(WritingTask(ch, dl, dt=X.DT, H=X.H), sigma=0.8, dt=X.DT, H=X.H, K=X.K, **prm)  # noqa: E731
    lab = method + "".join(f"@{k}={v:g}" for k, v in prm.items())
    try:
        r, _ = X.run(lab, 0.0, seed=seed, controller_factory=fac)
    except Exception as exc:
        return {"label": lab, "method": method, "seed": seed, "error": repr(exc)}
    out = {k: r[k] for k in KEYS}
    out.update(label=lab, method=method, params=prm, seed=seed)
    return out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=4)
    ap.add_argument("--seeds", type=int, default=3)
    args = ap.parse_args()
    jobs = [(m, p, s) for s in range(args.seeds) for m, p in VARIANTS]
    out = HERE / "results" / "safe_writing.json"
    rows = []
    with Pool(args.procs) as pool:
        for r in pool.imap_unordered(_job, jobs):
            rows.append(r)
            print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}), flush=True)
            out.write_text(json.dumps({"rows": rows}, default=float))
