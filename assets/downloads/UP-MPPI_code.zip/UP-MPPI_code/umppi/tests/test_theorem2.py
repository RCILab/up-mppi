"""Theorem 2 (i)-(iii) on the arm model: every executed command is admissible, and the
separable and joint solvers return the same command."""
import numpy as np

from umppi import writing as W_
from umppi.controllers import CAMPMPPI
from umppi.robot import QD_MAX, Chain

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])


def main(trials=12):
    rng = np.random.default_rng(4)
    ch = Chain()
    q = Q_READY.copy()
    worst = dict(band=0.0, rows=0.0, virt=0.0, sep_joint=0.0)
    for i in range(trials):
        t = rng.uniform(0, W_.T_PATH)
        q = W_.ik_on_surface(ch, W_.path_point(t)[0], q)
        k = W_.kin(ch, q[None], np.zeros((1, 7)))
        Jc = W_.contact(k)[1][0]
        qd = rng.normal(0, 0.3, 7)
        qd -= Jc.T @ np.linalg.solve(Jc @ Jc.T, Jc @ qd)  # consistent with the contact row
        outs = {}
        for solver in ("separable", "joint"):
            c = CAMPMPPI(ch, solver=solver, virtual="hard", dt=0.01, H=10, K=128, sigma=3.0, seed=i)
            c.U = rng.normal(0, 2.0, (c.H, 7)) if solver == "separable" else outs["U0"]
            outs["U0"] = c.U.copy()
            outs[solver] = (c.plan(q, qd, t), c)
        cmd, c = outs["separable"]
        mdl = c._model(q[None], qd[None])
        a = cmd["a"][None]
        lam = -(mdl["Lam"][0] @ (mdl["Jc"][0] @ a[0] + mdl["jcd"][0]))[0]
        worst["band"] = max(worst["band"], max(W_.LAM_BAND[0] - lam, lam - W_.LAM_BAND[1], 0.0))
        x = (mdl["F"][0] @ a[0])
        d_lo, d_hi = c._hocbf(q[None], qd[None], mdl["f"])
        worst["rows"] = max(worst["rows"], np.max(-x - d_lo[0]), np.max(x - d_hi[0]), 0.0)
        qdd = x + mdl["f"][0]
        edot = mdl["Jo"][0] @ qd
        r_v = -c.KD * edot - c.KP * mdl["e"][0]
        worst["virt"] = max(worst["virt"], np.max(np.abs(mdl["Jo"][0] @ qdd + mdl["jod"][0] - r_v)))
        worst["sep_joint"] = max(worst["sep_joint"], np.max(np.abs(outs["separable"][0]["a"] - outs["joint"][0]["a"])))
    assert np.all(QD_MAX > 0)
    ok = worst["band"] < 1e-8 and worst["rows"] < 1e-7 and worst["virt"] < 1e-7 and worst["sep_joint"] < 1e-7
    for key, v in worst.items():
        print(f"  {key:9s} max violation / difference {v:.2e}")
    print("PASS" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    main()
