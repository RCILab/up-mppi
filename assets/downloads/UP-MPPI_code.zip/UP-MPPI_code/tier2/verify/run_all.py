"""Run every Tier-2 verification and print one PASS/FAIL summary."""
import time

import v1_separation
import v2_physical_virtual
import v3_cbf_layer
import v4_rollout_retraction
import v5_clipping
import v6_snis
import v7_deadbeat
import v8_robust
import v9_final_projection

SUITES = [
    ("T1  separation theorem", v1_separation),
    ("T2  physical vs virtual equalities", v2_physical_virtual),
    ("T3b finite-step CBF layer (orders 1, 2)", v3_cbf_layer),
    ("T3d executed-only vs per-rollout retraction", v4_rollout_retraction),
    ("T3c/T4b t=0 feasibility, clipping distortion", v5_clipping),
    ("Lemma 2 self-normalised projected update", v6_snis),
    ("Thm 2(v) virtual-row error dynamics", v7_deadbeat),
    ("Props R1-R3 robust and adaptive wrench rows", v8_robust),
    ("Alg 1 raw average, final projection, tightening", v9_final_projection),
]

if __name__ == "__main__":
    summary = []
    for title, mod in SUITES:
        print(f"\n=== {title} ===")
        t0 = time.perf_counter()
        rep = mod.main()
        summary.append((title, rep.all_pass, len(rep.rows), time.perf_counter() - t0))
    print("\n=== summary ===")
    for title, ok, n, dt in summary:
        print(f"  {'PASS' if ok else 'FAIL'}  {title}  ({n} checks, {dt:.0f} s)")
