"""Calibrate the error bounds of the waiter measurement models in separate runs (HARDWARE.md, step 3).

Oracle controller at the ends and the middle of the prior interval of h, seeds not used in the evaluation.
From every sticking window, with the true parameters and the true position d of the box on the tray:
  e_F  = max |Y_F - m S| / Tw                                   (force error: noise and dynamics)
  e_t  = max |Y_tau - m (h n + d) x S| / Tw, in-plane components (torque error without the offset term)
  d    = max |d| over the run                                     (offset of the box, direct model)
  rho  = max over window pairs up to 0.6 s apart of (|d_k - d_j| - d0) / (t_k - t_j + Tw)   (creep rate)
Each bound is 1.5 times its largest calibration value (d0 fixed at 0.1 mm).  Writes results/waiter_bounds.json.
"""
import json
import sys
import warnings
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiments.waiter_exp as X  # noqa: E402
from umppi import waiter as WT  # noqa: E402

H_CAL, SEEDS, MARGIN, D0, SPAN = (0.05, 0.115, 0.18), (100, 101), 1.5, 1e-4, 0.6
N_WIN = X.N_WIN
if "--n-win" in sys.argv:  # window length in control periods (the note compares 2 and 5)
    N_WIN = int(sys.argv[sys.argv.index("--n-win") + 1])


def job(a):
    h, seed = a
    warnings.filterwarnings("ignore")
    r, log = X.run("oracle", seed, h, collect=True, n_win=N_WIN)
    m = X.TRUE["m"]
    eF = et = rho = 0.0
    wins = log.get("win", [])
    pairs = []  # (measured COP ratio of the window, torque error)
    for t, YF, YT, S, n, t1, t2, d, Sp, dw in wins:
        Tw = X.DT * N_WIN
        eF = max(eF, float(np.max(np.abs(YF - m * S))) / Tw)
        res = YT - m * WT.cross(h * n + d, S)
        e = max(abs(float(res @ t1)), abs(float(res @ t2))) / Tw
        et = max(et, e)
        qs = [np.array([Si @ t1, Si @ t2]) / float(Si @ n) for Si in Sp]  # q of each period in the window
        IB = X.TRUE["m"] * ((2 * WT.R_BASE) ** 2 + (2 * WT.HALF_H) ** 2) / 12 + X.TRUE["m"] * h * h
        rot = IB * max(abs(float(dw @ t1)), abs(float(dw @ t2))) / Tw  # |I_B dw| / Tw, in-plane
        res_c = res - IB * dw  # torque error with the rotational term of the tray removed
        e_c = max(abs(float(res_c @ t1)), abs(float(res_c @ t2))) / Tw
        pairs.append((float(np.linalg.norm(np.cross(n, YT))) / (WT.R_BASE * float(YF @ n)), e,
                      float(np.max(np.abs(qs[-1] - qs[0]))), rot, e_c))
    for k, (tk, *_, dk, _s, _w) in enumerate(wins):
        for tj, *_, dj, _s2, _w2 in wins[:k]:
            if 0 < tk - tj <= SPAN:
                dd = max(abs(float((dk - dj) @ wins[k][5])), abs(float((dk - dj) @ wins[k][6])))
                rho = max(rho, (dd - D0) / (tk - tj + N_WIN * X.DT))
    return dict(h=h, seed=seed, tipped=r["tipped"], e_f=eF, e_t=et, d=r["box_shift_mm"] * 1e-3, rho=rho,
                windows=len(wins), pairs=pairs)


if __name__ == "__main__":
    warnings.filterwarnings("ignore")
    procs = int(sys.argv[sys.argv.index("--procs") + 1]) if "--procs" in sys.argv else 6
    with Pool(procs) as p:
        res = list(p.imap_unordered(job, [(h, s) for h in H_CAL for s in SEEDS]))
    for r in sorted(res, key=lambda r: (r["h"], r["seed"])):
        print(f"h={r['h']:.3f} seed {r['seed']}: e_F {r['e_f']:.3f} N  e_t {1e3 * r['e_t']:.2f} mN m  "
              f"|d| {1e3 * r['d']:.2f} mm  creep {1e3 * r['rho']:.2f} mm/s  windows {r['windows']}  tipped {r['tipped']}")
    worst = {k: max(r[k] for r in res) for k in ("e_f", "e_t", "d", "rho")}
    bounds = dict(eps_f=MARGIN * worst["e_f"], eps_t=MARGIN * worst["e_t"], d_max=MARGIN * worst["d"],
                  rho_d=max(MARGIN * worst["rho"], 1e-3), d0=D0)
    name = "waiter_bounds.json" if N_WIN == X.N_WIN else f"waiter_bounds_w{int(round(1e3 * N_WIN * X.DT))}.json"
    out = Path(__file__).resolve().parent / "results" / name
    out.write_text(json.dumps({"bounds": bounds, "worst": worst, "runs": res, "margin": MARGIN}, indent=1))
    print("bounds:", {k: round(v, 5) for k, v in bounds.items()})
