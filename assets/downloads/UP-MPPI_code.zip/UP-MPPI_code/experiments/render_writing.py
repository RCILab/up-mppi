"""Render the writing-task videos from recorded states: a synchronised 2x2 grid plus one clip per
scenario.  Ink is drawn where the pen presses (> 0.3 N), coloured by the contact force:
black inside the 2-4 N band, red above it, grey below it (as in CAMP-MPPI Fig. 3)."""
import sys
from pathlib import Path

import imageio_ffmpeg
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import writing as W_  # noqa: E402
from umppi.mjcf import scene_xml  # noqa: E402
from umppi.robot import Chain  # noqa: E402

VID = Path(__file__).resolve().parent / "results" / "videos"
TAGS = ["pr_press", "pr_lift", "camp_manifold", "unified"]
FPS, STEP = 25, 4  # one frame every 4 control steps of 10 ms
Wd, Hd, INSET = 640, 480, 210
FONT = "C:/Windows/Fonts/arial.ttf"
FONTB = "C:/Windows/Fonts/arialbd.ttf"
BOARD = (f'<geom name="board" type="sphere" size="{W_.R_S}" pos="{W_.C_S[0]} {W_.C_S[1]} {W_.C_S[2]}" '
         f'rgba="0.97 0.97 0.95 1" contype="0" conaffinity="0"/>')
SKY = '<texture type="skybox" builtin="gradient" rgb1="0.93 0.94 0.96" rgb2="0.62 0.66 0.72" width="256" height="256"/>'


def ink_rgba(f):
    lo, hi = W_.LAM_BAND
    if f > hi:
        return (0.86, 0.14, 0.10, 1.0)
    if f >= lo:
        return (0.07, 0.07, 0.09, 1.0)
    return (0.60, 0.60, 0.63, 1.0)


def frame_on_board(p):
    n = p - W_.C_S
    n /= np.linalg.norm(n)
    a = np.array([1.0, 0.0, 0.0]) if abs(n[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    x = np.cross(a, n)
    x /= np.linalg.norm(x)
    y = np.cross(n, x)
    return n, np.stack([x, y, n], 1)


def add_geom(scene, gtype, size, pos, mat, rgba):
    if scene.ngeom >= scene.maxgeom:
        return
    mujoco.mjv_initGeom(scene.geoms[scene.ngeom], gtype, np.asarray(size, float), np.asarray(pos, float),
                        np.ascontiguousarray(mat, float).reshape(9), np.asarray(rgba, np.float32))
    scene.ngeom += 1


def decorate(scene, ink_p, ink_f, upto, path_pts):
    eye = np.eye(3)
    for p in path_pts:
        add_geom(scene, mujoco.mjtGeom.mjGEOM_SPHERE, (0.0009, 0, 0), p, eye, (0.35, 0.55, 0.95, 0.55))
    for p, f in zip(ink_p[:upto], ink_f[:upto]):
        if f < 0.3:
            continue
        n, R = frame_on_board(p)
        r = min(0.0013 + 0.00022 * f, 0.0055)
        add_geom(scene, mujoco.mjtGeom.mjGEOM_CYLINDER, (r, 0.0003, 0), W_.C_S + n * (W_.R_S + 0.0005), R, ink_rgba(f))


class Cell:
    """Renders one scenario at a given control step."""

    def __init__(self, tag, model):
        z = np.load(VID / f"{tag}.npz")
        self.tag, self.title = tag, str(z["title"])
        self.qpos, self.t = z["qpos"], z["t"]
        self.ink_p, self.ink_f = z["ink_p"], z["ink_f"]
        self.div = float(z["diverged_t"])
        self.m, self.d = model, mujoco.MjData(model)
        self.main = mujoco.Renderer(model, Hd, Wd, max_geom=12000)
        self.ins = mujoco.Renderer(model, INSET, INSET, max_geom=12000)
        self.cam = mujoco.MjvCamera()
        self.cam.type = mujoco.mjtCamera.mjCAMERA_FREE
        self.cam.lookat[:] = (0.40, 0.0, 0.22)
        self.cam.distance, self.cam.azimuth, self.cam.elevation = 1.25, 145.0, -26.0
        self.top = mujoco.MjvCamera()
        self.top.type = mujoco.mjtCamera.mjCAMERA_FREE
        self.top.lookat[:] = (W_.C_S[0], W_.C_S[1], W_.C_S[2] + W_.R_S)
        self.top.distance, self.top.azimuth, self.top.elevation = 0.26, 90.0, -89.0
        self.opt_top = mujoco.MjvOption()
        self.opt_top.geomgroup[1] = 0  # hide the arm so the top view sees the ink
        self.path = W_.path_point(np.linspace(0, W_.T_PATH, 160))
        self.f_title = ImageFont.truetype(FONTB, 17)
        self.f_text = ImageFont.truetype(FONT, 16)
        self.f_small = ImageFont.truetype(FONT, 12)
        self.f_big = ImageFont.truetype(FONTB, 30)

    def render(self, k):
        n_ok = len(self.qpos)
        kk = min(k, n_ok - 1)
        t = (k + 1) * 0.01
        self.d.qpos[:] = self.qpos[kk]
        mujoco.mj_forward(self.m, self.d)
        upto = min((kk + 1) * 2, len(self.ink_p))  # two ink samples (5 ms) per control step
        imgs = []
        for rend, cam, opt in ((self.main, self.cam, None), (self.ins, self.top, self.opt_top)):
            if opt is None:
                rend.update_scene(self.d, camera=cam)
            else:
                rend.update_scene(self.d, camera=cam, scene_option=opt)
            decorate(rend.scene, self.ink_p, self.ink_f, upto, self.path)
            imgs.append(rend.render())
        img = Image.fromarray(imgs[0])
        inset = Image.fromarray(imgs[1])
        img.paste(inset, (Wd - INSET - 10, Hd - INSET - 34))
        dr = ImageDraw.Draw(img)
        dr.rectangle([Wd - INSET - 11, Hd - INSET - 35, Wd - 10, Hd - 35], outline=(60, 60, 60), width=1)
        dr.text((Wd - INSET - 10, Hd - 31), "top view (arm hidden)", font=self.f_small, fill=(30, 30, 30))
        dr.text((Wd - INSET - 10, Hd - 17), "ink: 2-4 N black, >4 N red, <2 N grey", font=self.f_small, fill=(30, 30, 30))
        dr.rectangle([0, 0, Wd, 30], fill=(250, 250, 250))
        dr.text((10, 6), self.title, font=self.f_title, fill=(15, 15, 15))
        f_now = float(np.mean(self.ink_f[max(0, upto - 20):upto])) if upto else 0.0
        lo, hi = W_.LAM_BAND
        status, col = ("in band", (20, 110, 40)) if lo <= f_now <= hi else \
            (("above band", (200, 40, 30)) if f_now > hi else ("below band / no contact", (120, 120, 120)))
        dr.text((10, Hd - 50), f"t = {min(t, self.t[-1]):4.2f} s", font=self.f_text, fill=(15, 15, 15))
        dr.text((10, Hd - 28), f"contact force {f_now:5.2f} N", font=self.f_text, fill=(15, 15, 15))
        dr.text((190, Hd - 28), status, font=self.f_text, fill=col)
        if self.div > 0 and t >= self.div:
            dr.rectangle([10, 40, 330, 82], fill=(255, 255, 255))
            dr.text((20, 44), f"DIVERGED at {self.div:.2f} s", font=self.f_big, fill=(210, 30, 25))
        return np.asarray(img)


def writer(path, w, h):
    g = imageio_ffmpeg.write_frames(str(path), (w, h), fps=FPS, codec="libx264", quality=8,
                                    pix_fmt_out="yuv420p", macro_block_size=16)
    g.send(None)
    return g


def main(test_frame=None):
    model = mujoco.MjModel.from_xml_string(scene_xml([(Chain(), "")], extra_world=BOARD, extra_asset=SKY))
    cells = [Cell(tag, model) for tag in TAGS]
    n_frames = int(round(W_.T_PATH / 0.01)) // STEP
    if test_frame is not None:
        k = test_frame * STEP
        top = np.concatenate([cells[0].render(k), cells[1].render(k)], 1)
        bot = np.concatenate([cells[2].render(k), cells[3].render(k)], 1)
        Image.fromarray(np.concatenate([top, bot], 0)).save(VID / f"frame_{test_frame}.png")
        print("saved test frame")
        return
    grid = writer(VID / "writing_grid.mp4", 2 * Wd, 2 * Hd)
    singles = {c.tag: writer(VID / f"writing_{c.tag}.mp4", Wd, Hd) for c in cells}
    for f in range(n_frames):
        k = f * STEP + STEP - 1
        frames = [c.render(k) for c in cells]
        for c, fr in zip(cells, frames):
            singles[c.tag].send(np.ascontiguousarray(fr))
        top = np.concatenate(frames[:2], 1)
        bot = np.concatenate(frames[2:], 1)
        grid.send(np.ascontiguousarray(np.concatenate([top, bot], 0)))
    for g in [grid, *singles.values()]:
        g.close()
    print("wrote", VID / "writing_grid.mp4", "and", len(singles), "single clips")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else None)
