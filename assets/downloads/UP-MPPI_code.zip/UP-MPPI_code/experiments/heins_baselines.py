"""Gradient-based baselines after Heins and Schoellig (umppi/robust_plan.py) on the waiter task, robust (h, mu) prior.

offline  one robust trajectory optimisation over the whole run (IPOPT; RA-L 2025 structure), tracked with PD
         feedback; rows as they are (eps = 0) or tightened by the calibrated execution-error bound
online   receding-horizon robust NMPC with the MPPI cost, horizon and step (Keep-it-upright structure, 2023),
         rows hard at the first knot; jerk weight w_j tuned at h = 0.14 m, then the heights of the sweep
Both are deterministic (no sampling; the F/T noise is not used), so one run per height.
Writes results/heins_baselines.json (and caches the offline plans in results/heins_plans.pkl).
"""
import json
import pickle
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import waiter_exp as X  # noqa: E402

HERE = Path(__file__).resolve().parent
H_ALL = (0.08, 0.11, 0.14, 0.17)
W_J = (1e-4, 1e-3, 1e-2)
KEYS = ("tipped", "t_tip", "rmse1", "rmse2", "reach1", "reach2", "peak_ah", "oct_model_max", "cop_true_max", "dev_max",
        "ms_per_step", "h_true", "seed")
PLANS = HERE / "results" / "heins_plans.pkl"


def _job(a):
    kind, prm, h, eps = a
    import warnings
    warnings.filterwarnings("ignore")
    from umppi.robust_plan import OnlineNMPC, PlanTracker
    if kind == "offline":
        pl = pickle.loads(PLANS.read_bytes())[eps]
        fac = lambda task: PlanTracker(pl)  # noqa: E731
    else:
        holder = {}

        def fac(task):
            holder["c"] = OnlineNMPC(task, eps=eps, **prm)
            return holder["c"]
    try:
        r, _ = X.run("robust", 0, h, controller_factory=fac, eps_exec=eps)
    except Exception as exc:
        return {"kind": kind, "params": prm, "eps": eps, "h_true": h, "error": repr(exc)}
    out = {k: r[k] for k in KEYS}
    out.update(kind=kind, params=prm, eps=eps)
    if kind == "online":
        out["fail"] = holder["c"].stats["fail"]
    return out


def run_jobs(jobs, out, procs, rows):
    with Pool(procs) as pool:
        for r in pool.imap_unordered(_job, jobs):
            rows.append(r)
            print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}, default=float), flush=True)
            out.write_text(json.dumps({"rows": rows}, default=float))
    return rows


if __name__ == "__main__":
    import argparse
    import numpy as np
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=4)
    ap.add_argument("--extra-wj", nargs="*", type=float, default=None,
                    help="more jerk weights for the online NMPC at h = 0.14 m, appended; the heights for a new best")
    args = ap.parse_args()
    if args.extra_wj:
        out = HERE / "results" / "heins_baselines.json"
        rows = json.loads(out.read_text())["rows"]
        eps_x = X.EPS_EXEC
        run_jobs([("online", {"w_j": w}, 0.14, e) for e in (0.0, eps_x) for w in args.extra_wj], out, args.procs, rows)
        for e in (0.0, eps_x):
            ok = [r for r in rows if r.get("kind") == "online" and abs(r["eps"] - e) < 1e-9 and "error" not in r
                  and not r["tipped"] and r["h_true"] == 0.14]
            best = min(ok, key=lambda r: r["rmse1"])["params"]
            done = {r["h_true"] for r in rows if r.get("kind") == "online" and abs(r["eps"] - e) < 1e-9 and r.get("params") == best}
            todo = [("online", best, h, e) for h in H_ALL if h not in done]
            print("eps", e, "best", best, "todo", len(todo), flush=True)
            if todo:
                run_jobs(todo, out, args.procs, rows)
        raise SystemExit
    from umppi import waiter as WT
    from umppi.robust_plan import plan
    eps_x = X.EPS_EXEC
    ch = WT.make_chain()
    q0 = WT.ik(ch, WT.A_PT, X.Q_READY)
    plans = {e: plan(ch, q0, h_box=X.PRIOR_H, mu_box=X.PRIOR_MU, eps=e) for e in (0.0, eps_x)}
    for e, pl in plans.items():
        print("offline plan eps", round(e, 3), pl["info"], flush=True)
    PLANS.write_bytes(pickle.dumps(plans))
    out = HERE / "results" / "heins_baselines.json"
    rows = []
    jobs = [("offline", {}, h, e) for e in (0.0, eps_x) for h in H_ALL]
    jobs += [("online", {"w_j": w}, 0.14, e) for e in (0.0, eps_x) for w in W_J]
    run_jobs(jobs, out, args.procs, rows)
    best = {}
    for e in (0.0, eps_x):
        ok = [r for r in rows if r.get("kind") == "online" and r["eps"] == e and "error" not in r and not r["tipped"]]
        if ok:
            best[e] = min(ok, key=lambda r: r["rmse1"])["params"]
    print("best online", best, flush=True)
    jobs = [("online", p, h, e) for e, p in best.items() for h in H_ALL if h != 0.14]
    run_jobs(jobs, out, args.procs, rows)
