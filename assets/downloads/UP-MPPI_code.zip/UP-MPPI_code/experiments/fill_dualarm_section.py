"""Fill tier2/dualarm_section.tex from results/dualarm_summary.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAIN_FINAL = 7.52  # N/mm: closed-chain Prop. 2(b) at the configuration where the runs end
LABEL = {"PR": "PR-MPPI", "PR-noretract": "PR-MPPI w/o retraction", "PR-noineq": "PR-MPPI w/o inequality",
         "Unified": "Unified", "PR-anchored": "PR-MPPI anchored", "Unified-eps0": "Unified, $\\varepsilon=0$",
         "Shield": "Shield-MPPI", "DualGuard": "DualGuard MPPI", "GS": "GS-MPPI"}


def sci(x):
    """LaTeX scientific notation, e.g. 4.1e-14 -> $4.1\\times10^{-14}$."""
    m, e = f"{x:.1e}".split("e")
    return f"${m}\\times10^{{{int(e)}}}$"


def main():
    S = json.loads((HERE / "results/dualarm_summary.json").read_text())
    EX = json.loads((HERE / "results/dualarm_exec_bound.json").read_text())
    E1, E2 = S["E1"], S["E2"]
    t1 = ["\\begin{table}[h]", "\\centering",
          "\\caption{E1: joint-limit stress test without calibration error (three seeds). Residuals are measured on the physical arms; the command residual is the largest entry of the model equality at the retracted command.}",
          "\\label{tab:dual_e1}", "\\footnotesize", "\\begin{tabularx}{\\linewidth}{l Y Y Y Y Y Y}", "\\toprule",
          "Controller & Bound viol.\\ [rad] & Margin pen.\\ [rad] & Command residual & Chain [mm / mrad] & Tilt [deg] & Internal force [N] \\\\",
          "\\midrule"]
    for nm in ("PR", "PR-noretract", "PR-noineq", "Unified", "Unified-eps0", "Shield", "DualGuard", "GS"):
        if nm not in E1:
            continue
        v = E1[nm]
        cmd = v["cmd_model_max"][0]
        cmd_s = "--" if cmd != cmd else (sci(cmd) if cmd < 1e-3 else f"{cmd:.3f}")
        t1.append(f"{LABEL[nm]} & {v['bound_viol'][0]:.3f} & {v['margin_pen'][0]:.3f} & {cmd_s} & "
                  f"{v['meas_chain_trans_mm'][0]:.2f} / {v['meas_chain_rot_mrad'][0]:.2f} & {v['meas_tilt_deg'][0]:.2f} & "
                  f"{v['W_int_norm_mean'][0]:.2f} \\\\")
    t1 += ["\\bottomrule", "\\end{tabularx}", "\\end{table}"]
    base = E2["PR"]["0.0"]["Fy"][0]
    t2 = ["\\begin{table}[h]", "\\centering",
          "\\caption{E2: mean internal force [N] against the calibration error $\\delta_b$ of the right-arm base (three seeds, $t\\ge1$\\,s).}",
          "\\label{tab:dual_e2}", "\\small", "\\begin{tabularx}{\\linewidth}{l Y Y Y Y}", "\\toprule",
          "Controller & $\\delta_b=0$ & $0.5$\\,mm & $1$\\,mm & $2$\\,mm \\\\", "\\midrule",
          "Prop.~\\ref{prop:physvirt}(b), closed chain & " + " & ".join(
              f"{base + GAIN_FINAL * d:.2f}" for d in (0.0, 0.5, 1.0, 2.0)) + " \\\\"]
    for nm in ("PR", "PR-anchored", "Unified"):
        t2.append(LABEL[nm] + " & " + " & ".join(f"{E2[nm][str(d)]['Fnorm'][0]:.2f}" for d in (0.0, 0.5, 1.0, 2.0)) + " \\\\")
    t2 += ["\\bottomrule", "\\end{tabularx}", "\\end{table}"]
    pr = E2["PR"]
    err = max(abs(pr[str(d)]["Fy"][0] - (base + GAIN_FINAL * d)) / (base + GAIN_FINAL * d) for d in (0.5, 1.0, 2.0))
    findings = [
        "\\begin{enumerate}",
        "\\item E1 reproduces the pattern of PR-MPPI Table~II.",
        f"Full PR-MPPI never crossed the bound and returned commands that satisfy the model equality to {sci(E1['PR']['cmd_model_max'][0])}.",
        f"Without retraction the command residual grew to {E1['PR-noretract']['cmd_model_max'][0]:.2f} and the tray tilted by {E1['PR-noretract']['meas_tilt_deg'][0]:.1f}\\,deg on average; without inequality projection the cost penalty let joint~4 cross the bound by {E1['PR-noineq']['bound_viol'][0]:.3f}\\,rad (the manuscript reports 0.022\\,rad).",
        f"The unified controller, with its joint rows tightened by the calibrated execution-error bounds below, kept the bound, using {E1['Unified']['margin_pen'][0]:.3f} of the 0.05\\,rad margin, and held the internal wrench inside its box ({E1['Unified']['W_int_norm_mean'][0]:.2f}\\,N); "
        + (f"its tray tilt of {E1['Unified']['meas_tilt_deg'][0]:.1f}\\,deg is larger than that of PR-MPPI ({E1['PR']['meas_tilt_deg'][0]:.2f}\\,deg) because the 1\\,kg tray is unmodelled and the command is pure feed-forward."
           if E1["Unified"]["meas_tilt_deg"][0] > E1["PR"]["meas_tilt_deg"][0] else
           f"its tray tilt was {E1['Unified']['meas_tilt_deg'][0]:.1f}\\,deg, against {E1['PR']['meas_tilt_deg'][0]:.1f}\\,deg for PR-MPPI, although the 1\\,kg tray is unmodelled and the command is pure feed-forward."),
        f"\\item The internal force of PR-MPPI grew linearly with the calibration error, as the closed-chain form of Proposition~\\ref{{prop:physvirt}}(b) predicts: the zero-error baseline plus $(C_l+C_r+2C_g)^{{-1}}\\delta_b$, with the compliances of the two interpolated computed-torque loops and of the grasp springs at the final configuration ({GAIN_FINAL:.2f}\\,N/mm), matches the measurement to within {100 * err:.0f}\\%.",
        f"Anchoring (Proposition~\\ref{{prop:anchor}}) removed it: {E2['PR-anchored']['2.0']['Fnorm'][0]:.2f}\\,N at every $\\delta_b$.",
        f"The unified controller is exactly invariant ({E2['Unified']['0.0']['Fnorm'][0]:.2f}\\,N at every $\\delta_b$), since a translation of the base changes no Jacobian and the Gauss dynamics use nothing else (Proposition~\\ref{{prop:physvirt}}(a)).",
        f"\\item The margin of Algorithm~\\ref{{alg:unified}} is needed here as well.",
        f"Without it ($\\varepsilon=0$) the unified controller crossed the bound by {E1['Unified-eps0']['bound_viol'][0]:.3f}\\,rad in every run: the command rides the barrier, and the unmodelled tray makes the realized acceleration of joint~4 lag the command by about 0.9\\,rad/s$^2$ in steady state.",
        f"The bounds are calibrated like those of the waiter, as 1.5 times the largest period-averaged deviation of each joint acceleration from the model in separate runs of the untightened controller ($\\delta_b\\in\\{{0,2\\}}$\\,mm, seeds 100 and 101): {min(EX['eps_qdd_joint']):.1f}--{max(EX['eps_qdd_joint'][i] for i in (0, 1, 2, 3, 7, 8, 9, 10)):.1f}\\,rad/s$^2$ for the shoulder and elbow joints and up to {max(EX['eps_qdd_joint']):.0f}\\,rad/s$^2$ at the wrists, where the grasp springs oscillate.",
        f"They are conservative: the tightened controller stopped {E1['Unified']['goal_err'][0]:.2f}\\,rad from the goal, against {E1['PR']['goal_err'][0]:.3f}\\,rad for PR-MPPI and {E1['Unified-eps0']['goal_err'][0]:.3f}\\,rad without the margin; modelling the tray load would shrink them (open item).",
        "\\item The warm start must append a zero input, as in Algorithm~1 of PR-MPPI.",
        "Repeating the last input instead carried the tracking velocity past the goal and drove joint~4 0.6\\,rad beyond the bound in the ablation without inequality projection, which the CBF rows of the full controller had masked.",
        "\\end{enumerate}",
    ]
    tpl = (HERE / "dualarm_section.tex.in").read_text(encoding="utf-8")
    out = tpl.replace("@@TABLES@@", "\n".join(t1 + [""] + t2)).replace("@@FINDINGS@@", "\n".join(findings))
    (HERE.parent / "tier2" / "dualarm_section.tex").write_text(out, encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
