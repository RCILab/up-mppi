"""GPU (NVIDIA Warp) order-2 controllers on the curved-surface writing task: the unified controller
with the separable solver (Theorem 1: tangential QP + reaction clamp) and with the joint composite
projection (CAMP-MPPI Eq. 37), same model, rows, costs and float32 arithmetic, so their timings
compare the solvers alone.  Formulas as in umppi/writing.py and controllers.CAMPMPPI
(virtual="hard"); umppi/tests/test_warp_writing.py checks both against numpy.
"""
import numpy as np
import torch
import warp as wp

from . import writing as W_
from .warp_mppi import chol, chol_solve, mat37, mat73, mat77, row_of, vec7, zrow

wp.init()

NRW = 20  # row capacity: at most 3 equalities + 2 reaction rows + 14 box rows
matW7 = wp.types.matrix(shape=(NRW, 7), dtype=wp.float32)
vecW = wp.types.vector(length=NRW, dtype=wp.float32)
ivec8 = wp.types.vector(length=8, dtype=wp.int32)
mat78 = wp.types.matrix(shape=(7, 8), dtype=wp.float32)
mat88 = wp.types.matrix(shape=(8, 8), dtype=wp.float32)
vec8 = wp.types.vector(length=8, dtype=wp.float32)


@wp.func
def wrow(C: matW7, i: int):
    r = vec7()
    for j in range(7):
        r[j] = C[i, j]
    return r


@wp.func
def solve_active_w(Lm: mat77, C: matW7, d: vecW, xt: vec7, act: ivec8, na: int):
    """KKT solution for the active rows; ok = 0 if the active rows are (numerically) dependent."""
    Wm = mat78()
    for a in range(na):
        w = chol_solve(Lm, wrow(C, act[a]))
        for j in range(7):
            Wm[j, a] = w[j]
    G = mat88()
    rhs = vec8()
    for a in range(na):
        ca = wrow(C, act[a])
        rhs[a] = wp.dot(ca, xt) - d[act[a]]
        for b in range(na):
            s = float(0.0)
            for j in range(7):
                s = s + ca[j] * Wm[j, b]
            G[a, b] = s
    ok = int(1)
    Lg = mat88()
    for j in range(na):
        s = G[j, j]
        for k in range(j):
            s = s - Lg[j, k] * Lg[j, k]
        if s < 1.0e-7 * G[j, j]:
            ok = 0
        ljj = wp.sqrt(wp.max(s, 1.0e-20))
        Lg[j, j] = ljj
        for i in range(j + 1, na):
            t = G[i, j]
            for k in range(j):
                t = t - Lg[i, k] * Lg[j, k]
            Lg[i, j] = t / ljj
    y = vec8()
    for i in range(na):
        s = rhs[i]
        for k in range(i):
            s = s - Lg[i, k] * y[k]
        y[i] = s / Lg[i, i]
    lam = vec8()
    for ii in range(na):
        i = na - 1 - ii
        s = y[i]
        for k in range(i + 1, na):
            s = s - Lg[k, i] * lam[k]
        lam[i] = s / Lg[i, i]
    x = xt
    for a in range(na):
        for j in range(7):
            x[j] = x[j] - Wm[j, a] * lam[a]
    return x, lam, ok


@wp.func
def project_w(Lm: mat77, C: matW7, d: vecW, xt: vec7, n_eq: int, n_use: int):
    """Exact inertia-metric projection onto rows [0, n_eq) as equalities and [n_eq, n_use) as
    inequalities, by a dual active-set method.  status 0 ok, 1 infeasible or not converged."""
    act = ivec8()
    for a in range(n_eq):
        act[a] = a
    na = int(n_eq)
    x = xt
    status = int(1)
    for it in range(40):
        x, lam, ok = solve_active_w(Lm, C, d, xt, act, na)
        if ok == 0:  # the last added row depends on the active ones: infeasible with this set
            break
        imin = int(-1)
        lmin = float(-1.0e-7)
        for a in range(n_eq, na):
            if lam[a] < lmin:
                lmin = lam[a]
                imin = a
        if imin >= 0:
            act[imin] = act[na - 1]
            na = na - 1
            continue
        imax = int(-1)
        vmax = float(1.0e-5)
        for i in range(n_eq, n_use):
            inA = int(0)
            for a in range(na):
                if act[a] == i:
                    inA = 1
            if inA == 0:
                v = wp.dot(wrow(C, i), x) - d[i]
                if v > vmax:
                    vmax = v
                    imax = i
        if imax < 0:
            status = 0
            break
        if na >= 7:
            break
        act[na] = imax
        na = na + 1
    return x, status


@wp.func
def normalise_rows(C: matW7, d: vecW, n_rows: int):
    for i in range(n_rows):
        nrm = float(0.0)
        for j in range(7):
            nrm = nrm + C[i, j] * C[i, j]
        nrm = wp.sqrt(nrm)
        if nrm > 1.0e-9:
            for j in range(7):
                C[i, j] = C[i, j] / nrm
            d[i] = d[i] / nrm
    return C, d


@wp.kernel
def rollout_writing(
    q0: vec7, qd0: vec7, U: wp.array(dtype=vec7), eps: wp.array2d(dtype=vec7),
    Rx: wp.array(dtype=wp.mat33), P: wp.array(dtype=wp.vec3), COM: wp.array(dtype=wp.vec3),
    MASS: wp.array(dtype=float), IL: wp.array(dtype=wp.mat33), ARM: vec7,
    base_rot: wp.mat33, base_pos: wp.vec3, tool: wp.vec3,
    qmin: vec7, qmax: vec7, qdmax: vec7, prm: wp.array(dtype=float), cs: wp.vec3,
    qref: vec7, tgt: wp.array(dtype=wp.vec3), H: int, joint: int,
    Aout: wp.array2d(dtype=vec7), Sout: wp.array(dtype=float), relax: wp.array(dtype=wp.int32),
):
    k = wp.tid()
    dt = prm[0]
    h_safe = prm[1]
    k1 = prm[2]
    k2 = prm[3]
    KP = prm[4]
    KD = prm[5]
    lam_lo = prm[6]
    lam_hi = prm[7]
    lam_nom = prm[8]
    w_p = prm[9]
    w_v = prm[10]
    w_q = prm[11]
    w_f = prm[12]
    w_T = prm[13]
    rs = prm[14]  # R_S + delta
    mode = int(prm[15])  # 0: reaction band enforced (clamp); 1: band as a penalty of weight w_s (baseline)
    w_s = prm[16]
    ex = wp.vec3(1.0, 0.0, 0.0)
    ey = wp.vec3(0.0, 1.0, 0.0)
    q = q0
    qd = qd0
    S = float(0.0)
    lam_prev = float(0.0)
    nrelax = int(0)
    for t in range(H + 1):
        # ---------------- model: forward kinematics and mass matrix in one pass
        R = base_rot
        o = base_pos
        Z = mat73()
        O = mat73()
        M = mat77()
        for i in range(7):
            o = o + R * P[i]
            c = wp.cos(q[i])
            s = wp.sin(q[i])
            Rz = wp.mat33(c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0)
            R = R * Rx[i] * Rz
            for m in range(3):
                Z[i, m] = R[m, 2]
                O[i, m] = o[m]
            pci = o + R * COM[i]
            Iw = R * IL[i] * wp.transpose(R)
            for j in range(i + 1):
                zj = zrow(Z, j)
                cj = wp.cross(zj, pci - zrow(O, j))
                Izj = Iw * zj
                for l in range(j + 1):
                    zl = zrow(Z, l)
                    cl = wp.cross(zl, pci - zrow(O, l))
                    val = MASS[i] * wp.dot(cj, cl) + wp.dot(zl, Izj)
                    M[j, l] = M[j, l] + val
                    if l != j:
                        M[l, j] = M[l, j] + val
        for i in range(7):
            M[i, i] = M[i, i] + ARM[i]
        pt = o + R * tool
        if t > 0:  # running cost of the state reached by step t-1 (reaction of that step)
            dp = pt - tgt[t - 1]
            dq = q - qref
            dl = lam_prev - lam_nom
            S = S + dt * (w_p * wp.dot(dp, dp) + w_v * wp.dot(qd, qd) + w_q * wp.dot(dq, dq) + w_f * dl * dl)
        if t == H:
            dp = pt - tgt[H - 1]
            S = S + w_T * wp.dot(dp, dp)
            break
        Jv = mat37()
        vpt = wp.vec3(0.0, 0.0, 0.0)
        w = wp.vec3(0.0, 0.0, 0.0)
        for j in range(7):
            zj = zrow(Z, j)
            cj = wp.cross(zj, pt - zrow(O, j))
            for m in range(3):
                Jv[m, j] = cj[m]
            vpt = vpt + cj * qd[j]
            w = w + zj * qd[j]
        ab = wp.vec3(0.0, 0.0, 0.0)
        alb = wp.vec3(0.0, 0.0, 0.0)
        wprev = wp.vec3(0.0, 0.0, 0.0)
        for j in range(7):
            zj = zrow(Z, j)
            oj = zrow(O, j)
            voj = wp.vec3(0.0, 0.0, 0.0)
            for i in range(j):
                voj = voj + wp.cross(zrow(Z, i), oj - zrow(O, i)) * qd[i]
            zdot = wp.cross(wprev, zj)
            ab = ab + (wp.cross(zdot, pt - oj) + wp.cross(zj, vpt - voj)) * qd[j]
            alb = alb + zdot * qd[j]
            wprev = wprev + zj * qd[j]
        # ---------------- physical row (contact with the sphere) and Gauss dynamics
        r = pt - cs
        rho = wp.length(r)
        nh = r / rho
        Jc = vec7()
        for j in range(7):
            Jc[j] = nh[0] * Jv[0, j] + nh[1] * Jv[1, j] + nh[2] * Jv[2, j]
        pn = wp.dot(nh, vpt)
        jcd = wp.dot(nh, ab) + (wp.dot(vpt, vpt) - pn * pn) / rho
        Lm = chol(M)
        MiJt = chol_solve(Lm, Jc)
        Lam = 1.0 / wp.dot(Jc, MiJt)
        f = MiJt * (-Lam * jcd)
        # ---------------- virtual rows (pen axis vertical): e, Jo, jod ; stabilised right-hand side
        zt = wp.vec3(R[0, 2], R[1, 2], R[2, 2])
        ztd = wp.cross(w, zt)
        Jo1 = vec7()
        Jo2 = vec7()
        ax = wp.cross(zt, ex)
        ay = wp.cross(zt, ey)
        for j in range(7):
            zj = zrow(Z, j)
            Jo1[j] = wp.dot(ax, zj)
            Jo2[j] = wp.dot(ay, zj)
        jod1 = wp.dot(wp.cross(ztd, ex), w) + wp.dot(ax, alb)
        jod2 = wp.dot(wp.cross(ztd, ey), w) + wp.dot(ay, alb)
        rv1 = -KD * wp.dot(Jo1, qd) - KP * zt[0] - wp.dot(Jo1, f) - jod1
        rv2 = -KD * wp.dot(Jo2, qd) - KP * zt[1] - wp.dot(Jo2, f) - jod2
        # ---------------- HOCBF and velocity rows on x = qdd - f
        sg = k1 + k2
        pg = k1 * k2
        dlo = vec7()
        dhi = vec7()
        for j in range(7):
            lo = q[j] - (qmin[j] + h_safe)
            hi = (qmax[j] - h_safe) - q[j]
            dlo[j] = wp.min(f[j] + sg * qd[j] + pg * lo, (qdmax[j] + qd[j]) / dt + f[j])
            dhi[j] = wp.min(-f[j] - sg * qd[j] + pg * hi, (qdmax[j] - qd[j]) / dt - f[j])
        araw = U[t] + eps[k, t]
        C = matW7()
        dd = vecW()
        a = vec7()
        if joint == 0:
            # separable: tangential QP in x, then the reaction clamp (Theorem 1)
            for j in range(7):
                C[0, j] = Jc[j]
                C[1, j] = Jo1[j]
                C[2, j] = Jo2[j]
                C[3 + j, j] = -1.0
                C[10 + j, j] = 1.0
                dd[3 + j] = dlo[j]
                dd[10 + j] = dhi[j]
            dd[1] = rv1
            dd[2] = rv2
            C, dd = normalise_rows(C, dd, 17)
            # xt = F araw = araw - MiJt Lam (Jc . araw)
            xt = araw - MiJt * (Lam * wp.dot(Jc, araw))
            x, st = project_w(Lm, C, dd, xt, 3, 17)
            if st != 0:
                x, st = project_w(Lm, C, dd, xt, 3, 3)
                nrelax = nrelax + 1
            lraw = -Lam * (wp.dot(Jc, araw) + jcd)
            lam = lraw
            if mode == 0:
                lam = wp.clamp(lraw, lam_lo, lam_hi)
            a = x - MiJt * (lam + Lam * jcd)
        else:
            # joint composite projection in a: F rows, reaction rows, virtual rows through F
            for i in range(7):
                for j in range(7):
                    Fij = -MiJt[i] * Lam * Jc[j]
                    if i == j:
                        Fij = Fij + 1.0
                    C[4 + i, j] = -Fij
                    C[11 + i, j] = Fij
                dd[4 + i] = dlo[i]
                dd[11 + i] = dhi[i]
            # virtual rows Jo F a = rv ;  Jo F = Jo - (Jo . MiJt) Lam Jc
            g1 = wp.dot(Jo1, MiJt) * Lam
            g2 = wp.dot(Jo2, MiJt) * Lam
            for j in range(7):
                C[0, j] = Jo1[j] - g1 * Jc[j]
                C[1, j] = Jo2[j] - g2 * Jc[j]
                C[2, j] = Lam * Jc[j]  # G0 a <= -lo - Lam jcd
                C[3, j] = -Lam * Jc[j]  # -G0 a <= hi + Lam jcd
            dd[0] = rv1
            dd[1] = rv2
            dd[2] = -lam_lo - Lam * jcd
            dd[3] = lam_hi + Lam * jcd
            C, dd = normalise_rows(C, dd, 18)
            a, st = project_w(Lm, C, dd, araw, 2, 18)
            if st != 0:  # reaction rows kept hard, motion rows relaxed
                a, st = project_w(Lm, C, dd, araw, 2, 4)
                nrelax = nrelax + 1
        Aout[k, t] = a
        # rollout: qdd = F a + f, reaction of this step
        lam_prev = -Lam * (wp.dot(Jc, a) + jcd)
        if mode == 1:
            b1 = wp.max(lam_lo - lam_prev, 0.0)
            b2 = wp.max(lam_prev - lam_hi, 0.0)
            S = S + dt * w_s * (b1 * b1 + b2 * b2)
        qdd = a - MiJt * (Lam * wp.dot(Jc, a)) + f
        qd = qd + qdd * dt
        q = q + qd * dt
    Sout[k] = S
    relax[k] = nrelax


class WarpWritingMPPI:
    """GPU counterpart of controllers.CAMPMPPI(metric="M", virtual="hard", solver=...)."""

    def __init__(self, chain, solver="separable", K=256, H=15, dt=0.01, sigma=0.8, eta=0.5, k1=4.0, k2=4.0,
                 KP=100.0, KD=20.0, w_p=1e5, w_T=1e4, w_v=5.0, w_q=5.0, w_f=1.0, h_safe=0.05, delta=0.0,
                 seed=0, device="cuda:0", mode="hard", w_s=100.0, exec_project=False, average="projected",
                 noise_clip=3.0, nominal="raw", reaction="clamped"):
        """mode "penalty": the reaction band as a cost of weight w_s instead of the clamp (baseline A1);
        exec_project: exact projection of the executed command (baseline A2); average "raw": the MPPI update
        on the raw inputs with the executed command projected once at the measured state (Algorithm 1);
        noise_clip: exploration noise truncated at this many standard deviations."""
        from .robot import Q_MAX, Q_MIN, QD_MAX
        self.mode, self.w_s, self.exec_project = mode, w_s, exec_project or average == "raw"
        self.delta, self._helper, self.average, self.noise_clip = delta, None, average, noise_clip
        self.nominal = nominal  # "filtered": warm start from the execution-filtered raw average
        self.reaction = reaction  # with average "raw": "clamped" executes the average of the clamped sample reactions
        self.kw = dict(k1=k1, k2=k2, KP=KP, KD=KD, w_p=w_p, w_T=w_T, w_v=w_v, w_q=w_q, w_f=w_f, h_safe=h_safe)
        self.chain, self.solver, self.K, self.H, self.dt, self.sigma, self.eta = chain, solver, K, H, dt, sigma, eta
        self.dev = device
        f32 = lambda a: np.asarray(a, dtype=np.float32)  # noqa: E731
        self.Rx = wp.array(f32(chain.Rx), dtype=wp.mat33, device=device)
        self.P = wp.array(f32(chain.p), dtype=wp.vec3, device=device)
        self.COM = wp.array(f32(chain.com), dtype=wp.vec3, device=device)
        self.MASS = wp.array(f32(chain.mass), dtype=float, device=device)
        self.IL = wp.array(f32(chain.I), dtype=wp.mat33, device=device)
        self.ARM = vec7(*f32(chain.armature))
        self.base_rot, self.base_pos = wp.mat33(*f32(chain.base_rot).ravel()), wp.vec3(*f32(chain.base_pos))
        self.tool = wp.vec3(*f32(chain.tool))
        self.qmin, self.qmax, self.qdmax = vec7(*f32(Q_MIN)), vec7(*f32(Q_MAX)), vec7(*f32(QD_MAX))
        lo, hi = W_.LAM_BAND
        self.prm = wp.array(f32([dt, h_safe, k1, k2, KP, KD, lo, hi, W_.LAM_NOM, w_p, w_v, w_q, w_f, w_T,
                                 W_.R_S + delta, 1.0 if mode == "penalty" else 0.0, w_s]), dtype=float, device=device)
        # final projection: the same kernel, one thread, one step, zero noise, the band enforced
        self.prm1 = wp.array(f32([dt, h_safe, k1, k2, KP, KD, lo, hi, W_.LAM_NOM, w_p, w_v, w_q, w_f, w_T,
                                  W_.R_S + delta, 0.0, w_s]), dtype=float, device=device)
        self.U1_t = torch.zeros((H, 7), device="cuda")
        self.eps1_t = torch.zeros((1, H, 7), device="cuda")
        self.U1_w, self.eps1_w = wp.from_torch(self.U1_t, dtype=vec7), wp.from_torch(self.eps1_t, dtype=vec7)
        self.A1 = wp.zeros((1, H), dtype=vec7, device=device)
        self.S1 = wp.zeros(1, dtype=float, device=device)
        self.r1 = wp.zeros(1, dtype=wp.int32, device=device)
        self.cs = wp.vec3(*f32(W_.C_S))
        self.U = np.zeros((H, 7), dtype=np.float32)
        self.q_ref = None
        self.Aout = wp.zeros((K, H), dtype=vec7, device=device)
        self.Sout = wp.zeros(K, dtype=float, device=device)
        self.relax = wp.zeros(K, dtype=wp.int32, device=device)
        self.gen = torch.Generator(device="cuda").manual_seed(seed)
        self.rng = None
        self.stats = {"time": [], "relaxed": 0, "fallback": 0, "calls": 0, "exec_relaxed": 0}
        self.tgt_t = torch.zeros((H, 3), device="cuda")
        self.U_t = torch.zeros((H, 7), device="cuda")
        self.eps_t = torch.zeros((K, H, 7), device="cuda")
        self.tgt_w, self.U_w = wp.from_torch(self.tgt_t, dtype=wp.vec3), wp.from_torch(self.U_t, dtype=vec7)
        self.eps_w = wp.from_torch(self.eps_t, dtype=vec7)

    def plan(self, q0, qd0, t_now, eps=None, return_samples=False):
        import time as _t
        t0 = _t.perf_counter()
        K, H = self.K, self.H
        if self.q_ref is None:
            self.q_ref = np.asarray(q0, dtype=np.float32).copy()
        c = self.noise_clip
        if eps is None and self.rng is not None:
            z = self.rng.standard_normal((K, H, 7))
            eps = self.sigma * (z if c is None else np.clip(z, -c, c))
        if eps is None:
            torch.randn((K, H, 7), generator=self.gen, device="cuda", out=self.eps_t)
            if c is not None:
                self.eps_t.clamp_(-c, c)
            self.eps_t.mul_(self.sigma)
        else:
            self.eps_t.copy_(torch.from_numpy(np.asarray(eps, dtype=np.float32)))
        self.tgt_t.copy_(torch.from_numpy(W_.path_point(t_now + self.dt * np.arange(1, H + 1)).astype(np.float32)))
        self.U_t.copy_(torch.from_numpy(self.U.astype(np.float32)))
        prof = getattr(self, "profile", False)
        if prof:
            wp.synchronize()
            tk = _t.perf_counter()
        wp.launch(rollout_writing, dim=K, device=self.dev, inputs=[
            vec7(*np.asarray(q0, np.float32)), vec7(*np.asarray(qd0, np.float32)), self.U_w, self.eps_w,
            self.Rx, self.P, self.COM, self.MASS, self.IL, self.ARM,
            self.base_rot, self.base_pos, self.tool, self.qmin, self.qmax, self.qdmax, self.prm, self.cs,
            vec7(*self.q_ref), self.tgt_w, H, 1 if self.solver == "joint" else 0, self.Aout, self.Sout, self.relax])
        if prof:
            wp.synchronize()
            self.stats.setdefault("kernel", []).append(_t.perf_counter() - tk)
        S = wp.to_torch(self.Sout)
        A = wp.to_torch(self.Aout).view(K, H, 7)
        beta = torch.clamp(self.eta * S.std(unbiased=False), min=1e-12)
        wgt = torch.exp(-(S - S.min()) / beta)
        wgt = wgt / wgt.sum()
        if self._helper is None:  # numpy model at the measured state (reaction map of the executed command)
            from .controllers import CAMPMPPI
            self._helper = CAMPMPPI(self.chain, sigma=self.sigma, metric="M", solver="separable", virtual="hard",
                                    dt=self.dt, H=self.H, K=1, delta=self.delta, **self.kw)
        if self.average == "raw":
            As = self.U + torch.einsum("k,kti->ti", wgt, self.eps_t).cpu().numpy()
        else:
            As = torch.einsum("k,kti->ti", wgt, A).cpu().numpy()
        self.U = np.concatenate([As[1:], np.zeros((1, 7), dtype=np.float32)], 0).astype(np.float32)
        a0 = As[0].astype(np.float64)
        mdl = None
        if self.exec_project:  # execution filtering: one thread, the whole horizon, zero noise, the band enforced
            self.U1_t.copy_(torch.from_numpy(np.asarray(As, np.float32)))
            wp.launch(rollout_writing, dim=1, device=self.dev, inputs=[
                vec7(*np.asarray(q0, np.float32)), vec7(*np.asarray(qd0, np.float32)), self.U1_w, self.eps1_w,
                self.Rx, self.P, self.COM, self.MASS, self.IL, self.ARM,
                self.base_rot, self.base_pos, self.tool, self.qmin, self.qmax, self.qdmax, self.prm1, self.cs,
                vec7(*self.q_ref), self.tgt_w, H if self.nominal == "filtered" else 1, 1 if self.solver == "joint" else 0,
                self.A1, self.S1, self.r1])
            Af = self.A1.numpy()[0].astype(np.float64)
            a0 = Af[0]
            if self.nominal == "filtered":
                self.U = np.concatenate([Af[1:], np.zeros((1, 7))], 0).astype(np.float32)
            self.stats["exec_relaxed"] += int(self.r1.numpy()[0])
            if self.average == "raw" and self.mode == "hard" and self.reaction == "clamped":
                # Separation (Thm. 1): the motion part comes from the projection of the raw average, the reaction
                # from the average of the clamped sample reactions (in the band by convexity); the reaction map
                # of the measured state is used for every horizon step of the warm start
                mdl = self._helper._model(np.asarray(q0, float)[None], np.asarray(qd0, float)[None])
                Lam, Jc, jcd, MiJt = mdl["Lam"][0, 0, 0], mdl["Jc"][0, 0], mdl["jcd"][0, 0], mdl["MiJt"][0][:, 0]
                lam_k = -Lam * (A.double().cpu().numpy() @ Jc + jcd)  # (K, H): clamped reaction of every sample
                lam_bar = wgt.double().cpu().numpy() @ lam_k  # (H,)
                a0 = a0 + MiJt * (-Lam * (Jc @ a0 + jcd) - lam_bar[0])
                lam_U = -Lam * (self.U.astype(np.float64) @ Jc + jcd)
                lam_tgt = np.concatenate([lam_bar[1:], [lam_bar[-1]]])
                self.U = (self.U + (lam_U - lam_tgt)[:, None] * MiJt[None]).astype(np.float32)
        self.stats["relaxed"] += int(wp.to_torch(self.relax).sum().item())
        self.stats["time"].append(_t.perf_counter() - t0)
        if mdl is None:  # only to log the commanded reaction (outside the timing)
            mdl = self._helper._model(np.asarray(q0, float)[None], np.asarray(qd0, float)[None])
        lam0 = float(-(mdl["Lam"][0] @ (mdl["Jc"][0] @ a0 + mdl["jcd"][0]))[0])
        out = {"a": a0, "lam_cmd": lam0}
        if return_samples:
            out.update(A=A.cpu().numpy(), S=S.cpu().numpy(), w=wgt.cpu().numpy())
        return out
