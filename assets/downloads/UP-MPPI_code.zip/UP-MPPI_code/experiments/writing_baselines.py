"""Baselines on the curved-surface writing task, surface-model offset delta in {-1, 0, +1} mm.

A1  penalty MPPI: the reaction band as a cost of weight w_s instead of the clamp (motion rows hard)
A2  penalty MPPI with the raw average and the executed command projected exactly onto all rows, band included
A3  one-step QP with the contact in the Gauss dynamics, the band hard (no horizon)
MPPI variants run on the GPU controller (separable structure) with the numpy noise draws.
Writes results/writing_baselines.json.
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import writing_exp as X  # noqa: E402

W_SWEEP = (1.0, 10.0, 100.0, 1000.0)


def _job(a):
    label, w, dl, seed, T = a
    import warnings
    warnings.filterwarnings("ignore")
    from umppi.baselines import OneStepQPWriting
    from umppi.warp_writing import WarpWritingMPPI
    O2 = dict(dt=X.DT, H=X.H, K=X.K, sigma=0.8, w_p=1e5, w_T=1e4, w_v=5.0)
    if label in ("penalty", "penalty-exec"):
        fac = lambda ch, delta: WarpWritingMPPI(ch, solver="separable", delta=delta, mode="penalty", w_s=w,  # noqa: E731
                                              average="raw" if label == "penalty-exec" else "projected", **O2)
    elif label == "unified-gpu":
        fac = lambda ch, delta: WarpWritingMPPI(ch, solver="separable", delta=delta, average="raw", **O2)  # noqa: E731
    else:
        fac = lambda ch, delta: OneStepQPWriting(ch, delta=delta, dt=X.DT)  # noqa: E731
    try:
        r, _ = X.run(label, dl, T=T, seed=seed, controller_factory=fac)
    except Exception as exc:
        return {"controller": label, "w_s": w, "delta_mm": dl, "seed": seed, "error": repr(exc)}
    r.update(controller=label, w_s=w, seed=seed)
    return r


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--procs", type=int, default=6)
    ap.add_argument("--T", type=float, default=X.W_.T_PATH)
    args = ap.parse_args()
    jobs = []
    for s in range(args.seeds):
        for dl in (-1.0, 0.0, 1.0):
            jobs += [("penalty", w, dl, s, args.T) for w in W_SWEEP]
            jobs += [("penalty-exec", w, dl, s, args.T) for w in W_SWEEP]
            jobs += [("onestep", None, dl, s, args.T), ("unified-gpu", None, dl, s, args.T)]
    out = Path(__file__).resolve().parent / "results" / "writing_baselines.json"
    rows = []
    with Pool(args.procs) as pool:
        for r in pool.imap_unordered(_job, jobs):
            rows.append(r)
            keys = ("controller", "w_s", "delta_mm", "seed", "track_rmse_mm", "force_mean", "in_band", "contact",
                    "ori_rms_deg", "lam_cmd_range", "ms_per_step", "diverged_t", "relaxed", "error")
            print(json.dumps({k: (round(r[k], 3) if isinstance(r.get(k), float) else r.get(k)) for k in keys if k in r}), flush=True)
            out.write_text(json.dumps({"rows": rows}))
