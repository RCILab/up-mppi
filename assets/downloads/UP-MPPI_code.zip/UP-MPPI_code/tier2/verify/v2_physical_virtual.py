"""T2 -- physical vs virtual equalities.

Prop 2b: position-level enforcement of a PHYSICAL equality (order-1 retraction onto a
model manifold offset by delta, tracked by a stiff joint-space loop K) produces a reaction
    lam = (Lam_K^-1 + k_env^-1)^-1 delta + O(delta^2),   Lam_K = (Jc K^-1 Jc^T)^-1,
which no inequality of the order-1 controller sees.
Prop 2a: at order 2 the commanded reaction depends on the constraint model only through
(Jc, Jc_dot q_dot) at the measured state, so it equals lam_des for every offset.

Setup: planar 3R arm, pen tip on a horizontal floor, last link pointing down.
"""
import numpy as np
from scipy.optimize import fsolve

from common import Report, null_basis

L = np.array([0.40, 0.35, 0.25])
MASS = np.array([2.0, 1.5, 0.8])
X0, Y_MODEL = 0.50, -0.25  # commanded tip position on the MODEL floor


def fk(q):
    th = np.cumsum(q)
    return np.array([np.sum(L * np.cos(th)), np.sum(L * np.sin(th))])


def jac(q):
    th = np.cumsum(q)
    Jx = np.array([-np.sum(L[j:] * np.sin(th[j:])) for j in range(3)])
    Jy = np.array([np.sum(L[j:] * np.cos(th[j:])) for j in range(3)])
    return np.vstack([Jx, Jy])


def mass_matrix(q):
    """Uniform rods: M = sum m_i Jc_i^T Jc_i + I_i Jw_i^T Jw_i."""
    th = np.cumsum(q)
    M = np.zeros((3, 3))
    for i in range(3):
        Jc = np.zeros((2, 3))
        for j in range(i + 1):
            # COM of link i: joints j..i-1 full lengths, link i half length
            lengths = np.concatenate([L[j:i], [L[i] / 2]])
            angles = th[j:i + 1]
            Jc[0, j] = -np.sum(lengths * np.sin(angles))
            Jc[1, j] = np.sum(lengths * np.cos(angles))
        Jw = np.array([1.0 if j <= i else 0.0 for j in range(3)])
        M += MASS[i] * Jc.T @ Jc + (MASS[i] * L[i] ** 2 / 12) * np.outer(Jw, Jw)
    return M


def ik_pen_down(x, y):
    """Tip at (x, y) with the last link pointing straight down (elbow up)."""
    wx, wy = x, y + L[2]
    d2 = wx ** 2 + wy ** 2
    c2 = (d2 - L[0] ** 2 - L[1] ** 2) / (2 * L[0] * L[1])
    q2 = -np.arccos(np.clip(c2, -1, 1))
    q1 = np.arctan2(wy, wx) - np.arctan2(L[1] * np.sin(q2), L[0] + L[1] * np.cos(q2))
    q3 = -np.pi / 2 - q1 - q2
    return np.array([q1, q2, q3])


def equilibrium(q_cmd, K, y_real, k_env=None, lam_guess=0.0):
    """Static equilibrium of a PD-held arm (gravity compensated) against a frictionless floor."""
    def F(z):
        q, lam = z[:3], z[3]
        Jy = jac(q)[1]
        r = list(K @ (q_cmd - q) + Jy * lam)
        if k_env is None:
            r.append(fk(q)[1] - y_real)
        else:
            r.append(lam - k_env * (y_real - fk(q)[1]))
        return r
    sol, info, _, _ = fsolve(F, np.concatenate([q_cmd, [lam_guess]]), full_output=True, xtol=1e-14)
    assert np.max(np.abs(info["fvec"])) < 1e-11, info["fvec"]
    return sol[:3], sol[3]


def main():
    rep = Report("T2 physical vs virtual")
    q_cmd = ik_pen_down(X0, Y_MODEL)  # order-1 retraction lands exactly here (model floor)
    assert np.allclose(fk(q_cmd), [X0, Y_MODEL])
    Jy = jac(q_cmd)[1]
    stiffness = {
        "joint PD diag(400,300,150)": np.diag([400.0, 300.0, 150.0]),
        "computed torque M(q)(2pi*10Hz)^2": mass_matrix(q_cmd) * (2 * np.pi * 10) ** 2,
    }
    deltas = np.array([0.05, 0.1, 0.2, 0.5, 1.0, 2.0]) * 1e-3
    for name, K in stiffness.items():
        LamK = 1.0 / (Jy @ np.linalg.solve(K, Jy))
        for k_env, env in ((None, "rigid floor"), (2.0e4, "k_env=2e4 N/m")):
            pred_gain = LamK if k_env is None else 1.0 / (1.0 / LamK + 1.0 / k_env)
            rel = []
            for d in deltas:
                _, lam = equilibrium(q_cmd, K, Y_MODEL + d, k_env, pred_gain * d)
                rel.append(abs(lam - pred_gain * d) / (pred_gain * d))
            rel = np.array(rel)
            # first-order formula: relative error must vanish linearly with delta
            ok = rel[0] < 1e-3 and rel[-1] < 5e-2 and np.all(np.diff(rel) > -1e-12)
            rep.check(f"Prop 2b [{name}; {env}]", ok,
                      f"gain {pred_gain:7.1f} N/m -> {pred_gain * 1e-3:5.2f} N per mm; "
                      f"rel err {rel[0]:.1e} (0.05 mm) .. {rel[-1]:.1e} (2 mm)")

    # Prop 2a: order-2 commanded reaction is offset-independent (identity check) -----
    rng = np.random.default_rng(3)
    lam_des, worst = 3.0, 0.0
    for d in deltas:
        q = ik_pen_down(X0, Y_MODEL + d)  # measured configuration on the REAL floor
        M, Jc = mass_matrix(q), jac(q)[1:2]
        Mi = np.linalg.inv(M)
        Lam = np.linalg.inv(Jc @ Mi @ Jc.T)
        a_T = null_basis(Jc) @ rng.standard_normal(2)  # arbitrary tangential motion command
        a = a_T - Mi @ Jc.T @ (np.array([lam_des]) + Lam @ np.zeros(1))  # static: Jc_dot qdot = 0
        lam = -Lam @ (Jc @ a)
        worst = max(worst, abs(lam[0] - lam_des))
    rep.check("Prop 2a: order-2 commanded reaction = lam_des for every offset", worst < 1e-12,
              f"max |lam - lam_des| {worst:.1e}")
    return rep


if __name__ == "__main__":
    main()
