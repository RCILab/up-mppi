"""T3c + T4b -- execution feasibility at t = 0 and the clipping-distortion bound.

At t = 0 all samples share the state, so the projection Pi onto the admissible polyhedron
A0 = {Aeq u = beq, Ain u <= bin} (metric W) is common.  With vbar = sum w_k v_k:
  T3c  sum w_k Pi(v_k) lies in A0 and is a fixed point of Pi
  T4b  sum w_k Pi(v_k) - Pi(vbar) = sum_{k in D} w_k (Pi(v_k) - Pi_{aff Fbar}(v_k))   (exact)
       ||.||_W <= 2 sum_{k in D} w_k ||v_k - vbar||_W <= 2 sqrt(w(D) Var_w)
  where Fbar is the face of Pi(vbar) and D the samples whose active set differs from it.
"""
import numpy as np

from common import Report, qp_project, rand_spd, wnorm

rng = np.random.default_rng(11)
n, ne, m, K = 6, 2, 5, 64
TRIALS = 300


def problem(rng):
    W = rand_spd(n, rng, 1.0)
    Aeq = rng.standard_normal((ne, n))
    u_f = rng.standard_normal(n)
    Ain = rng.standard_normal((m, n))
    bin_ = Ain @ u_f + rng.uniform(0.0, 0.3, m)
    return W, Aeq, Aeq @ u_f, Ain, bin_, u_f


def pieces(v, W, Aeq, beq, Ain, bin_):
    u, act, _ = qp_project(v, W, Aeq, beq, Ain, bin_)
    return u, frozenset(act)


def main():
    rep = Report("T3c/T4b averaging")
    id_err = ratio_max = feas_err = fix_err = 0.0
    ratios, nonzero = [], 0
    for _ in range(TRIALS):
        W, Aeq, beq, Ain, bin_, u_f = problem(rng)
        v_nom = u_f + 0.8 * rng.standard_normal(n)
        V = v_nom + rng.uniform(0.2, 1.5) * rng.standard_normal((K, n))
        S = np.sum((V - rng.standard_normal(n)) ** 2, axis=1)
        w = np.exp(-(S - S.min()) / rng.uniform(0.5, 5.0))
        w /= w.sum()
        P, acts = zip(*(pieces(v, W, Aeq, beq, Ain, bin_) for v in V))
        P = np.array(P)
        vbar = w @ V
        pbar, abar = pieces(vbar, W, Aeq, beq, Ain, bin_)
        avg = w @ P
        delta = avg - pbar
        # T3c: feasibility and fixed point
        feas_err = max(feas_err, np.linalg.norm(Aeq @ avg - beq), np.max(Ain @ avg - bin_))
        fix_err = max(fix_err, np.linalg.norm(pieces(avg, W, Aeq, beq, Ain, bin_)[0] - avg))
        # T4b: exact identity
        A_face = np.vstack([Aeq, Ain[sorted(abar)]]) if abar else Aeq
        b_face = np.concatenate([beq, bin_[sorted(abar)]]) if abar else beq
        D = [k for k in range(K) if acts[k] != abar]
        ident = np.zeros(n)
        for k in D:
            ident += w[k] * (P[k] - qp_project(V[k], W, A_face, b_face)[0])
        id_err = max(id_err, np.linalg.norm(delta - ident) / (1.0 + np.linalg.norm(delta)))
        # bound
        B1 = 2 * sum(w[k] * wnorm(V[k] - vbar, W) for k in D)
        var_w = sum(w[k] * wnorm(V[k] - vbar, W) ** 2 for k in range(K))
        B2 = 2 * np.sqrt(sum(w[k] for k in D) * var_w)
        dn = wnorm(delta, W)
        if dn > 1e-10:
            nonzero += 1
            ratios.append(dn / B1)
        ratio_max = max(ratio_max, dn / B1 if B1 > 0 else 0.0)
        assert B1 <= B2 + 1e-12
    rep.check("T3c: weighted projected command is admissible", feas_err < 1e-9, f"max violation {feas_err:.1e}")
    rep.check("T3c: execution projection at t=0 is the identity", fix_err < 1e-9, f"max |Pi(avg)-avg| {fix_err:.1e}")
    rep.check("T4b: exact distortion identity", id_err < 1e-9, f"max rel err {id_err:.1e}")
    rep.check("T4b: ||Delta||_W <= 2 sum_D w ||v - vbar||_W", ratio_max <= 1.0 + 1e-12,
              f"max ratio {ratio_max:.3f}, median {np.median(ratios):.3f} over {nonzero}/{TRIALS} distorted trials")

    # zero distortion when every sample shares the mean's face, even if all are clipped --------
    worst, clipped = 0.0, 0
    for _ in range(TRIALS // 3):
        W, Aeq, beq, Ain, bin_, u_f = problem(rng)
        i = rng.integers(m)
        v0 = u_f + 5.0 * np.linalg.solve(W, Ain[i])  # far beyond face i
        V = v0 + 1e-3 * rng.standard_normal((K, n))
        w = rng.dirichlet(np.ones(K))
        P, acts = zip(*(pieces(v, W, Aeq, beq, Ain, bin_) for v in V))
        pbar, abar = pieces(w @ V, W, Aeq, beq, Ain, bin_)
        if all(a == abar for a in acts) and len(abar) > 0:
            clipped += 1
            worst = max(worst, np.linalg.norm(w @ np.array(P) - pbar))
    rep.check("T4b: all samples clipped by the same face -> no distortion", clipped > 0 and worst < 1e-10,
              f"max |Delta| {worst:.1e} over {clipped} fully-clipped trials")

    # distortion vanishes as the temperature goes to zero -------------------------------------
    W, Aeq, beq, Ain, bin_, u_f = problem(rng)
    V = u_f + 0.8 * rng.standard_normal(n) + 1.0 * rng.standard_normal((K, n))
    S = np.sum((V - rng.standard_normal(n)) ** 2, axis=1)
    P = np.array([pieces(v, W, Aeq, beq, Ain, bin_)[0] for v in V])
    ds = []
    lams = [10.0, 3.0, 1.0, 0.3, 0.1, 0.03, 0.01]
    for lam_t in lams:
        w = np.exp(-(S - S.min()) / lam_t)
        w /= w.sum()
        ds.append(wnorm(w @ P - pieces(w @ V, W, Aeq, beq, Ain, bin_)[0], W))
    rep.check("T4b: distortion -> 0 as lambda -> 0", ds[-1] < 1e-6 * max(ds[0], 1e-12) or ds[-1] < 1e-9,
              f"|Delta| {np.array2string(np.array(ds), precision=2)}")
    return rep


if __name__ == "__main__":
    main()
