"""Shared utilities for the Tier-2 verification scripts."""
import numpy as np
from scipy.optimize import nnls


def rand_spd(n, rng, spread=1.0):
    """Random SPD matrix with eigenvalues log-uniform in [10^-spread, 10^spread]."""
    Q, _ = np.linalg.qr(rng.standard_normal((n, n)))
    ev = 10.0 ** rng.uniform(-spread, spread, n)
    return Q @ np.diag(ev) @ Q.T


def wpinv(J, W):
    """W-weighted right pseudoinverse  W^-1 J^T (J W^-1 J^T)^-1."""
    WiJt = np.linalg.solve(W, J.T)
    return WiJt @ np.linalg.inv(J @ WiJt)


def wproj(J, W):
    """W-orthogonal projector onto null(J) (P_I = N of PR-MPPI, P_M = F of CAMP-MPPI)."""
    return np.eye(J.shape[1]) - wpinv(J, W) @ J


def null_basis(J):
    """Orthonormal basis of null(J)."""
    _, s, Vt = np.linalg.svd(J)
    rank = int(np.sum(s > 1e-12 * max(s.max(), 1.0)))
    return Vt[rank:].T


def wnorm(x, W):
    return float(np.sqrt(x @ W @ x))


def qp_project(x, W, Aeq=None, beq=None, Ain=None, bin_=None, tol=1e-8):
    """Exact solution of  min 1/2 (u-x)^T W (u-x)  s.t.  Aeq u = beq,  Ain u <= bin_.

    Equalities are eliminated by a W-orthogonal split; the rest is a least-distance
    program solved exactly with Lawson-Hanson NNLS (active-set, finite termination).
    Returns (u, active_set, inequality_multipliers).
    """
    n = x.size
    Aeq = np.zeros((0, n)) if Aeq is None else np.atleast_2d(Aeq)
    beq = np.zeros(0) if beq is None else np.atleast_1d(beq)
    Ain = np.zeros((0, n)) if Ain is None else np.atleast_2d(Ain)
    bin_ = np.zeros(0) if bin_ is None else np.atleast_1d(bin_)
    if Aeq.shape[0]:
        u0 = x - wpinv(Aeq, W) @ (Aeq @ x - beq)  # W-projection of x onto the affine set
        Z = null_basis(Aeq)
    else:
        u0, Z = x.copy(), np.eye(n)
    if Ain.shape[0] == 0 or np.all(Ain @ u0 <= bin_ + tol):
        return u0, tuple(), np.zeros(Ain.shape[0])
    L = np.linalg.cholesky(Z.T @ W @ Z)
    LinvT = np.linalg.inv(L).T
    G = -Ain @ Z @ LinvT  # constraints  G z >= h  in whitened coordinates z = L^T y
    h = Ain @ u0 - bin_
    E = np.vstack([G.T, h[None, :]])
    fvec = np.zeros(E.shape[0])
    fvec[-1] = 1.0
    mu, _ = nnls(E, fvec, maxiter=50 * E.shape[1])
    res = E @ mu - fvec
    if abs(res[-1]) < 1e-14:
        raise RuntimeError("QP infeasible")
    z = -res[:-1] / res[-1]
    u = u0 + Z @ (LinvT @ z)
    lam_in = mu / (1.0 - h @ mu)
    scale = 1.0 + np.abs(bin_)
    active = tuple(int(i) for i in np.where(np.abs(Ain @ u - bin_) <= tol * scale)[0])
    return u, active, lam_in


def loglog_slope(x, y):
    """Least-squares slope of log(y) against log(x)."""
    return float(np.polyfit(np.log(x), np.log(y), 1)[0])


class Report:
    """Collects PASS/FAIL lines so run_all.py can print one summary."""

    def __init__(self, name):
        self.name, self.rows = name, []

    def check(self, label, ok, detail=""):
        self.rows.append((label, bool(ok), detail))
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}  {detail}")
        return ok

    def info(self, label, detail):
        print(f"  [info] {label}  {detail}")

    @property
    def all_pass(self):
        return all(ok for _, ok, _ in self.rows)
