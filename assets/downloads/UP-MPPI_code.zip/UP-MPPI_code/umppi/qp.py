"""Batched exact metric projections onto polyhedra.

    min 1/2 (u - x_b)^T W_b (u - x_b)   s.t.  E_b u = e_b,  A_b u <= d_b      (b = 1..B)

The equality-only projection u0 is computed first.  The m_cand rows with the largest
residual at u0 form a candidate set (PR-MPPI's active-set growth, with the candidate set
fixed in size so the batch stays vectorised); every subset of it is tried as an active set,
and a subset is accepted when its multipliers are nonnegative and every row of the full
problem is satisfied.  Samples whose active set is not among the candidates are solved
by an exact least-distance program (Lawson-Hanson NNLS), so the result is always exact.
"""
import itertools

import numpy as np
from scipy.optimize import nnls


def _bsolve(S, r):
    """Batched solve with a pseudo-inverse fallback for singular active sets."""
    try:
        return np.linalg.solve(S, r[..., None])[..., 0]
    except np.linalg.LinAlgError:
        return np.einsum("bij,bj->bi", np.linalg.pinv(S), r)


def _ldp_single(x, W, E, e, A, d, tol):
    n = x.size
    if E is not None and E.shape[0]:
        WiEt = np.linalg.solve(W, E.T)
        u0 = x - WiEt @ np.linalg.solve(E @ WiEt, E @ x - e)
        _, s, Vt = np.linalg.svd(E)
        Z = Vt[int(np.sum(s > 1e-12 * s.max())):].T
    else:
        u0, Z = x.copy(), np.eye(n)
    if np.all(A @ u0 <= d + tol):
        return u0
    L = np.linalg.cholesky(Z.T @ W @ Z)
    LinvT = np.linalg.inv(L).T
    G = -A @ Z @ LinvT
    h = A @ u0 - d
    # row normalisation: the LDP is invariant to positive row scaling, NNLS is not
    gn = np.linalg.norm(G, axis=1)
    keep = gn > 1e-14
    if np.any(~keep & (h > tol)):
        raise RuntimeError("infeasible projection")
    G, h = G[keep] / gn[keep, None], h[keep] / gn[keep]
    hs = max(1.0, np.max(np.abs(h)))
    Emat = np.vstack([G.T, (h / hs)[None, :]])  # scale h so the NNLS system is O(1)
    f = np.zeros(Emat.shape[0])
    f[-1] = 1.0
    mu, _ = nnls(Emat, f, maxiter=100 * Emat.shape[1])
    res = Emat @ mu - f
    if abs(res[-1]) < 1e-12:
        raise RuntimeError("infeasible projection")
    z = -res[:-1] / res[-1] * hs
    if np.any(G @ z < h - 1e-7 * (1.0 + np.abs(h))):
        raise RuntimeError("infeasible projection")
    return u0 + Z @ (LinvT @ z)


def _relaxed_single(x, W, E, e, A, d, soft, eq_soft, rho_in, rho_eq, tol):
    """Priority fallback (Prop. 8): hard rows kept, soft inequality rows and soft equality rows
    relaxed by slacks with weights rho_in, rho_eq.  Variables (u, s_in, s_eq)."""
    n, m = x.size, A.shape[0]
    ne = 0 if E is None else E.shape[0]
    eq_soft = np.zeros(ne, dtype=bool) if eq_soft is None else np.asarray(eq_soft, dtype=bool)
    ns, nse = int(soft.sum()), int(eq_soft.sum())
    N = n + ns + nse
    Wa = np.zeros((N, N))
    Wa[:n, :n] = W
    Wa[n:n + ns, n:n + ns] = rho_in * np.eye(ns)
    Wa[n + ns:, n + ns:] = rho_eq * np.eye(nse)
    xa = np.concatenate([x, np.zeros(ns + nse)])
    Aa = np.zeros((m, N))
    Aa[:, :n] = A
    Aa[np.where(soft)[0], n + np.arange(ns)] = -1.0  # A_soft u - s <= d
    Ea = ea = None
    if ne:
        Ea = np.zeros((ne, N))
        Ea[:, :n] = E
        Ea[np.where(eq_soft)[0], n + ns + np.arange(nse)] = -1.0  # E_soft u - s_eq = e
        ea = e
    return _ldp_single(xa, Wa, Ea, ea, Aa, d, tol)[:n]


def project(x, W, E=None, e=None, A=None, d=None, m_cand=4, tol=1e-9, return_info=False,
            soft=None, eq_soft=None, rho_in=1e6, rho_eq=1e3):
    """Exact batched projection.  Shapes: x (B,n); W (B,n,n) or (n,n); E (B,ne,n); A (B,m,n).
    soft / eq_soft: bool masks of the inequality / equality rows that the infeasibility
    fallback may relax (Prop. 8); all other rows stay hard."""
    B, n = x.shape
    W = np.broadcast_to(W, (B, n, n))
    Wi = np.linalg.inv(W)
    ne = 0 if E is None else E.shape[1]
    if ne:
        WiEt = Wi @ np.swapaxes(E, 1, 2)
        nu = _bsolve(E @ WiEt, np.einsum("bij,bj->bi", E, x) - e)
        u0 = x - np.einsum("bij,bj->bi", WiEt, nu)
    else:
        u0 = x.copy()
    info = {"fallback": 0, "relaxed": 0, "active": np.zeros(B, dtype=int)}
    if A is None or A.shape[1] == 0:
        return (u0, info) if return_info else u0
    m = A.shape[1]
    r0 = np.einsum("bij,bj->bi", A, u0) - d
    todo = np.where(np.any(r0 > tol, axis=1))[0]
    u = u0.copy()
    if todo.size == 0:
        return (u, info) if return_info else u
    mc = min(m_cand, m)
    cand = np.argsort(-r0[todo], axis=1)[:, :mc]  # most violated / least slack rows
    Bt = todo.size
    xs, Wis, As, ds = x[todo], Wi[todo], A[todo], d[todo]
    Es = E[todo] if ne else None
    es = e[todo] if ne else None
    done = np.zeros(Bt, dtype=bool)
    usol = np.empty((Bt, n))
    nact = np.zeros(Bt, dtype=int)
    rows_idx = np.arange(Bt)[:, None]
    for size in range(1, mc + 1):
        for S in itertools.combinations(range(mc), size):
            rem = np.where(~done)[0]
            if rem.size == 0:
                break
            sel = cand[rem][:, list(S)]  # (R, size)
            G = As[rem[:, None], sel]  # (R, size, n)
            g = ds[rem[:, None], sel]
            if ne:
                Bm = np.concatenate([Es[rem], G], axis=1)
                rhs = np.concatenate([es[rem], g], axis=1)
            else:
                Bm, rhs = G, g
            WiBt = Wis[rem] @ np.swapaxes(Bm, 1, 2)
            nu = _bsolve(Bm @ WiBt, np.einsum("bij,bj->bi", Bm, xs[rem]) - rhs)
            ut = xs[rem] - np.einsum("bij,bj->bi", WiBt, nu)
            mu = nu[:, ne:]
            feas = np.all(np.einsum("bij,bj->bi", As[rem], ut) - ds[rem] <= tol * (1 + np.abs(ds[rem])), axis=1)
            ok = feas & np.all(mu >= -1e-10 * (1 + np.abs(mu).max(axis=1, keepdims=True)), axis=1) & np.all(np.isfinite(ut), axis=1)
            idx = rem[ok]
            usol[idx] = ut[ok]
            nact[idx] = size
            done[idx] = True
        if done.all():
            break
    for j in np.where(~done)[0]:
        Wj = np.linalg.inv(Wis[j])
        Ej, ej = (Es[j], es[j]) if ne else (None, None)
        try:
            usol[j] = _ldp_single(xs[j], Wj, Ej, ej, As[j], ds[j], tol)
        except RuntimeError:
            if soft is None:
                raise
            sm = np.asarray(soft, dtype=bool)
            for scale in (1.0, 1e-2, 1e-4):  # the slack weight is only a priority; retry if ill-scaled
                try:
                    usol[j] = _relaxed_single(xs[j], Wj, Ej, ej, As[j], ds[j], sm, eq_soft,
                                              rho_in * scale, rho_eq * scale, tol)
                    break
                except RuntimeError:
                    continue
            else:  # last resort: hard rows only (always feasible when they are)
                Eh = None if Ej is None else Ej[~np.asarray(eq_soft, dtype=bool)] if eq_soft is not None else Ej
                eh = None if Ej is None else ej[~np.asarray(eq_soft, dtype=bool)] if eq_soft is not None else ej
                usol[j] = _ldp_single(xs[j], Wj, Eh, eh, As[j][~sm], ds[j][~sm], tol)
            info["relaxed"] += 1
        info["fallback"] += 1
    u[todo] = usol
    info["active"][todo] = nact
    del rows_idx
    return (u, info) if return_info else u
