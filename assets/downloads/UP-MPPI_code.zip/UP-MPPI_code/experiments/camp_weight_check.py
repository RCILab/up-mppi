"""Sensitivity of the CAMP-MPPI (orientation as cost) baseline to the orientation weight w_o."""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiments.writing_exp as X  # noqa: E402
from umppi.controllers import CAMPMPPI  # noqa: E402


def job(w_o):
    X.CONTROLLERS["tmp"] = lambda ch, dl: CAMPMPPI(ch, metric="M", solver="joint", virtual="soft", delta=dl,
                                                    w_o=w_o, **X.O2)
    r, _ = X.run("tmp", 0.0)
    keep = ("track_rmse_mm", "force_mean", "in_band", "ori_rms_deg", "diverged_t", "joint_margin")
    return {"w_o": w_o, **{k: r[k] for k in keep}}


if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    with Pool(3) as p:
        res = list(p.imap_unordered(job, [5e3, 5e4, 5e5]))
    out = Path(__file__).resolve().parent / "results/camp_weight_check.json"
    out.write_text(json.dumps(res, indent=1))
    for r in sorted(res, key=lambda r: r["w_o"]):
        print(json.dumps(r))
