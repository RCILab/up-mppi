"""Ground-truth physics: MuJoCo rigid-body dynamics + explicit board contact.

Contact with the REAL board (sphere C_S, R_S): spring k_env, damper d_env, regularised
Coulomb friction mu.  Joints carry viscous friction (1 N m s/rad), which no controller models.  Low-level loops run at the physics rate (1 kHz):
  order 1  computed-torque tracking of the reference q0 -> q+ over the control period
  order 2  tau = M(q) a + b(q, qd) with the commanded acceleration a held (ZOH)
"""
import mujoco
import numpy as np

from .mjcf import scene_xml
from .writing import C_S, R_S


class Physics:
    def __init__(self, chain, k_env=2.0e4, d_env=60.0, mu=0.2, v_eps=1e-3, dt=0.001, omega_ll=2 * np.pi * 10,
                 joint_damping=1.0):
        self.m = mujoco.MjModel.from_xml_string(scene_xml([(chain, "")], timestep=dt))
        self.m.dof_damping[:] = joint_damping  # viscous joint friction of the real arm (N m s/rad)
        self.d = mujoco.MjData(self.m)
        self.sid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SITE, "tool")
        self.k_env, self.d_env, self.mu, self.v_eps, self.dt = k_env, d_env, mu, v_eps, dt
        self.kp, self.kd = omega_ll ** 2, 2 * omega_ll
        self.Jp = np.zeros((3, 7))
        self.Jr = np.zeros((3, 7))
        self.M = np.zeros((7, 7))

    def reset(self, q, qd=None):
        self.d.qpos[:] = q
        self.d.qvel[:] = 0.0 if qd is None else qd
        mujoco.mj_forward(self.m, self.d)

    @property
    def q(self):
        return self.d.qpos.copy()

    @property
    def qd(self):
        return self.d.qvel.copy()

    def _contact(self):
        p = self.d.site_xpos[self.sid].copy()
        mujoco.mj_jacSite(self.m, self.d, self.Jp, self.Jr, self.sid)
        v = self.Jp @ self.d.qvel
        r = p - C_S
        rho = np.linalg.norm(r)
        n = r / rho
        gap = rho - R_S
        fn = 0.0
        F = np.zeros(3)
        if gap < 0:
            fn = max(self.k_env * (-gap) - self.d_env * (n @ v), 0.0)
            vt = v - n * (n @ v)
            ft = -self.mu * fn * vt / np.sqrt(vt @ vt + self.v_eps ** 2)
            F = fn * n + ft
        return self.Jp.T @ F, fn, gap, p

    def step_order1(self, q0, q_plus, T):
        """Track q0 -> q+ linearly over T seconds with computed torque; returns logs."""
        n = int(round(T / self.dt))
        qd_ref = (q_plus - q0) / T
        logs = []
        for i in range(n):
            s = (i + 1) * self.dt
            q_ref = q0 + qd_ref * s
            qfc, fn, gap, p = self._contact()
            mujoco.mj_fullM(self.m, self.d, self.M)
            tau = self.M @ (self.kp * (q_ref - self.d.qpos) + self.kd * (qd_ref - self.d.qvel)) + self.d.qfrc_bias
            self.d.qfrc_applied[:] = tau + qfc
            mujoco.mj_step(self.m, self.d)
            logs.append((fn, gap, p))
        return logs

    def step_order2(self, a, T):
        """tau = M(q) a + b(q, qd), a held over T seconds."""
        n = int(round(T / self.dt))
        logs = []
        for _ in range(n):
            qfc, fn, gap, p = self._contact()
            mujoco.mj_fullM(self.m, self.d, self.M)
            tau = self.M @ a + self.d.qfrc_bias
            self.d.qfrc_applied[:] = tau + qfc
            mujoco.mj_step(self.m, self.d)
            logs.append((fn, gap, p))
        return logs
