"""Fill tier2/timing_section.tex from results/gpu_timing.json."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
D = json.loads((HERE / "results/gpu_timing.json").read_text())
wg, sg, jg = D["waiter_gpu"], D["writing_gpu"]["separable"], D["writing_gpu"]["joint"]
Ks = sorted(wg, key=int)


def cell(x):
    return f"{x['plan_ms']:.2f} ({x['kernel_ms']:.2f})"


rows = [
    f"Waiter, unified (robust rows) & {D['waiter_numpy_K256_ms']:.0f} & " + " & ".join(cell(wg[k]) for k in Ks) + " \\\\",
    f"Writing, unified (separable) & {D['writing_numpy_K256_ms']['separable']:.0f} & " + " & ".join(cell(sg[k]) for k in Ks) + " \\\\",
    f"Writing, joint projection & {D['writing_numpy_K256_ms']['joint']:.0f} & " + " & ".join(cell(jg[k]) for k in Ks) + " \\\\",
]
k1 = "1024"
gain = [100 * (1 - sg[k]["kernel_ms"] / jg[k]["kernel_ms"]) for k in Ks]
np_gain = 100 * (1 - D["writing_numpy_K256_ms"]["separable"] / D["writing_numpy_K256_ms"]["joint"])
speed_w = D["writing_numpy_K256_ms"]["separable"] / sg["256"]["plan_ms"]
speed_wt = D["waiter_numpy_K256_ms"] / wg["256"]["plan_ms"]

tex = r"""\section{Real-time implementation}
\label{sec:timing}

Every sample is projected at every rollout step, so the cost of the controller is the cost of $KH$ small quadratic programs and model evaluations per control cycle.
The numpy reference evaluates them batched over the samples but step by step in Python, and needs about 0.2--0.3\,s per plan.
Porting the same operations to GPU tensor operations does not help much: with CUDA graphs the rollout still launches hundreds of small kernels per step, and it was only about seven times faster.

The implementation used here assigns one GPU thread to each sample and runs its whole rollout in one kernel (NVIDIA Warp, float32).
Per step, the thread evaluates the model (forward kinematics and the mass matrix in one pass over the links, the tool Jacobian and $\dot J\dot q$), builds the rows, solves the inertia-metric projection exactly by a dual active-set method, integrates, and accumulates the cost.
The weights and the raw average are computed on the GPU afterwards, and the final projection of Algorithm~\ref{alg:unified} is a second launch of the same kernel with one thread, one step and zero noise, so the executed command never leaves the device code.
With the same noise, the projected inputs of every sample agree with the numpy reference to $4\times10^{-5}$ or better, the costs to $10^{-5}$, and the executed command to $5\times10^{-5}$.
With the raw average, noise clipped at $\pm3\sigma$ and tightened rows, the executed commands of two consecutive cycles agree to $5\times10^{-5}$ as well, and the GPU command satisfies the tightened support rows to $2\times10^{-7}$.
These checks are \texttt{umppi/tests/test\_warp.py} and \texttt{test\_warp\_writing.py}; the waiter experiments of Sections~\ref{sec:robust} and~\ref{sec:baselines} run on this controller.

\begin{table}[h]
\centering
\caption{Plan time per control cycle in milliseconds, with the kernel time in parentheses: numpy reference at $K=256$, and the GPU controllers on an RTX~4060 for three sample counts. Waiter: $H=20$, control period 20\,ms. Writing: $H=15$, control period 10\,ms.}
\label{tab:timing}
\footnotesize
\begin{tabularx}{\linewidth}{l Y Y Y Y}
\toprule
Controller & numpy, $K=256$ & GPU, $K=256$ & GPU, $K=1024$ & GPU, $K=4096$ \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabularx}
\end{table}

\paragraph{Findings.}
\begin{enumerate}
""" + (
    f"\\item Both controllers run well inside their control periods: {sg[k1]['plan_ms']:.1f}\\,ms of 10\\,ms for writing and {wg[k1]['plan_ms']:.1f}\\,ms of 20\\,ms for the waiter at $K=1024$, "
    f"{speed_w:.0f} and {speed_wt:.0f} times faster than the numpy reference at $K=256$.\n"
    f"The plan time is nearly flat up to $K=1024$, where one thread's sequential rollout sets it, and grows beyond, where the device is saturated.\n"
    f"The workstation was shared with other CPU-bound jobs during the measurement, which inflates the host-side part of the plan time (the weights, the average, the reaction map of the measured state and the launches), not the kernel time.\n"
    f"\\item On the GPU the separable solver of Theorem~\\ref{{thm:sep}} takes {min(gain):.0f}--{max(gain):.0f}\\% less kernel time than the joint projection, against {np_gain:.0f}\\% in numpy, where the model evaluation dominates.\n"
    "The reaction becomes a closed-form clamp instead of two rows of the program, and the tangential program has only box rows besides the equalities.\n"
    "\\item The waiter kernel is slower than the writing kernel because it carries 34 rows, 17 of them support rows, and a longer horizon; it could be pruned further, but it already meets the 20\\,ms period with margin.\n"
) + r"""\end{enumerate}
"""
(HERE.parent / "tier2" / "timing_section.tex").write_text(tex, encoding="utf-8")
print("written; separable kernel gain", [round(g, 1) for g in gain], "numpy gain", round(np_gain, 1))
