# Planned hardware validation of the robust/adaptive wrench rows (waiter task)

The current manuscript reports simulation and numerical results only. This is a future experiment
protocol, not a record of completed hardware trials. The former red hardware paragraph has been
removed from the manuscript and its generation template. No example hardware outcome is a target
value to copy into the paper. See [HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md) for the handoff across
writing, dual-arm transport, waiter transport, and computation timing.

## Questions to evaluate

- **C1, certificate on hardware.** Do the robust and adaptive controllers keep the period-averaged support wrench admissible when the calibrated bounds hold? Record tips, COP ratios, and execution residuals, including violations.
- **C2, adaptation with the F/T sensor alone.** Do COP differences shrink the interval of h while retaining the true value, and how much of the robust-to-oracle tracking gap is recovered?
- **C3, model mismatch.** How does a controller that trusts a wrong model (nominal, h = 0.07 m) behave on the same object? Report the observed tipping count, including zero if no tipping occurs.

## Equipment

| Item | Requirement | Why |
|---|---|---|
| Arm | Franka FR3 (or Panda), torque control through libfranka at 1 kHz | Order-2 execution τ = M a + b + D q̇ − τ_load |
| Controller | Unified order-2 MPPI at 50 Hz, H = 20, K = 256, integrated with the lab's torque-control stack | A GPU implementation exists; benchmark the complete sensing/planning/execution path on the robot computer before choosing the control period |
| F/T sensor | Wrist sensor between flange and tray, e.g. ATI Axia80 or Mini45, 1 kHz | The COP needs about 1 mN·m torque resolution; the FR3's own external-wrench estimate is too noisy |
| Tray | Rigid, flat, about 26 × 18 cm, high-friction mat (μ ≥ 0.5) | Slip rows stay inactive, as in simulation |
| Object | Rigid box or tube with a 4 × 4 cm base and 24 cm height; an internal sliding mass sets h ∈ {0.08, 0.11, 0.14, 0.17} m; total mass about 0.6 kg | Same geometry as simulation |
| Safety | Soft catch (foam wall or tether) around the tray | The nominal controller tips the object by design |
| Tip detection | Small IMU on the object (or a camera); a tip is recorded when the tilt exceeds 20° | Same criterion as simulation |
| Optional | Camera tracking the object's position on the tray to 0.2 mm | Only for the "box tracked" variant |

## Calibration (before any trial)

1. **h of each mass setting.** Tilt test: tilt the object on its base edge until it balances. Then h = r / tan(θ_balance) with r = 2 cm. Repeat 3 times and report the mean ± spread. This gives the oracle's h and the ground truth for the containment check.
2. **Tray wrench compensation.** Identify the tray's mass and COM from 20 static poses without the object. During trials, subtract the tray's gravity and inertial wrench from the sensor reading to get the contact wrench on the object.
3. **Execution-error bound (first: the other calibrations use the tightened controller).** Algorithm 1 executes the projection of the raw average, which rides the boundary of the rows, so its rows carry the tightening ε_exec. Run the oracle with ε_exec = 0 (its most aggressive motion) at the lightest and heaviest mass settings, not the evaluation trials. From the tray-point acceleration (joint encoders through the model, or an IMU on the tray), compute the period average of s_real − s_cmd over every 20 ms control period, and set ε_exec to 1.5 × the largest norm. The simulation got 0.110 m/s² at the lowest COM, so ε_exec = 0.165 m/s² (`experiments/waiter_baselines.py --calib-exec`, stored in `results/waiter_exec_bound.json`). Joint friction and torque-tracking error on hardware will likely raise it, and every row loses ‖L_i‖·ε_exec, so check that the tightened rows still admit the move before the evaluation trials (with ε_exec = 0.165 m/s² the robust rows admit 0.84 m/s²).
4. **Sensor and model error bounds.** Run the oracle controller (calibrated h, rows tightened by ε_exec) at the lightest and heaviest mass settings, not the evaluation trials, with 100 ms windows. From the residuals of the measurement models under the calibrated parameters, set ε_F and ε_τ to 1.5 × the largest absolute residual. The simulation used exactly this procedure (`experiments/waiter_calibrate.py`) and got 0.033 N and 3.5 mN·m. The torque error is dominated by the object rocking on the compliant contact, and it falls as 1/T_w (see the note for the 40 ms against 100 ms comparison). A rubber mat increases it, so calibrate on the mat that will be used.
5. **Creep bound.** Run 10 moves with the object free and track its position on the tray (camera, or the COP drift across the holds). Set the creep rate ḋ_max to 1.5 × the largest rate over 100 ms windows, and d0 to 1.5 × the largest jump. The simulation values were 1.7 mm/s and 0.1 mm.

## Protocol

- Reference: A → B → A, 0.4 m lateral, quintic, 0.8 s per move, 1.2 s hold (peak 3.6 m/s²). This is the same as simulation.
- Conditions: the main height is h = 0.14 m, with 10 trials each for nominal, robust, adaptive-COP and oracle (plus adaptive-tracked if a camera is used). The sweep uses h ∈ {0.11, 0.17} m, with 5 trials each for robust, adaptive-COP and oracle; the nominal is run at 0.11 m only.
- Randomise the order of controllers within a height. Re-seat the object at the same mark before every trial.
- Log at 1 kHz: joint state, commanded acceleration, F/T wrench, estimator interval, object IMU. Log at 50 Hz: model wrench of the executed command (octagon ratio under the calibrated h).

## Measurements to report

| Question | Metric | Interpretation |
|---|---|---|
| C1 | Tips of robust/adaptive controllers, all heights | Report the count and denominator; zero tips alone does not establish a wrench certificate |
| C1 | Largest period-averaged COP ratio (square norm, relative to the object's base) | < 1 (supports Prop. tighten (b)) |
| C1 | Largest period-averaged model-vs-realized tray acceleration deviation, over ε_exec | < 1 (the hypothesis of Prop. tighten (b); simulation 0.70) |
| C1 | The same two quantities at the full sensor rate (1 kHz), reported separately | report; < 1 is needed for the pointwise Prop. tighten (a), which the simulation did not meet (up to 1.7 ε_exec at 1 ms) |
| C2 | Calibrated h inside the final interval, every adaptive trial | yes |
| C2 | Rejected updates (empty set) | Count and inspect every rejection; it indicates inconsistency with the assumed model/bounds. Keep evaluation bounds fixed; any recalibration defines a new evaluation batch |
| C2 | Move-2 RMSE and robust-to-oracle gap closed by adaptive-COP at h = 0.14 m | Report the measured value, dispersion, and denominator; do not require a prescribed improvement |
| C3 | Nominal tips at h = 0.14 m | Report the observed count over all planned trials, not a predetermined failure rate |

## Material for the future hardware section

| # | Topic | Fill from recorded evidence |
|---|---|---|
| H1 | Setup | Equipment actually used, controller configuration, calibration protocol, and trial counts actually run |
| H2 | Nominal outcomes | C3 count at h = 0.14 m, including interrupted trials and their causes |
| H3 | Robust/adaptive/oracle outcomes | Counts for each controller and height, with the actual denominators |
| H4 | Wrench and execution residuals | Largest period-averaged COP ratio and normalized execution residual; full-rate values separately |
| H5 | Adaptation and tracking | Final interval, containment throughout each trial, move-1/move-2 RMSE, and gap closure |
