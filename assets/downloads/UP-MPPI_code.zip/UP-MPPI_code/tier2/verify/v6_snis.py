"""Lemma 2 -- self-normalised estimator of the projected update.

Gaussian proposal P = N(0, I_d), cost S(v) = |v - c|^2 / 2, temperature lam, so the tilted
measure Q* is Gaussian and everything is available in closed form:
  Q* = N(c / (1 + lam), lam / (1 + lam) I),
  rho = E_P[g^2] / E_P[g]^2  with g = exp(-S / lam).
The projection is the clip onto the box [-1, 1]^d (a bounded admissible set), so every
coordinate of Pi(V) is a test function bounded by 1.  Agapiou et al. (2017, Thm 2.1) give
  MSE <= 4 rho / K;  the note's self-contained proof gives  |bias| <= (4 rho - 2) / K.
Checks: bound holds for every K and coordinate, MSE ~ 1/K, consistency; the raw average
(unbounded test function) is reported for comparison.
"""
import numpy as np
from scipy.stats import norm

from common import Report, loglog_slope

rng = np.random.default_rng(5)
d, lam = 4, 1.0
c = np.array([1.5, -0.5, 2.0, 0.0])
KS = np.array([32, 128, 512, 2048])
REPS = 2000


def exact():
    mu = c / (1 + lam)
    s = np.sqrt(lam / (1 + lam))
    a, b = (-1 - mu) / s, (1 - mu) / s
    clip_mean = -norm.cdf(a) + (1 - norm.cdf(b)) + mu * (norm.cdf(b) - norm.cdf(a)) - s * (norm.pdf(b) - norm.pdf(a))

    def gauss_int(tau):  # E_P[exp(-|v - c|^2 / (2 tau))]
        return (tau / (1 + tau)) ** (d / 2) * np.exp(-c @ c / (2 * (1 + tau)))
    rho = gauss_int(lam / 2) / gauss_int(lam) ** 2
    return mu, clip_mean, rho


def main():
    rep = Report("Lemma 2 SNIS")
    mu, clip_mean, rho = exact()
    rep.info("closed form", f"rho = {rho:.2f}  (ESS ~ K/rho)")
    mse_p, bias_p, mse_r = [], [], []
    for K in KS:
        est_p, est_r = np.empty((REPS, d)), np.empty((REPS, d))
        for r in range(REPS):
            V = rng.standard_normal((K, d))
            logw = -0.5 * np.sum((V - c) ** 2, axis=1) / lam
            w = np.exp(logw - logw.max())
            w /= w.sum()
            est_p[r] = w @ np.clip(V, -1.0, 1.0)
            est_r[r] = w @ V
        mse_p.append(np.max(np.mean((est_p - clip_mean) ** 2, axis=0)))
        bias_p.append(np.max(np.abs(est_p.mean(axis=0) - clip_mean)))
        mse_r.append(np.max(np.mean((est_r - mu) ** 2, axis=0)))
    mse_p, bias_p, mse_r = map(np.array, (mse_p, bias_p, mse_r))
    bound = 4 * rho / KS
    rep.check("projected SNIS: MSE <= 4 rho / K (every K, worst coordinate)", np.all(mse_p <= bound),
              f"MSE/bound {np.array2string(mse_p / bound, precision=3)}")
    rep.check("projected SNIS: |bias| <= (4 rho - 2) / K", np.all(bias_p <= (4 * rho - 2) / KS),
              f"bias/bound {np.array2string(bias_p / ((4 * rho - 2) / KS), precision=3)}")
    s = loglog_slope(KS, mse_p)
    rep.check("projected SNIS: MSE ~ 1/K (consistency)", abs(s + 1) < 0.15, f"slope {s:.2f}")
    rep.info("raw SNIS MSE (no bounded-function guarantee)",
             f"{np.array2string(mse_r, precision=4)} vs projected {np.array2string(mse_p, precision=4)}")
    return rep


if __name__ == "__main__":
    main()
