"""T3d -- executed-only vs per-rollout retraction (Proposition 4), orders 1 and 2.

Unit-sphere toy, same noise realisation for both schemes:
  A  rollouts integrate without retraction (as in PR-MPPI / CAMP-MPPI)
  B  every rollout step is followed by a retraction (order 1: q/|q|;
     order 2: phase-space retraction q/|q|, N(q) qd)
Both rollouts pass through the projection (equality + one CBF / HOCBF half-space).
Measured: trajectory gap, cost gap, MPPI update gap (projected averaging).

The noise is a smooth random process sampled at t = i dt, so every dt discretises the
same continuous-time inputs (bounded independently of dt, as Proposition 4 assumes).
Prediction (dt-weighted running cost):
  fixed horizon length H   -> gaps O(dt^2)   (slope 2, the regime of the June toy)
  fixed horizon time  T_h  -> gaps O(dt)     (slope 1)
Counter-check: white-noise-scaled exploration (sigma ~ dt^-1/2) violates the bounded-input
assumption; the executed-only drift then stays O(1) at fixed T_h (Ito-type drift).
"""
import numpy as np

from common import Report, loglog_slope

EZ = np.array([0.0, 0.0, 1.0])
Q0 = np.array([1.0, 0.2, 0.1]) / np.linalg.norm([1.0, 0.2, 0.1])
QD0 = np.cross(EZ, Q0) / np.linalg.norm(np.cross(EZ, Q0))  # unit tangent initial velocity
GOAL = np.array([-0.2, 1.0, 0.6]) / np.linalg.norm([-0.2, 1.0, 0.6])
K, LAMBDA, WT, ZMIN = 256, 0.1, 1.0, -0.2
DTS = np.array([0.1, 0.05, 0.025, 0.0125, 0.00625])
SEEDS = range(5)
NFREQ = 8
OMEGAS = np.linspace(0.5, 6.0, NFREQ)


def rowdot(a, b):
    return np.sum(a * b, axis=1)


def tangent(q, u):
    return u - q * (rowdot(q, u) / rowdot(q, q))[:, None]


def pi_order1(q, u, gamma=5.0):
    """Euclidean projection onto {q^T u = 0, e_z^T u >= -gamma (q_z - z_min)} (nested)."""
    up = tangent(q, u)
    n = EZ[None, :] - q * (q[:, 2] / rowdot(q, q))[:, None]  # N e_z
    res = -gamma * (q[:, 2] - ZMIN) - up[:, 2]
    return up + (np.maximum(res, 0.0) / n[:, 2])[:, None] * n


def pi_order2(q, qd, a, k1=4.0, k2=4.0):
    """M = I projection of the commanded acceleration onto the HOCBF half-space."""
    n = EZ[None, :] - q * (q[:, 2] / rowdot(q, q))[:, None]
    f = -q * (rowdot(qd, qd) / rowdot(q, q))[:, None]
    beta = -f[:, 2] - (k1 + k2) * qd[:, 2] - k1 * k2 * (q[:, 2] - ZMIN)
    res = beta - rowdot(n, a)
    return a + (np.maximum(res, 0.0) / rowdot(n, n))[:, None] * n


def smooth_noise(rng, sigma, dt, H):
    """eps_k(t) = sigma sqrt(2/m) sum_j cos(w_j t + phi_kij): same function of t for every dt."""
    phi = rng.uniform(0, 2 * np.pi, (K, 3, NFREQ))
    t = dt * np.arange(H)
    arg = OMEGAS[None, None, None, :] * t[None, :, None, None] + phi[:, None, :, :]
    return sigma * np.sqrt(2.0 / NFREQ) * np.cos(arg).sum(axis=3)  # (K, H, 3)


def rollout(order, dt, H, U, eps, retract):
    q = np.repeat(Q0[None, :], K, axis=0)
    qd = np.repeat(QD0[None, :], K, axis=0)
    S = np.zeros(K)
    traj, applied = [], []
    for t in range(H):
        v = U[t][None, :] + eps[:, t, :]
        if order == 1:
            u = pi_order1(q, v)
            q = q + dt * u
            if retract:
                q = q / np.linalg.norm(q, axis=1, keepdims=True)
            state = q.copy()
        else:
            u = pi_order2(q, qd, v)
            qdd = tangent(q, u) - q * (rowdot(qd, qd) / rowdot(q, q))[:, None]  # Gauss, M = I
            qd = qd + dt * qdd
            q = q + dt * qd
            if retract:
                q = q / np.linalg.norm(q, axis=1, keepdims=True)
                qd = tangent(q, qd)
            state = np.hstack([q, qd])
            S += 0.01 * rowdot(qd, qd) * dt
        S += rowdot(q - GOAL, q - GOAL) * dt
        traj.append(state)
        applied.append(u)
    S += WT * rowdot(q - GOAL, q - GOAL)
    return np.stack(traj, 1), np.stack(applied, 1), S


def weights(S):
    w = np.exp(-(S - S.min()) / LAMBDA)
    return w / w.sum()


def compare(order, dt, H, seed, white=False):
    rng = np.random.default_rng(seed)
    sigma = 0.6 if order == 1 else 2.0
    U = np.tile(0.5 * (GOAL - Q0), (H, 1))
    if white:
        eps = (sigma * np.sqrt(0.05 / dt)) * rng.standard_normal((K, H, 3))  # sigma_c = sigma at dt = 0.05
    else:
        eps = smooth_noise(rng, sigma, dt, H)
    XA, UA, SA = rollout(order, dt, H, U, eps, retract=False)
    XB, UB, SB = rollout(order, dt, H, U, eps, retract=True)
    wA, wB = weights(SA), weights(SB)
    UstarA = np.einsum("k,kti->ti", wA, UA)
    UstarB = np.einsum("k,kti->ti", wB, UB)
    sq_drift = np.mean(np.sum(XA[:, -1, :3] ** 2, axis=1) - 1.0)  # mean |q_H|^2 - 1 of scheme A
    return (np.max(np.linalg.norm(XA - XB, axis=2)), np.max(np.abs(SA - SB)),
            np.max(np.linalg.norm(UstarA - UstarB, axis=1)), sq_drift)


DTS_H = DTS / 5  # fixed-H grid: keeps T_h = 20 dt <= 0.4 s (asymptotic regime)


def main():
    rep = Report("T3d rollout retraction")
    data = {"dts": DTS, "dts_H": DTS_H}
    for order in (1, 2):
        for regime in ("fixed H", "fixed T_h"):
            grid = DTS_H if regime == "fixed H" else DTS
            gaps = []
            for dt in grid:
                H = 20 if regime == "fixed H" else int(round(1.0 / dt))
                gaps.append(np.mean([compare(order, dt, H, s) for s in SEEDS], axis=0))
            gaps = np.array(gaps)
            if regime == "fixed H":
                # asymptotic (finest-segment) slope; Prop. 4 is an upper bound O(dt^2)
                loc = [float(np.diff(np.log(gaps[-2:, j]))[0] / np.diff(np.log(grid[-2:]))[0]) for j in range(3)]
                ok = all(s >= 1.85 for s in loc)
                rep.check(f"order {order}, {regime:9s}: asymptotic traj/cost/update slopes >= 2", ok,
                          "local slopes " + " / ".join(f"{s:.2f}" for s in loc))
            else:
                slopes = [loglog_slope(grid, gaps[:, j]) for j in range(3)]
                ok = all(abs(s - 1.0) < 0.15 for s in slopes)
                rep.check(f"order {order}, {regime:9s}: traj/cost/update slopes ~ 1", ok,
                          "slopes " + " / ".join(f"{s:.2f}" for s in slopes))
            data[f"o{order}_{'H' if regime == 'fixed H' else 'T'}"] = gaps

    # counter-check: white-noise scaling breaks the bounded-input assumption ----------
    smooth = np.array([np.mean([compare(1, dt, int(round(1.0 / dt)), s)[3] for s in SEEDS]) for dt in DTS])
    white = np.array([np.mean([compare(1, dt, int(round(1.0 / dt)), s, white=True)[3] for s in SEEDS])
                      for dt in DTS])
    ito = 2 * (0.6 ** 2 * 0.05) * 1.0  # 2 sigma_c^2 T_h : two tangent directions
    s_sm = loglog_slope(DTS, smooth)
    rep.check("bounded inputs: executed-only drift E|q_H|^2-1 vanishes like dt", abs(s_sm - 1) < 0.15,
              f"{np.array2string(smooth, precision=4)}  slope {s_sm:.2f}")
    rep.check("white-noise inputs (sigma ~ dt^-1/2): drift -> Ito constant 2 sigma_c^2 T_h, not 0",
              abs(white[-1] / ito - 1) < 0.25, f"{np.array2string(white, precision=4)}  vs {ito:.3f}")
    data.update(smooth_drift=smooth, white_drift=white, ito=ito)
    np.savez("v4_data.npz", **data)
    return rep


if __name__ == "__main__":
    main()
