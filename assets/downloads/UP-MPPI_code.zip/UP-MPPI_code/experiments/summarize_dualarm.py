"""Aggregate the dual-arm sweep (E1 table in the style of PR-MPPI Table II; E2 internal force)."""
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    D = json.loads((HERE / "results/dualarm.json").read_text())
    rows = [r for r in D["rows"] if "error" not in r]
    errs = [r for r in D["rows"] if "error" in r]
    g = defaultdict(list)
    for r in rows:
        g[(r["controller"], r["delta_b_mm"])].append(r)

    def m(nm, dl, key):
        v = [r[key] for r in g[(nm, dl)] if r.get(key) is not None]
        return (float(np.mean(v)), float(np.std(v))) if v else (float("nan"), float("nan"))
    print(f"errors: {len(errs)}", [e["error"][:80] for e in errs][:3])
    print("\nE1 (no calibration error)")
    keys = ["bound_viol", "margin_pen", "meas_chain_trans_mm", "meas_chain_rot_mrad", "meas_tilt_deg",
            "cmd_model_max", "W_int_norm_mean", "ms_per_step", "goal_err"]
    print(f"{'controller':14s} " + " ".join(f"{k[:14]:>15s}" for k in keys))
    E1 = {}
    for nm in ("PR", "PR-noretract", "PR-noineq", "Unified", "Unified-eps0", "Shield", "DualGuard", "GS"):
        if (nm, 0.0) not in g:
            continue
        vals = {k: m(nm, 0.0, k) for k in keys}
        E1[nm] = vals
        print(f"{nm:14s} " + " ".join(f"{vals[k][0]:15.4g}" for k in keys))
    print("\nE2 (internal force [N] vs right-base calibration error)")
    pred = {float(k): v for k, v in D["pred"].items()}
    E2 = {}
    for nm in ("PR", "PR-anchored", "Unified"):
        E2[nm] = {}
        line = f"{nm:12s}"
        for dl in (0.0, 0.5, 1.0, 2.0):
            key = (nm, dl) if (nm, dl) in g else (("PR", 0.0) if nm == "PR-anchored" and dl == 0.0 else (nm, dl))
            fy, fn = m(*key, "W_int_y_mean"), m(*key, "W_int_norm_mean")
            E2[nm][dl] = dict(Fy=fy, Fnorm=fn, cmd_true=m(*key, "cmd_true_trans_mm"), bound=m(*key, "bound_viol"))
            line += f"  d={dl}: |F|={fn[0]:6.2f}+-{fn[1]:.2f} Fy={fy[0]:6.2f}"
        print(line)
    print("prediction Fy [N]:", {d: round(v[1], 2) for d, v in pred.items()})
    out = dict(E1=E1, E2={nm: {str(k): v for k, v in d.items()} for nm, d in E2.items()},
               pred={str(k): v for k, v in pred.items()}, errors=errs)
    (HERE / "results/dualarm_summary.json").write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main(*sys.argv[1:])
