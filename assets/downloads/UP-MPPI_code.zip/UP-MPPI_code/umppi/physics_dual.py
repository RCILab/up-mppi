"""Ground-truth physics of the dual-arm tray task: MuJoCo, two arms + a free tray body.

Each hand holds the tray through an explicit 6-DoF grasp spring (stiffness K_t, K_r; damping
D_t, D_r), so the internal wrench is measurable exactly:  W_int = (W_l - W_r) / 2, the part of
the two grasp wrenches on the tray that does not support it.  Joints carry viscous friction.
Low-level loops per arm, at 1 kHz, with the arm-only model (the tray is not modelled):
  order 1  computed-torque tracking of the reference q0 -> q+ over the control period
  order 2  tau = M a + b with the commanded acceleration held
"""
import mujoco
import numpy as np

from .dualarm import GRIP_Y, kin_pair
from .mjcf import _fmt, scene_xml

TRAY_SIZE = np.array([0.08, GRIP_Y + 0.05, 0.008])  # half extents (x, y, z)


def tray_xml(pos, mass=1.0):
    I = mass / 3.0 * np.array([TRAY_SIZE[1] ** 2 + TRAY_SIZE[2] ** 2, TRAY_SIZE[0] ** 2 + TRAY_SIZE[2] ** 2,
                                TRAY_SIZE[0] ** 2 + TRAY_SIZE[1] ** 2])
    return (f'<body name="tray" pos="{_fmt(pos)}"><freejoint name="tray_free"/>'
            f'<inertial pos="0 0 {-TRAY_SIZE[2]:.4f}" mass="{mass}" diaginertia="{_fmt(I)}"/>'
            f'<geom type="box" size="{_fmt(TRAY_SIZE)}" pos="0 0 {-TRAY_SIZE[2]:.4f}" rgba="0.55 0.38 0.22 1" '
            f'contype="0" conaffinity="0"/>'
            f'<geom type="cylinder" size="0.03 0.05" pos="0.0 0.0 0.05" rgba="0.2 0.45 0.8 0.9" contype="0" conaffinity="0"/>'
            f'</body>')


def so3_log1(R):
    tr = np.clip((np.trace(R) - 1) / 2, -1, 1)
    th = np.arccos(tr)
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    return v * (0.5 if th < 1e-8 else th / (2 * np.sin(th)))


class DualPhysics:
    def __init__(self, arms, q_init, K_t=3.0e4, D_t=150.0, K_r=300.0, D_r=0.5, tray_mass=1.0,
                 joint_damping=1.0, dt=0.0005, omega_ll=2 * np.pi * 10):
        self.arms = arms  # TRUE arms (physics and low-level models)
        K = kin_pair(arms, q_init[None], np.zeros((1, 14)))
        self.p_tray0 = 0.5 * (K[0]["p"][0] + K[1]["p"][0])
        xml = scene_xml([(arms[0], "l_"), (arms[1], "r_")], extra_world=tray_xml(self.p_tray0, tray_mass), timestep=dt)
        self.m = mujoco.MjModel.from_xml_string(xml)
        self.m.dof_damping[:14] = joint_damping
        self.d = mujoco.MjData(self.m)
        self.sid = [mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SITE, f"{s}tool") for s in ("l_", "r_")]
        self.bid = [mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, f"{s}link7") for s in ("l_", "r_")]
        self.tid = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, "tray")
        self.K_t, self.D_t, self.K_r, self.D_r, self.dt = K_t, D_t, K_r, D_r, dt
        self.kp, self.kd = omega_ll ** 2, 2 * omega_ll
        self.d.qpos[:14] = q_init
        self.d.qpos[14:17] = self.p_tray0
        self.d.qpos[17:21] = (1, 0, 0, 0)
        mujoco.mj_forward(self.m, self.d)
        # grasp attachment: tool frames expressed in the tray frame at the start (tray level)
        Rt = self.d.xmat[self.tid].reshape(3, 3)
        self.att = []
        for s in self.sid:
            Rs = self.d.site_xmat[s].reshape(3, 3)
            self.att.append((Rt.T @ (self.d.site_xpos[s] - self.d.xpos[self.tid]), Rt.T @ Rs))
        self.v6 = np.zeros(6)

    @property
    def q(self):
        return self.d.qpos[:14].copy()

    @property
    def qd(self):
        return self.d.qvel[:14].copy()

    def _grasp(self):
        """Apply the two grasp springs; return the grasp wrenches ON THE TRAY (world frame)."""
        d, m = self.d, self.m
        pt, Rt = d.xpos[self.tid], d.xmat[self.tid].reshape(3, 3)
        mujoco.mj_objectVelocity(m, d, mujoco.mjtObj.mjOBJ_BODY, self.tid, self.v6, 0)
        wt, vt = self.v6[:3].copy(), self.v6[3:].copy()  # tray angular / linear velocity at its origin
        W = []
        for s, b, (ap, aR) in zip(self.sid, self.bid, self.att):
            pa = pt + Rt @ ap  # attachment point on the tray
            va = vt + np.cross(wt, pa - pt)
            mujoco.mj_objectVelocity(m, d, mujoco.mjtObj.mjOBJ_SITE, s, self.v6, 0)
            ws, vs = self.v6[:3].copy(), self.v6[3:].copy()
            e_p = d.site_xpos[s] - pa
            e_R = so3_log1(d.site_xmat[s].reshape(3, 3) @ (Rt @ aR).T)
            f = -self.K_t * e_p - self.D_t * (vs - va)  # force on the hand
            tq = -self.K_r * e_R - self.D_r * (ws - wt)
            mujoco.mj_applyFT(m, d, f, tq, d.site_xpos[s], b, d.qfrc_applied)
            mujoco.mj_applyFT(m, d, -f, -tq, pa, self.tid, d.qfrc_applied)
            W.append(np.concatenate([-f, -tq]))  # wrench on the tray (force, torque)
        return W

    def _arm_terms(self, q, qd):
        """Arm-only M and bias: the arms and the tray are separate trees, so the 14x14 block of
        MuJoCo's mass matrix and the first 14 bias entries are exactly the arm model."""
        if not hasattr(self, "_Mfull"):
            self._Mfull = np.zeros((self.m.nv, self.m.nv))
        mujoco.mj_fullM(self.m, self.d, self._Mfull)
        return self._Mfull[:14, :14], self.d.qfrc_bias[:14].copy()

    def _log(self, W):
        Wl, Wr = W
        return dict(W_int=0.5 * (Wl - Wr), W_l=Wl, W_r=Wr, tray_R=self.d.xmat[self.tid].reshape(3, 3).copy(),
                    q=self.q)

    def step_order1(self, q0, q_plus, T):
        n = int(round(T / self.dt))
        qd_ref = (q_plus - q0) / T
        logs = []
        for i in range(n):
            q_ref = q0 + qd_ref * (i + 1) * self.dt
            self.d.qfrc_applied[:] = 0.0
            W = self._grasp()
            M, b = self._arm_terms(self.q, self.qd)
            self.d.qfrc_applied[:14] += M @ (self.kp * (q_ref - self.q) + self.kd * (qd_ref - self.qd)) + b
            mujoco.mj_step(self.m, self.d)
            logs.append(self._log(W))
        return logs

    def step_order2(self, a, T):
        n = int(round(T / self.dt))
        logs = []
        for _ in range(n):
            self.d.qfrc_applied[:] = 0.0
            W = self._grasp()
            M, b = self._arm_terms(self.q, self.qd)
            self.d.qfrc_applied[:14] += M @ a + b
            mujoco.mj_step(self.m, self.d)
            logs.append(self._log(W))
        return logs
