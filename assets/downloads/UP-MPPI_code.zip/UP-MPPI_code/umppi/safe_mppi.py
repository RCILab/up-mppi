"""Safe-MPPI baselines from the literature, re-implemented on the model, rows and costs of the unified controller.

None of the three methods handles equality constraints, so all of them keep the stabilised virtual rows (tray
level and heading on the waiter) by the same exact equality projection as Algorithm 1; they differ from it only
in how the inequality rows are treated (joint-limit HOCBF and velocity rows, task rows C qdd <= d such as the
support rows of the waiter, and the reaction box of physical rows such as the writing band).  With physical rows the
equalities are the Gauss dynamics of Algorithm 1 and the reaction box is treated by each method's own mechanism.

ShieldMPPI -- Yin, Dawson, Fan, Tsiotras, RA-L 2023 (arXiv:2302.11719).  The rollouts are unconstrained and
    their cost carries C max(alpha h(x_k) - h(x_{k+1}), 0) for every state barrier h (joint position and
    velocity limits; Eq. 19-20) and C max(g(x_k, v_k), 0) for every input row g (the support rows, which constrain
    the input directly).  The executed control is repaired by n_s fixed-step gradient-ascent iterations on
    sum_{k<N} min(h(x_{k+1}) - alpha h(x_k), 0) + min(-g, 0) over the first N controls (Eq. 22, Alg. 1).
DualGuardMPPI -- Borquez, Raus, Ciftci, Bansal, RA-L 2025 (arXiv:2502.01924).  Every sampled control passes a
    least-restrictive filter inside the rollouts: it is kept if the input rows hold and the next state stays in
    the Hamilton-Jacobi safe set of each joint, and otherwise replaced by the HJ-optimal safe control, which is
    maximal braking for a joint (the HJ value of a double integrator with bounded acceleration is the distance to
    the limit minus the braking distance) and zero tangential tray acceleration for the support rows (the input
    that maximises every tipping and slip margin at once).  The update averages the filtered samples (Eq. 3) and
    the output is filtered again.
GSMPPI -- Rabiee, Hoagg, arXiv:2410.02154 (CDC 2025).  All inequality rows, written as CBF conditions affine in
    the joint acceleration, are composed by the soft-min with parameter rho, and every sample passes the
    closed-form safe law (the Euclidean half-space projection onto the linearised composite, Eq. 19) inside the
    rollouts; the update averages the raw samples (Alg. 1, line 20) and the executed control is the safe law
    applied to the raw mean (Alg. 2).  GS-MPPI composes barrier functions of the state; the support rows constrain
    the input directly, so they enter the composite at the level of the CBF conditions.
"""
import time

import numpy as np

from .generic import CAMP2, _weights, mv


def _proj_eq(x, Mi, A, b):
    """M-metric projection of x onto {A x = b}, batched: x - Mi A^T (A Mi A^T)^-1 (A x - b)."""
    MiAt = Mi @ np.swapaxes(A, 1, 2)
    lam = np.linalg.solve(A @ MiAt, (mv(A, x) - b)[..., None])[..., 0]
    return x - mv(MiAt, lam)


class _SafeBase(CAMP2):
    def __init__(self, task, **kw):
        kw.setdefault("noise_clip", 3.0)
        super().__init__(task, solver="separable", virtual="hard", **kw)

    # ------------------------------------------------------------------ rows
    def _eq(self, q, qd, mdl):
        """Equality rows on the command a (the virtual rows through qdd = F a + f; physical rows hold for every a)."""
        e_v, Jv, jvd = mdl["vr"]
        r_v = -self.KD * mv(Jv, qd) - self.KP * e_v
        return Jv @ mdl["F"], r_v - mv(Jv, mdl["f"]) - jvd

    def _eq_proj(self, q, qd, a, mdl):
        """The equalities of Algorithm 1: M-projection of the motion part F a onto the stabilised virtual rows inside
        the tangent space; the reaction of a is kept."""
        F, f, Jp = mdl["F"], mdl["f"], mdl["Jp"]
        e_v, Jv, jvd = mdl["vr"]
        r_v = -self.KD * mv(Jv, qd) - self.KP * e_v
        A = np.concatenate([Jp, Jv], 1)
        b = np.concatenate([np.zeros(Jp.shape[:2]), r_v - mv(Jv, f) - jvd], 1)
        x = _proj_eq(mv(F, a), mdl["Mi"], A, b)
        if Jp.shape[1] == 0:
            return x
        return x - mv(mdl["MiJt"], self.lam_of(a, mdl) + mv(mdl["Lam"], mdl["jpd"]))

    def _margins(self, q, qd, a, mdl):
        """Normalised margins of every inequality row (>= 0 admissible) and their gradients in a."""
        F, f = mdl["F"], mdl["f"]
        d_lo, d_hi = self._rows(q, qd, f)
        x = mv(F, a)
        w, G = [d_lo + x, d_hi - x], [F, -F]
        if mdl["ex"] is not None:
            C, dc = mdl["ex"]
            w.append(dc - mv(C, x + f))
            G.append(-C @ F)
        T = self.task
        if mdl["Jp"].shape[1] and T.lam_lo is not None:
            lam = self.lam_of(a, mdl)
            LJ = mdl["Lam"] @ mdl["Jp"]
            w += [lam - T.lam_lo, T.lam_hi - lam]
            G += [-LJ, LJ]
        w, G = np.concatenate(w, 1), np.concatenate(G, 1)
        nrm = np.maximum(np.linalg.norm(G, axis=2), 1e-12)  # signed distances to the row hyperplanes in a
        return w / nrm, G / nrm[..., None]

    def _input_viol(self, q, qd, a, mdl):
        """Normalised violation of the rows that constrain the input directly (task rows, reaction box), >= 0."""
        out = [np.zeros((a.shape[0], 0))]
        if mdl["ex"] is not None:
            C, dc = mdl["ex"]
            CF = C @ mdl["F"]
            out.append(np.maximum(mv(C, mv(mdl["F"], a) + mdl["f"]) - dc, 0.0) / np.linalg.norm(CF, axis=2))
        T = self.task
        if mdl["Jp"].shape[1] and T.lam_lo is not None:
            lam = self.lam_of(a, mdl)
            nl = np.linalg.norm(mdl["Lam"] @ mdl["Jp"], axis=2)
            out += [np.maximum(T.lam_lo - lam, 0.0) / nl, np.maximum(lam - T.lam_hi, 0.0) / nl]
        return np.concatenate(out, 1)

    def _state_barriers(self, q, qd):
        T = self.task
        return np.concatenate([q - (T.q_min + T.h_safe), (T.q_max - T.h_safe) - q, T.qd_max - np.abs(qd)], 1)

    # ------------------------------------------------------------------ MPPI loop shared by the three methods
    def _filter(self, q, qd, a, mdl):
        raise NotImplementedError

    def _extra_cost(self, q, qd, q1, qd1, a, mdl):
        return 0.0

    def _update(self, w, eps, Ap):
        raise NotImplementedError

    def _output(self, q0, qd0, u0, mdl0):
        return self._filter(q0[None], qd0[None], self._eq_proj(q0[None], qd0[None], u0[None], mdl0), mdl0)[0]

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        T, K_, H, n, dt = self.task, self.K, self.H, self.n, self.dt
        T.t_now = t_now
        if getattr(T, "q_ref", 0) is None:
            T.q_ref = q0.copy()
        z = self.rng.standard_normal((K_, H, n))
        eps = self.sigma * (z if self.noise_clip is None else np.clip(z, -self.noise_clip, self.noise_clip))
        q, qd = np.repeat(q0[None], K_, 0), np.repeat(qd0[None], K_, 0)
        S = np.zeros(K_)
        Ap = np.empty((K_, H, n))
        for t in range(H):
            mdl = self._model(q, qd)
            a = self._filter(q, qd, self._eq_proj(q, qd, self.U[t][None] + eps[:, t], mdl), mdl)
            qd1 = qd + dt * (mv(mdl["F"], a) + mdl["f"])
            q1 = q + dt * qd1
            S += (T.run_cost(q1, qd1, self.lam_of(a, mdl), t) + self._extra_cost(q, qd, q1, qd1, a, mdl)) * dt
            q, qd = q1, qd1
            Ap[:, t] = a
        S += T.term_cost(q, qd)
        w = _weights(S, self.eta)
        mdl0 = self._model(q0[None], qd0[None])
        self._As = self._update(w, eps, Ap)
        a0 = self._output(q0, qd0, self._As[0], mdl0)
        As = self._As  # the output step may modify the sequence (Shield's repair)
        self.U = np.concatenate([As[1:], np.zeros((1, n))], 0)
        self.stats["time"].append(time.perf_counter() - t0)
        lam0 = self.lam_of(a0[None], mdl0)[0]
        return {"a": a0, "lam_cmd": float(lam0[0]) if lam0.size == 1 else lam0}


class ShieldMPPI(_SafeBase):
    def __init__(self, task, C=1e3, alpha=0.9, n_s=20, N=3, step=0.5, fd=1e-4, **kw):
        super().__init__(task, **kw)
        self.C, self.alpha, self.n_s, self.N, self.step, self.fd = C, alpha, n_s, N, step, fd

    def _filter(self, q, qd, a, mdl):
        return a  # unconstrained rollouts (inequality rows enter the cost)

    def _cbf_terms(self, q, qd, q1, qd1, a, mdl):
        """Discrete CBF residuals min(h(x_{k+1}) - alpha h(x_k), 0) and input-row residuals min(-g, 0)."""
        h0, h1 = self._state_barriers(q, qd), self._state_barriers(q1, qd1)
        return np.concatenate([np.minimum(h1 - self.alpha * h0, 0.0), -self._input_viol(q, qd, a, mdl)], 1)

    def _extra_cost(self, q, qd, q1, qd1, a, mdl):
        return -self.C * np.sum(self._cbf_terms(q, qd, q1, qd1, a, mdl), 1)

    def _update(self, w, eps, Ap):
        return np.einsum("k,kti->ti", w, Ap)  # the samples are unconstrained up to the equalities

    def _repair_objective(self, q0, qd0, V):
        """sum over the first N steps of the CBF and input-row residuals, for a batch of control sequences V."""
        B = V.shape[0]
        q, qd = np.repeat(q0[None], B, 0), np.repeat(qd0[None], B, 0)
        J = np.zeros(B)
        for k in range(V.shape[1]):
            mdl = self._model(q, qd)
            a = self._eq_proj(q, qd, V[:, k], mdl)
            qd1 = qd + self.dt * (mv(mdl["F"], a) + mdl["f"])
            q1 = q + self.dt * qd1
            J += np.sum(self._cbf_terms(q, qd, q1, qd1, a, mdl), 1)
            q, qd = q1, qd1
        return J

    def _output(self, q0, qd0, u0, mdl0):
        """Repair the first N controls of the MPPI solution; the warm start keeps the repaired sequence."""
        v = self._As[:self.N].copy()
        for _ in range(self.n_s):
            J0 = self._repair_objective(q0, qd0, v[None])[0]
            if J0 >= -1e-12:
                break
            P = np.repeat(v[None], v.size, 0)
            P.reshape(v.size, -1)[np.arange(v.size), np.arange(v.size)] += self.fd
            g = ((self._repair_objective(q0, qd0, P) - J0) / self.fd).reshape(v.shape)
            v = v + self.step * g / max(np.linalg.norm(g), 1e-12)
        self._As = self._As.copy()
        self._As[:self.N] = v
        return self._eq_proj(q0[None], qd0[None], v[0][None], mdl0)[0]


class DualGuardMPPI(_SafeBase):
    def __init__(self, task, a_brake=10.0, **kw):
        super().__init__(task, **kw)
        self.a_brake = a_brake

    def _hj_value(self, q, qd):
        """HJ value of every joint as a double integrator with |qdd| <= a_brake, for the lower and upper limit
        (inside the margin h_safe): distance to the limit minus the braking distance."""
        T, ab = self.task, self.a_brake
        lo = q - (T.q_min + T.h_safe) - np.maximum(-qd, 0.0) ** 2 / (2 * ab)
        hi = (T.q_max - T.h_safe) - q - np.maximum(qd, 0.0) ** 2 / (2 * ab)
        return lo, hi

    def _safe_support(self, q, qd, a, mdl):
        """HJ-optimal safe input for the support rows: zero tangential tray acceleration (with the equalities)."""
        K = mdl["K"]
        A, b = self._eq(q, qd, mdl)
        n = -K["zt"]
        x7 = K["R"][:, -1][:, :, 0]
        t1 = x7 - np.sum(x7 * n, 1, keepdims=True) * n
        t1 = t1 / np.linalg.norm(t1, axis=1, keepdims=True)
        t2 = np.cross(n, t1)
        Jb, jd = K["Jv"], K["jdv"] - np.array([0.0, 0.0, -9.81])
        Tt = np.stack([np.einsum("bi,bij->bj", t1, Jb), np.einsum("bi,bij->bj", t2, Jb)], 1)
        bt = -np.stack([np.sum(t1 * jd, 1), np.sum(t2 * jd, 1)], 1)
        return _proj_eq(a, mdl["Mi"], np.concatenate([A, Tt], 1), np.concatenate([b, bt], 1))

    def _filter(self, q, qd, a, mdl):
        a = a.copy()
        if mdl["ex"] is not None:  # least-restrictive filter on the input rows
            bad = np.any(self._input_viol(q, qd, a, mdl) > 0, 1)
            if bad.any():
                sub = {k: (v[bad] if isinstance(v, np.ndarray) and v.shape[:1] == (len(bad),) else v)
                       for k, v in mdl.items() if k not in ("K", "vr", "ex")}
                sub["K"] = {k: v[bad] for k, v in mdl["K"].items()}
                sub["vr"] = tuple(v[bad] for v in mdl["vr"])
                a[bad] = self._safe_support(q[bad], qd[bad], a[bad], sub)
        T = self.task
        if mdl["Jp"].shape[1] and T.lam_lo is not None:  # reaction outside the box: the centre of the box
            lam = self.lam_of(a, mdl)
            bad = np.any((lam < T.lam_lo) | (lam > T.lam_hi), 1)
            if bad.any():
                a[bad] = a[bad] + mv(mdl["MiJt"][bad], lam[bad] - 0.5 * (T.lam_lo + T.lam_hi))
        # least-restrictive filter on the HJ safe set of each joint, checked at the next state
        qd1 = qd + self.dt * (mv(mdl["F"], a) + mdl["f"])
        q1 = q + self.dt * qd1
        lo, hi = self._hj_value(q1, qd1)
        a = np.where(lo < 0, self.a_brake, a)
        a = np.where(hi < 0, -self.a_brake, a)
        return a

    def _update(self, w, eps, Ap):
        return np.einsum("k,kti->ti", w, Ap)  # average of the filtered samples (DualGuard Eq. 3)


class GSMPPI(_SafeBase):
    """With state barriers the composite CBF condition is affine in the input and one application of the safe law
    is exact; with input rows in the composite it is concave in the input, so the law is applied repeatedly (up to
    `iters` times) until the composite holds."""

    def __init__(self, task, rho=20.0, iters=5, **kw):
        super().__init__(task, **kw)
        self.rho, self.iters = rho, iters

    def _composite(self, q, qd, a, mdl):
        om, G = self._margins(q, qd, a, mdl)
        m = om.min(1, keepdims=True)
        e = np.exp(-self.rho * (om - m))
        s = e / e.sum(1, keepdims=True)
        return m[:, 0] - np.log(e.sum(1)) / self.rho, np.einsum("bi,bij->bj", s, G)  # soft-min and its gradient

    def _filter(self, q, qd, a, mdl):
        A, _ = self._eq(q, qd, mdl)
        At = np.swapaxes(A, 1, 2)
        for _ in range(self.iters):
            Om, g = self._composite(q, qd, a, mdl)
            if np.all(Om >= -1e-9):
                break
            # keep the equalities: Euclidean projection of the step direction onto their null space
            d = g - mv(At, np.linalg.solve(A @ At, mv(A, g)[..., None])[..., 0])
            step = np.maximum(-Om, 0.0) / np.maximum(np.sum(d * d, 1), 1e-12)  # safe law, Eq. 19 with gamma -> inf
            a = a + step[:, None] * d
        return a

    def _update(self, w, eps, Ap):
        return self.U + np.einsum("k,kti->ti", w, eps)  # raw average (Alg. 1, line 20)
