"""The batched controller model must reproduce MuJoCo's rigid-body quantities exactly."""
import mujoco
import numpy as np

from umppi.mjcf import scene_xml
from umppi.robot import Q_MAX, Q_MIN, Chain


def main():
    rng = np.random.default_rng(0)
    chain = Chain(base_pos=np.array([0.1, -0.2, 0.3]))
    m = mujoco.MjModel.from_xml_string(scene_xml([(chain, "")]))
    d = mujoco.MjData(m)
    sid = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_SITE, "tool")
    B = 64
    q = rng.uniform(Q_MIN, Q_MAX, (B, 7))
    qd = rng.uniform(-2, 2, (B, 7))
    Rt, pt = chain.tool_pose(q)
    M = chain.mass_matrix(q)
    b = chain.bias(q, qd)
    Jv, Jw, _ = chain.jacobian(q)
    acc_v, acc_w = chain.point_acc_bias(q, qd)
    err = dict(pos=0.0, M=0.0, bias=0.0, Jv=0.0, Jw=0.0, rnea=0.0, jdot=0.0, sym=0.0)
    for k in range(B):
        d.qpos[:] = q[k]
        d.qvel[:] = qd[k]
        mujoco.mj_forward(m, d)
        err["pos"] = max(err["pos"], np.max(np.abs(d.site_xpos[sid] - pt[k])))
        Mm = np.zeros((7, 7))
        mujoco.mj_fullM(m, d, Mm)
        err["M"] = max(err["M"], np.max(np.abs(Mm - M[k])) / np.max(np.abs(Mm)))
        err["bias"] = max(err["bias"], np.max(np.abs(d.qfrc_bias - b[k])) / (1 + np.max(np.abs(d.qfrc_bias))))
        jp, jr = np.zeros((3, 7)), np.zeros((3, 7))
        mujoco.mj_jacSite(m, d, jp, jr, sid)
        err["Jv"] = max(err["Jv"], np.max(np.abs(jp - Jv[k])))
        err["Jw"] = max(err["Jw"], np.max(np.abs(jr - Jw[k])))
    qdd = rng.standard_normal((B, 7))
    err["rnea"] = np.max(np.abs(chain.rnea(q, qd, qdd) - (np.einsum("kij,kj->ki", M, qdd) + b)))
    err["sym"] = np.max(np.abs(M - np.swapaxes(M, 1, 2)))
    eps = 1e-6
    Jp, Jwp, _ = chain.jacobian(q + eps * qd)
    Jm, Jwm, _ = chain.jacobian(q - eps * qd)
    jd_v = np.einsum("kij,kj->ki", (Jp - Jm) / (2 * eps), qd)
    jd_w = np.einsum("kij,kj->ki", (Jwp - Jwm) / (2 * eps), qd)
    err["jdot"] = max(np.max(np.abs(jd_v - acc_v)), np.max(np.abs(jd_w - acc_w)))
    ok = (err["pos"] < 1e-12 and err["M"] < 1e-10 and err["bias"] < 1e-10 and err["Jv"] < 1e-12
          and err["Jw"] < 1e-12 and err["rnea"] < 1e-9 and err["sym"] < 1e-12 and err["jdot"] < 1e-6)
    for k_, v in err.items():
        print(f"  {k_:5s} max err {v:.2e}")
    print("PASS" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    main()
