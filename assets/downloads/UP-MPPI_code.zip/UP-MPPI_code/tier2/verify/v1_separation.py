"""T1 -- constraint classes and the separation theorem (order-2, Gauss dynamics).

Checks
  1. energy split  ||da||_M^2 = ||d qdd||_M^2 + ||d lam||^2_{Lam^-1}
  2. joint M-projection onto (motion-only) cap (reaction-only) == two separated QPs
  3. leakage: R-only violation -> motion change,  K-only violation -> reaction change,
     for W = M, M + Jc^T S Jc (separating), I and random SPD (non-separating)
  4. reaction-only constraints never restrict the achievable motion (LP optimum unchanged)
  5. coupled rows (torque limits) break separation; sequential projection fails
  6. a passive coordinate makes reaction-only rows restrict motion (LP bounded vs unbounded)
"""
import numpy as np
from scipy.optimize import linprog

from common import Report, null_basis, qp_project, rand_spd, wnorm

rng = np.random.default_rng(7)
n, ne = 7, 2
TRIALS = 200


def system(rng, spread=1.5):
    M = rand_spd(n, rng, spread)
    Jc = rng.standard_normal((ne, n))
    r = rng.standard_normal(ne)  # r = Jc_dot qdot
    Mi = np.linalg.inv(M)
    Lam = np.linalg.inv(Jc @ Mi @ Jc.T)
    F = np.eye(n) - Mi @ Jc.T @ Lam @ Jc
    f = -Mi @ Jc.T @ Lam @ r
    return dict(M=M, Jc=Jc, r=r, Mi=Mi, Lam=Lam, F=F, f=f)


def qdd(s, a):
    return s["F"] @ a + s["f"]


def lam(s, a):
    return -s["Lam"] @ (s["Jc"] @ a + s["r"])


def phi_inv(s, qdd_, lam_):
    """Inverse of a -> (qdd, lam)."""
    return (qdd_ - s["f"]) - s["Mi"] @ s["Jc"].T @ (lam_ + s["Lam"] @ s["r"])


def constraint_sets(s, rng, mK=4):
    """Random feasible motion-only rows (C_K a <= d_K) and a reaction box (lam_lo <= lam <= lam_hi)."""
    a0 = rng.standard_normal(n)
    C_K = rng.standard_normal((mK, n)) @ s["F"]  # rows annihilate M^-1 Jc^T  -> motion-only
    d_K = C_K @ a0 + rng.uniform(0.05, 0.5, mK)
    l0 = lam(s, a0)
    lam_lo, lam_hi = l0 - rng.uniform(0.05, 0.5, ne), l0 + rng.uniform(0.05, 0.5, ne)
    A_l = np.vstack([np.eye(ne), -np.eye(ne)])
    b_l = np.concatenate([lam_hi, -lam_lo])
    # reaction rows in a:  A_l lam(a) <= b_l  <=>  A_l(-Lam Jc) a <= b_l + A_l Lam r
    C_R = A_l @ (-s["Lam"] @ s["Jc"])
    d_R = b_l + A_l @ s["Lam"] @ s["r"]
    return a0, C_K, d_K, A_l, b_l, C_R, d_R


def main():
    rep = Report("T1 separation")

    # 1. energy split -------------------------------------------------------------
    err = 0.0
    for _ in range(TRIALS):
        s = system(rng)
        da = rng.standard_normal(n)
        dq, dl = s["F"] @ da, -s["Lam"] @ s["Jc"] @ da
        lhs = da @ s["M"] @ da
        rhs = dq @ s["M"] @ dq + dl @ np.linalg.solve(s["Lam"], dl)
        err = max(err, abs(lhs - rhs) / lhs)
    rep.check("energy split identity", err < 1e-9, f"max rel err {err:.1e}")

    # 2. joint projection == separated projections ------------------------------
    e_a = e_q = e_l = 0.0
    for _ in range(TRIALS):
        s = system(rng)
        a0, C_K, d_K, A_l, b_l, C_R, d_R = constraint_sets(s, rng)
        a_raw = a0 + 2.0 * rng.standard_normal(n)
        a_st, _, _ = qp_project(a_raw, s["M"], Ain=np.vstack([C_K, C_R]), bin_=np.concatenate([d_K, d_R]))
        # motion QP on x = qdd - f in T:  min ||x - F a_raw||_M  s.t. Jc x = 0, C_K x <= d_K
        x_st, _, _ = qp_project(s["F"] @ a_raw, s["M"], Aeq=s["Jc"], beq=np.zeros(ne), Ain=C_K, bin_=d_K)
        # reaction QP:  min ||l - lam(a_raw)||_{Lam^-1}  s.t.  A_l l <= b_l
        l_st, _, _ = qp_project(lam(s, a_raw), np.linalg.inv(s["Lam"]), Ain=A_l, bin_=b_l)
        a_sep = phi_inv(s, x_st + s["f"], l_st)
        e_a = max(e_a, np.linalg.norm(a_st - a_sep) / (1 + np.linalg.norm(a_st)))
        e_q = max(e_q, np.linalg.norm(qdd(s, a_st) - (x_st + s["f"])))
        e_l = max(e_l, np.linalg.norm(lam(s, a_st) - l_st))
    rep.check("joint M-projection == separated QPs", max(e_a, e_q, e_l) < 1e-7,
              f"max |da| {e_a:.1e}, |dqdd| {e_q:.1e}, |dlam| {e_l:.1e}")

    # 3. leakage for different metrics -------------------------------------------
    leak = {k: [0.0, 0.0] for k in ("M", "M+JtSJ", "I", "rand")}
    for _ in range(TRIALS):
        s = system(rng)
        a0, C_K, d_K, A_l, b_l, C_R, d_R = constraint_sets(s, rng)
        S = rand_spd(ne, rng, 1.0)
        metrics = {"M": s["M"], "M+JtSJ": s["M"] + s["Jc"].T @ S @ s["Jc"],
                   "I": np.eye(n), "rand": rand_spd(n, rng, 1.5)}
        Ain, bin_ = np.vstack([C_K, C_R]), np.concatenate([d_K, d_R])
        # R-only violation: shift a0 along the M-normal space (changes lam only)
        y = rng.standard_normal(ne)
        a_R = a0 + s["Mi"] @ s["Jc"].T @ (3.0 * y / np.linalg.norm(y))
        # K-only violation: shift a0 inside T (changes qdd only)
        Z = null_basis(s["Jc"])
        a_K = a0 + 3.0 * Z @ rng.standard_normal(n - ne)
        for key, W in metrics.items():
            if np.any(C_R @ a_R > d_R + 1e-9):
                u, _, _ = qp_project(a_R, W, Ain=Ain, bin_=bin_)
                leak[key][0] = max(leak[key][0], np.linalg.norm(qdd(s, u) - qdd(s, a_R)))
            if np.any(C_K @ a_K > d_K + 1e-9):
                u, _, _ = qp_project(a_K, W, Ain=Ain, bin_=bin_)
                leak[key][1] = max(leak[key][1], np.linalg.norm(lam(s, u) - lam(s, a_K)))
    for key, (lq, ll) in leak.items():
        sep = key in ("M", "M+JtSJ")
        ok = (max(lq, ll) < 1e-7) if sep else (min(lq, ll) > 1e-3)
        rep.check(f"leakage W={key:7s} ({'separating' if sep else 'non-separating'})", ok,
                  f"R-fix->motion {lq:.1e}, K-fix->reaction {ll:.1e}")

    # 4. reaction-only rows never restrict motion -------------------------------
    gap = 0.0
    for _ in range(TRIALS // 4):
        s = system(rng)
        Z = null_basis(s["Jc"])  # orthonormal basis of T
        C_Kb = np.vstack([Z.T @ s["F"], -Z.T @ s["F"]])  # |z_i| <= 1 box on tangent coordinates
        d_Kb = np.ones(2 * (n - ne))
        _, _, _, _, _, C_R, d_R = constraint_sets(s, rng)
        g = s["F"].T @ rng.standard_normal(n)  # objective g^T a = (g')^T qdd + const
        r1 = linprog(-g, A_ub=C_Kb, b_ub=d_Kb, bounds=[(None, None)] * n)
        r2 = linprog(-g, A_ub=np.vstack([C_Kb, C_R]), b_ub=np.concatenate([d_Kb, d_R]),
                     bounds=[(None, None)] * n)
        gap = max(gap, abs(r1.fun - r2.fun))
    rep.check("reaction-only rows leave the motion optimum unchanged (LP)", gap < 1e-7, f"max gap {gap:.1e}")

    # 5. coupled rows: torque limits ---------------------------------------------
    sep_fail = seq_fail = cnt = 0
    for _ in range(TRIALS):
        s = system(rng)
        a0, C_K, d_K, A_l, b_l, C_R, d_R = constraint_sets(s, rng)
        b = rng.standard_normal(n)
        tau0 = s["M"] @ a0 + b
        tbar = np.abs(tau0) + rng.uniform(0.05, 0.3, n)  # a0 satisfies |M a + b| <= tbar
        C_T = np.vstack([s["M"], -s["M"]])
        d_T = np.concatenate([tbar - b, tbar + b])
        a_raw = a0 + 2.0 * rng.standard_normal(n)
        A_all = np.vstack([C_K, C_R, C_T])
        b_all = np.concatenate([d_K, d_R, d_T])
        try:
            a_st, _, _ = qp_project(a_raw, s["M"], Ain=A_all, bin_=b_all)
        except RuntimeError:
            continue
        cnt += 1
        a_kr, _, _ = qp_project(a_raw, s["M"], Ain=np.vstack([C_K, C_R]), bin_=np.concatenate([d_K, d_R]))
        if np.linalg.norm(a_kr - a_st) > 1e-6 and np.any(C_T @ a_kr > d_T + 1e-9):
            sep_fail += 1  # separated answer ignores the coupled rows
        a_seq, _, _ = qp_project(a_kr, s["M"], Ain=C_T, bin_=d_T)  # then clip torques
        if np.any(np.vstack([C_K, C_R]) @ a_seq > np.concatenate([d_K, d_R]) + 1e-7):
            seq_fail += 1
    rep.check("torque limits (coupled): separated answer infeasible in some trials", sep_fail > 0,
              f"{sep_fail}/{cnt} trials")
    rep.check("torque limits (coupled): sequential K,R -> torque projection breaks K or R", seq_fail > 0,
              f"{seq_fail}/{cnt} trials")

    # 6. passive coordinate couples reaction rows to motion ----------------------
    bounded = unbounded_full = unbounded_noband = 0
    for _ in range(TRIALS // 4):
        s = system(rng)
        Z = null_basis(s["Jc"])
        d = Z @ rng.standard_normal(n - ne)
        d /= np.linalg.norm(d)
        l0 = rng.standard_normal(ne)
        band_lo, band_hi = l0 - 0.5, l0 + 0.5
        for passive in (True, False):
            na = n - 1 if passive else n
            E = np.eye(n)[:, :na]
            a_p = np.eye(n)[:, n - 1] * 0.7 if passive else np.zeros(n)
            # variables x = [a_act, s]; maximize s
            c = np.zeros(na + 1)
            c[-1] = -1.0
            A_eq = np.hstack([Z.T @ s["F"] @ E, -(Z.T @ d)[:, None]])
            b_eq = -Z.T @ s["F"] @ a_p  # qdd - qdd(a_act = 0) = s d
            G = -s["Lam"] @ s["Jc"] @ E
            g0 = -s["Lam"] @ (s["Jc"] @ a_p + s["r"])
            A_ub = np.vstack([np.hstack([G, np.zeros((ne, 1))]), np.hstack([-G, np.zeros((ne, 1))])])
            b_ub = np.concatenate([band_hi - g0, g0 - band_lo])
            res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=[(None, None)] * (na + 1))
            if passive:
                bounded += res.status == 0
                res2 = linprog(c, A_eq=A_eq, b_eq=b_eq, bounds=[(None, None)] * (na + 1))
                unbounded_noband += res2.status == 3
            else:
                unbounded_full += res.status == 3
    N6 = TRIALS // 4
    rep.check("fully actuated: reaction band never bounds motion (LP unbounded)", unbounded_full == N6,
              f"{unbounded_full}/{N6}")
    rep.check("one passive coordinate: same band bounds motion (LP bounded)", bounded == N6 and unbounded_noband == N6,
              f"bounded {bounded}/{N6}, unbounded without band {unbounded_noband}/{N6}")
    return rep


if __name__ == "__main__":
    main()
