"""Record the video scenarios of the writing task (states only; rendering is separate)."""
import sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiments.writing_exp as X  # noqa: E402

OUT = Path(__file__).resolve().parent / "results" / "videos"
SCENARIOS = [  # (tag, controller, delta_mm, seed, title)
    ("pr_press", "PR", -1.0, 0, "PR-MPPI | board model 1 mm below the real board"),
    ("pr_lift", "PR", 0.5, 0, "PR-MPPI | board model 0.5 mm above the real board"),
    ("camp_manifold", "CAMP-manifold", 0.0, 0, "CAMP-MPPI | pen orientation inside the manifold"),
    ("unified", "Unified", 0.0, 0, "Unified (ours) | virtual pen rows, reaction band"),
]


def job(sc):
    tag, name, dl, seed, title = sc
    rec = {}
    r, _ = X.run(name, dl, seed=seed, rec=rec)
    OUT.mkdir(parents=True, exist_ok=True)
    np.savez(OUT / f"{tag}.npz", t=np.array(rec["t"]), qpos=np.array(rec["qpos"]),
             ink_p=np.array(rec["ink_p"]), ink_f=np.array(rec["ink_f"]),
             lam_cmd=np.array(rec.get("lam_cmd", [])), diverged_t=-1.0 if r["diverged_t"] is None else r["diverged_t"],
             title=title, delta_mm=dl)
    return tag, r["diverged_t"], r["force_mean"]


if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    with Pool(len(SCENARIOS)) as p:
        for tag, div, f in p.imap_unordered(job, SCENARIOS):
            print(tag, "diverged at" if div else "completed", div or "", f"mean force {f:.2f} N", flush=True)
