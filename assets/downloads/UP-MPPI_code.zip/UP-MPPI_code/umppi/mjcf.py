"""MJCF generation for the Franka-like chain (same parameters as robot.Chain).

Collisions are disabled; contact with task surfaces is applied as an explicit
spring-damper-friction force (physics.py), so the environment stiffness is known exactly.
"""
import mujoco
import numpy as np

from .robot import DH, Chain


def _quat_from_rot(R):
    q = np.zeros(4)
    mujoco.mju_mat2Quat(q, np.ascontiguousarray(R, dtype=np.float64).reshape(9))
    return q


def _fmt(v):
    return " ".join(f"{x:.17g}" for x in np.atleast_1d(v))


LINK_RGBA, JOINT_RGBA = "0.93 0.93 0.93 1", "0.22 0.22 0.24 1"


def _vgeom(kind, **attrs):
    """Visual-only geom (bodies carry explicit inertials, and contact is disabled)."""
    a = " ".join(f'{k}="{v}"' for k, v in attrs.items())
    return f'<geom type="{kind}" {a} contype="0" conaffinity="0" group="1"/>'


def arm_xml(chain: Chain, prefix="", rgba=LINK_RGBA, tool_extra=""):
    """Nested bodies of one arm, to be placed inside <worldbody>.  Visuals: a capsule from each
    joint to the next and a dark housing along every joint axis (Franka-like look)."""
    xml = []
    indent = "  "
    bq = _quat_from_rot(chain.base_rot)
    xml.append(f'<body name="{prefix}base" pos="{_fmt(chain.base_pos)}" quat="{_fmt(bq)}">')
    xml.append(indent + _vgeom("cylinder", size="0.075 0.03", pos="0 0 0.03", rgba=JOINT_RGBA))
    xml.append(indent + _vgeom("capsule", fromto=f"0 0 0.03 {_fmt(chain.p[0])}", size="0.06", rgba=rgba))
    depth = 1
    for i in range(chain.n):
        pad = indent * depth
        quat = _quat_from_rot(chain.Rx[i])
        xml.append(f'{pad}<body name="{prefix}link{i + 1}" pos="{_fmt(chain.p[i])}" quat="{_fmt(quat)}">')
        # principal axes computed here in float64 (MuJoCo's own diagonalisation is ~1e-9 accurate)
        evals, evecs = np.linalg.eigh(chain.I[i])
        if np.linalg.det(evecs) < 0:
            evecs[:, 0] = -evecs[:, 0]
        iq = _quat_from_rot(evecs)
        xml.append(f'{pad}{indent}<inertial pos="{_fmt(chain.com[i])}" quat="{_fmt(iq)}" mass="{chain.mass[i]:.17g}" diaginertia="{_fmt(evals)}"/>')
        xml.append(f'{pad}{indent}<joint name="{prefix}j{i + 1}" type="hinge" axis="0 0 1" armature="{chain.armature[i]:.17g}" damping="0" limited="false"/>')
        r = 0.055 if i < 4 else 0.045
        xml.append(pad + indent + _vgeom("cylinder", size=f"{r + 0.004:.3f} {r:.3f}", rgba=JOINT_RGBA))
        nxt = chain.p[i + 1] if i + 1 < chain.n else np.array([0.0, 0.0, 0.107])
        if np.linalg.norm(nxt) > 1e-6:
            xml.append(pad + indent + _vgeom("capsule", fromto=f"0 0 0 {_fmt(nxt)}", size=f"{r - 0.008:.3f}", rgba=rgba))
        depth += 1
    pad = indent * depth
    xml.append(f'{pad}<site name="{prefix}tool" pos="{_fmt(chain.tool)}" size="0.004" rgba="1 0 0 1"/>')
    xml.append(pad + _vgeom("cylinder", size="0.035 0.012", pos="0 0 0.107", rgba=JOINT_RGBA))
    xml.append(pad + _vgeom("capsule", fromto=f"0 0 0.11 {_fmt(chain.tool - np.array([0, 0, 0.012]))}",
                            size="0.009", rgba="0.15 0.35 0.75 1"))
    xml.append(pad + _vgeom("sphere", size="0.004", pos=_fmt(chain.tool), rgba="0.05 0.05 0.05 1"))
    if tool_extra:  # task geometry rigidly attached to the last link (e.g. a tray)
        xml.append(pad + tool_extra)
    for d in range(depth - 1, -1, -1):
        xml.append(indent * d + "</body>")
    return "\n".join(xml)


def scene_xml(arms, extra_world="", timestep=0.001, extra_asset="", equality="", contact=False, tool_extra=""):
    """arms: list of (chain, prefix).  contact=True enables MuJoCo contacts (only geoms with
    contype/conaffinity set collide; all arm visuals have them off)."""
    bodies = "\n".join(arm_xml(c, p, tool_extra=tool_extra) for c, p in arms)
    flag = "" if contact else '<flag contact="disable"/>'
    return f"""<mujoco model="umppi">
  <compiler angle="radian"/>
  <option timestep="{timestep}" gravity="0 0 -9.81" integrator="Euler">
    {flag}
  </option>
  <visual>
    <global offwidth="1920" offheight="1080"/>
    <quality shadowsize="4096"/>
    <headlight ambient="0.35 0.35 0.35" diffuse="0.5 0.5 0.5"/>
  </visual>
  <asset>
    <texture name="grid" type="2d" builtin="checker" rgb1="0.82 0.83 0.85" rgb2="0.74 0.75 0.78" width="512" height="512"/>
    <material name="floor" texture="grid" texrepeat="8 8" reflectance="0.05"/>
{extra_asset}
  </asset>
  <worldbody>
    <light pos="0.6 -0.8 2.2" dir="-0.2 0.35 -1" castshadow="true" diffuse="0.6 0.6 0.6"/>
    <light pos="-0.6 0.8 2.0" dir="0.3 -0.3 -1" castshadow="false" diffuse="0.3 0.3 0.3"/>
    <geom name="floor" type="plane" size="3 3 0.05" pos="0 0 -0.62" material="floor" contype="0" conaffinity="0"/>
{bodies}
{extra_world}
  </worldbody>
{equality}
</mujoco>"""


assert DH.shape == (7, 3)
