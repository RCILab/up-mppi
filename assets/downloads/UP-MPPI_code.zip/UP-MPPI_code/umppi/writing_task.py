"""The writing task through the generic task interface of umppi.generic: the contact as the physical row with the
reaction band [2, 4] N, the pen orientation as the virtual rows, and the costs of controllers.CAMPMPPI (tracking of
the path, velocity and posture regularisation, reaction cost towards the nominal 3 N), so that CAMP2 and the
controllers of umppi.safe_mppi run on it."""
import numpy as np

from . import writing as W_
from .robot import Q_MAX, Q_MIN, QD_MAX


class WritingTask:
    def __init__(self, chain, delta=0.0, q_ref=None, w_p=1e5, w_T=1e4, w_v=5.0, w_q=5.0, w_f=1.0, dt=0.01, H=15,
                 h_safe=0.05):
        self.chain, self.delta, self.n = chain, delta, chain.n
        self.q_min, self.q_max, self.qd_max, self.h_safe = Q_MIN, Q_MAX, QD_MAX, h_safe
        self.lam_lo, self.lam_hi = np.array([W_.LAM_BAND[0]]), np.array([W_.LAM_BAND[1]])
        self.q_ref = q_ref
        self.w_p, self.w_T, self.w_v, self.w_q, self.w_f, self.dt, self.H = w_p, w_T, w_v, w_q, w_f, dt, H
        self.t_now = 0.0

    def kin(self, q, qd):
        return W_.kin(self.chain, q, qd)

    def mass(self, q, K):
        return self.chain.mass_matrix(q, K["R"], K["o"])

    def phys(self, K):
        c, Jc, jcd, _ = W_.contact(K, self.delta)
        return c, Jc, jcd

    def virt(self, K):
        return W_.orientation(K)

    def _target(self, t):
        return W_.path_point(np.array([self.t_now + self.dt * (t + 1)]))[0]

    def run_cost(self, q, qd, lam, t):
        p = self.chain.tool_pose(q)[1]
        c = (self.w_p * np.sum((p - self._target(t)) ** 2, 1) + self.w_v * np.sum(qd * qd, 1)
             + self.w_q * np.sum((q - self.q_ref) ** 2, 1))
        if lam is not None and lam.shape[1]:
            c = c + self.w_f * np.sum((lam - W_.LAM_NOM) ** 2, 1)
        return c

    def term_cost(self, q, qd):
        p = self.chain.tool_pose(q)[1]
        return self.w_T * np.sum((p - self._target(self.H - 1)) ** 2, 1)
