"""Task-agnostic PR-MPPI (order 1) and CAMP-MPPI / unified (order 2) controllers.

A task provides (all batched over B):
  n, q_min, q_max, qd_max, h_safe
  kin(q, qd) -> K ;  mass(q, K) -> M (B,n,n)
  phys(K) -> (c_p, J_p, jpd)       physical rows (environment-enforced)
  virt(K) -> (e_v, J_v, jvd)       virtual rows (controller-enforced), or None
  run_cost(q, qd, lam, t) -> (B,) ;  term_cost(q, qd) -> (B,)
  lam_lo, lam_hi                   reaction box on the physical rows (order 2), or None
"""
import time

import numpy as np

from .qp import project


def _weights(S, eta):
    beta = max(eta * np.std(S), 1e-12)
    w = np.exp(-(S - S.min()) / beta)
    return w / w.sum()


def mv(A, v):
    return (A @ v[..., None])[..., 0]


class _Core:
    def __init__(self, task, K=256, H=15, dt=0.02, eta=0.5, seed=0):
        self.task, self.K, self.H, self.dt, self.eta = task, K, H, dt, eta
        self.n = task.n
        self.rng = np.random.default_rng(seed)
        self.U = np.zeros((H, self.n))
        self.stats = {"fallback": 0, "relaxed": 0, "calls": 0, "time": []}

    def _project(self, *a, **kw):
        u, info = project(*a, return_info=True, **kw)
        self.stats["fallback"] += info["fallback"]
        self.stats["relaxed"] += info["relaxed"]
        self.stats["calls"] += a[0].shape[0]
        return u


class PR1(_Core):
    """Order 1 (PR-MPPI).  retract: "all" (as published), "anchored" (Prop. 7) or "none";
    inequality=False drops the CBF rows (the ablation, which then relies on a cost penalty)."""

    def __init__(self, task, sigma=0.05, gamma=5.0, metric="I", retract="all", inequality=True,
                 retract_metric="I", **kw):
        super().__init__(task, **kw)
        self.sigma, self.gamma, self.metric = sigma, gamma, metric
        self.retract_mode, self.inequality, self.retract_metric = retract, inequality, retract_metric

    def _pi(self, q, v):
        T = self.task
        B, n = q.shape
        K = T.kin(q, np.zeros_like(q))
        _, Jp, _ = T.phys(K)
        vr = T.virt(K)
        E = Jp if vr is None else np.concatenate([Jp, vr[1]], 1)
        I = np.broadcast_to(np.eye(n), (B, n, n))
        vmax = np.broadcast_to(T.qd_max, (B, n))
        if self.inequality:
            lo, hi = q - (T.q_min + T.h_safe), (T.q_max - T.h_safe) - q
            A = np.concatenate([-I, I, I, -I], 1)
            d = np.concatenate([self.gamma * lo, self.gamma * hi, vmax, vmax], 1)
        else:
            A = np.concatenate([I, -I], 1)
            d = np.concatenate([vmax, vmax], 1)
        Wm = T.mass(q, K) if self.metric == "M" else np.eye(n)
        eq_soft = np.array([False] * Jp.shape[1] + ([] if vr is None else [True] * vr[1].shape[1]))
        return self._project(v, Wm, E, np.zeros((B, E.shape[1])), A, d,
                             soft=np.ones(A.shape[1], dtype=bool), eq_soft=eq_soft)

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        T, K_, H, n, dt = self.task, self.K, self.H, self.n, self.dt
        eps = self.sigma * self.rng.standard_normal((K_, H, n))
        q = np.repeat(q0[None], K_, 0)
        S = np.zeros(K_)
        Up = np.empty((K_, H, n))
        for t in range(H):
            u = self._pi(q, self.U[t][None] + eps[:, t])
            q = q + dt * u
            Up[:, t] = u
            S += T.run_cost(q, u, None, t) * dt
        S += T.term_cost(q, np.zeros_like(q))
        w = _weights(S, self.eta)
        Us = np.einsum("k,kti->ti", w, Up)
        qe = q0[None].copy()
        Uf = np.empty_like(Us)
        for t in range(H):  # execution filtering (PR-MPPI Eq. 13)
            Uf[t] = self._pi(qe, Us[t][None])[0]
            qe = qe + dt * Uf[t][None]
        q_plus = q0 + dt * Uf[0]
        if self.retract_mode != "none":
            q_plus = self.retract(q_plus, q0)
        self.U = np.concatenate([Uf[1:], np.zeros((1, n))], 0)  # warm start as PR-MPPI Alg. 1 line 23
        self.stats["time"].append(time.perf_counter() - t0)
        return {"q_plus": q_plus, "u": Uf[0]}

    def retract(self, q, q_meas, tol=1e-12, iters=40):
        """Gauss-Newton (Eq. 15) onto {c_p = target, e_v = 0}; target 0, or c_p(q_meas) if anchored."""
        T = self.task
        target = 0.0
        if self.retract_mode == "anchored":
            target = T.phys(T.kin(q_meas[None], np.zeros((1, self.n))))[0][0]
        q = q.copy()
        for _ in range(iters):
            K = T.kin(q[None], np.zeros((1, self.n)))
            c, Jp, _ = T.phys(K)
            vr = T.virt(K)
            g = c[0] - target if vr is None else np.concatenate([c[0] - target, vr[0][0]])
            if np.linalg.norm(g) < tol:
                break
            J = Jp[0] if vr is None else np.concatenate([Jp[0], vr[1][0]], 0)
            if self.retract_metric == "M":  # W-weighted Gauss-Newton step, W = M (dynamically consistent)
                WiJt = np.linalg.solve(T.mass(q[None], K)[0], J.T)
                q = q - WiJt @ np.linalg.solve(J @ WiJt, g)
            else:
                q = q - J.T @ np.linalg.solve(J @ J.T, g)
        return q


class CAMP2(_Core):
    """Order 2 (CAMP-MPPI / unified).  Gauss dynamics for the physical rows, reaction box,
    HOCBF joint limits + velocity limits, virtual rows "hard" (stabilised), "soft" or "none",
    solver "separable" (W = M, Thm. 1) or "joint".
    average "projected": execute the average of the projected samples (CAMP-MPPI); "raw": average the raw
    inputs and project the executed command once at the measured state (Algorithm 1).  noise_clip truncates
    the exploration noise at that many standard deviations (bounded inputs, Thm. 2(vi))."""

    def __init__(self, task, sigma=0.8, k1=4.0, k2=4.0, metric="M", solver="separable", virtual="hard",
                 KP=100.0, KD=20.0, w_o=5e3, average="projected", noise_clip=None, eps_motion=0.0,
                 reaction="clamped", **kw):
        super().__init__(task, **kw)
        self.average, self.noise_clip, self.reaction = average, noise_clip, reaction
        self.eps_motion = eps_motion  # tightening of the joint-acceleration rows by an execution-error bound
        self.sigma, self.k1, self.k2 = sigma, k1, k2
        self.metric, self.solver, self.virtual = metric, solver, virtual
        self.KP, self.KD, self.w_o = KP, KD, w_o

    def _model(self, q, qd):
        T = self.task
        K = T.kin(q, qd)
        M = T.mass(q, K)
        Mi = np.linalg.inv(M)
        B = q.shape[0]
        ph = T.phys(K)
        if ph is None:  # no physical rows: the command acts on the free dynamics
            Jp, jpd = np.zeros((B, 0, self.n)), np.zeros((B, 0))
            Lam, MiJt = np.zeros((B, 0, 0)), np.zeros((B, self.n, 0))
            F, f = np.broadcast_to(np.eye(self.n), (B, self.n, self.n)).copy(), np.zeros((B, self.n))
        else:
            _, Jp, jpd = ph
            Lam = np.linalg.inv(Jp @ Mi @ np.swapaxes(Jp, 1, 2))
            MiJt = Mi @ np.swapaxes(Jp, 1, 2)
            F = np.eye(self.n) - MiJt @ Lam @ Jp
            f = -mv(MiJt @ Lam, jpd)
        vr = T.virt(K) if self.virtual != "none" else None
        ex = T.extra_rows(K, q, qd) if hasattr(T, "extra_rows") else None  # hard rows  C qdd <= d
        return dict(K=K, M=M, Mi=Mi, Jp=Jp, jpd=jpd, Lam=Lam, MiJt=MiJt, F=F, f=f, vr=vr, ex=ex)

    def _rows(self, q, qd, f):
        T = self.task
        lo, hi = q - (T.q_min + T.h_safe), (T.q_max - T.h_safe) - q
        s, p = self.k1 + self.k2, self.k1 * self.k2
        d_lo = np.minimum(f + s * qd + p * lo, (T.qd_max + qd) / self.dt + f)
        d_hi = np.minimum(-f - s * qd + p * hi, (T.qd_max - qd) / self.dt - f)
        # rows -+qdd_j <= d have unit normals, so the tightening of Prop. tighten is eps itself
        return d_lo - self.eps_motion, d_hi - self.eps_motion

    def lam_of(self, a, mdl):
        if mdl["Jp"].shape[1] == 0:
            return np.zeros((a.shape[0], 0))
        return -mv(mdl["Lam"], mv(mdl["Jp"], a) + mdl["jpd"])

    def _pi(self, q, qd, a_raw, mdl):
        T = self.task
        B, n = q.shape
        F, f, M, Jp, Lam = mdl["F"], mdl["f"], mdl["M"], mdl["Jp"], mdl["Lam"]
        npr = Jp.shape[1]
        d_lo, d_hi = self._rows(q, qd, f)
        vr = mdl["vr"]
        if vr is not None and self.virtual == "hard":
            e_v, Jv, jvd = vr
            r_v = -self.KD * mv(Jv, qd) - self.KP * e_v
        I = np.broadcast_to(np.eye(n), (B, n, n))
        if self.solver == "separable":
            E, e = Jp, np.zeros((B, npr))
            eq_soft = [False] * npr
            if vr is not None and self.virtual == "hard":
                E = np.concatenate([Jp, Jv], 1)
                e = np.concatenate([e, r_v - mv(Jv, f) - jvd], 1)
                eq_soft += [True] * Jv.shape[1]
            A_x, d_x, soft_x = [-I, I], [d_lo, d_hi], [np.ones(2 * n, dtype=bool)]
            if mdl["ex"] is not None:  # task rows on qdd = x + f, kept hard
                C, dc = mdl["ex"]
                A_x.append(C)
                d_x.append(dc - mv(C, f))
                soft_x.append(np.zeros(C.shape[1], dtype=bool))
            x = self._project(mv(F, a_raw), M, E if E.shape[1] else None, e if E.shape[1] else None,
                              np.concatenate(A_x, 1), np.concatenate(d_x, 1),
                              soft=np.concatenate(soft_x), eq_soft=np.array(eq_soft) if E.shape[1] else None)
            lam = self.lam_of(a_raw, mdl)
            if T.lam_lo is not None:
                Ib = np.broadcast_to(np.eye(npr), (B, npr, npr))
                lam = self._project(lam, np.linalg.inv(Lam), None, None, np.concatenate([Ib, -Ib], 1),
                                    np.concatenate([np.broadcast_to(T.lam_hi, (B, npr)),
                                                    -np.broadcast_to(T.lam_lo, (B, npr))], 1))
            return x - mv(mdl["MiJt"], lam + mv(Lam, mdl["jpd"]))
        # joint composite projection in a
        A = [-F, F]
        dd = [d_lo, d_hi]
        soft = [np.ones(2 * n, dtype=bool)]
        if mdl["ex"] is not None:
            C, dc = mdl["ex"]
            A.append(C @ F)
            dd.append(dc - mv(C, f))
            soft.append(np.zeros(C.shape[1], dtype=bool))
        if T.lam_lo is not None:
            G = Lam @ Jp
            Lj = mv(Lam, mdl["jpd"])
            A += [G, -G]
            dd += [-np.broadcast_to(T.lam_lo, (B, npr)) - Lj, np.broadcast_to(T.lam_hi, (B, npr)) + Lj]
            soft.append(np.zeros(2 * npr, dtype=bool))
        E = e = eq_soft = None
        if vr is not None and self.virtual == "hard":
            E, e = Jv @ F, r_v - mv(Jv, f) - jvd
            eq_soft = np.ones(Jv.shape[1], dtype=bool)
        Wm = M if self.metric == "M" else np.eye(n)
        return self._project(a_raw, Wm, E, e, np.concatenate(A, 1), np.concatenate(dd, 1),
                             soft=np.concatenate(soft), eq_soft=eq_soft)

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        T, K_, H, n, dt = self.task, self.K, self.H, self.n, self.dt
        if getattr(T, "q_ref", 0) is None:  # tasks that take the posture reference from the first state
            T.q_ref = q0.copy()
        if hasattr(T, "t_now"):
            T.t_now = t_now
        z = self.rng.standard_normal((K_, H, n))
        eps = self.sigma * (z if self.noise_clip is None else np.clip(z, -self.noise_clip, self.noise_clip))
        q = np.repeat(q0[None], K_, 0)
        qd = np.repeat(qd0[None], K_, 0)
        S = np.zeros(K_)
        Ap = np.empty((K_, H, n))
        for t in range(H):
            mdl = self._model(q, qd)
            a = self._pi(q, qd, self.U[t][None] + eps[:, t], mdl)
            lam = self.lam_of(a, mdl)
            qd = qd + dt * (mv(mdl["F"], a) + mdl["f"])
            q = q + dt * qd
            Ap[:, t] = a
            run = T.run_cost(q, qd, lam, t)
            if self.virtual == "soft" and mdl["vr"] is not None:
                run = run + self.w_o * np.sum(mdl["vr"][0] ** 2, 1)
            S += run * dt
        S += T.term_cost(q, qd)
        w = _weights(S, self.eta)
        mdl0 = self._model(q0[None], qd0[None])
        if self.average == "raw":  # MPPI update on the raw inputs, one projection of the executed command
            As = self.U + np.einsum("k,kti->ti", w, eps)
            a0 = self._pi(q0[None], qd0[None], As[0][None], mdl0)[0]
        else:
            As = np.einsum("k,kti->ti", w, Ap)
            a0 = As[0]
        self.U = np.concatenate([As[1:], np.zeros((1, n))], 0)
        if self.average == "raw" and self.reaction == "clamped" and mdl0["Jp"].shape[1] and T.lam_lo is not None:
            # separation: motion part from the projection of the raw average, reaction = average of the clamped
            # sample reactions (in the box by convexity); measured-state reaction map for the warm start
            Lam, Jp, jpd, MiJt = mdl0["Lam"][0], mdl0["Jp"][0], mdl0["jpd"][0], mdl0["MiJt"][0]
            lam_of = lambda X: -(X @ Jp.T + jpd) @ Lam.T  # noqa: E731  rows of X are commands
            lam_bar = np.einsum("k,ktj->tj", w, lam_of(Ap))
            a0 = a0 + MiJt @ (lam_of(a0[None])[0] - lam_bar[0])
            tgt = np.concatenate([lam_bar[1:], lam_bar[-1:]], 0)
            self.U = self.U + (lam_of(self.U) - tgt) @ MiJt.T
        self.stats["time"].append(time.perf_counter() - t0)
        return {"a": a0, "lam_cmd": self.lam_of(a0[None], mdl0)[0]}
