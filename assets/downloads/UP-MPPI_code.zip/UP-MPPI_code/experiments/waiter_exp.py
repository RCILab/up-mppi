"""Tier 1(a): certified support-wrench constraints under model uncertainty (waiter task).

True object: 4 cm square base, 24 cm tall, COM height h (0.14 m in the main runs), mass 0.6 kg, friction 0.6;
tipping limit (r/h) g = 1.40 m/s^2 at h = 0.14.
The reference moves 0.4 m in 0.8 s twice (peak 3.6 m/s^2), so the constraints bind.
  nominal   h = 0.07, mu = 0.6          (wrong model: rows admit 2.6 m/s^2)
  robust    h in [0.05, 0.18], mu in [0.4, 0.8]  (vertex rows, admit 1.0 m/s^2)
  adaptive  robust prior, h interval shrunk online by set-membership on (m, m h) from F/T impulses
  adaptive-tracked  same, with the box position on the tray known to 0.2 mm
  oracle    true h and mu
Main runs: h = 0.14, five seeds.  Sweep: h in {0.08, 0.11, 0.17}, three seeds (tracked variant).
"""
import argparse
import json
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import waiter as WT  # noqa: E402
from umppi.generic import CAMP2  # noqa: E402

DT, H, K = 0.02, 20, 256
T_SETTLE, COP_STICK = 0.1, 0.9
N_WIN = 5  # measurement window of five control periods (100 ms): the rocking error of the impulse falls as 1/T_w
TRUE = dict(m=0.6, h=0.14, mu=0.6)
PRIOR_H, PRIOR_MU = (0.05, 0.18), (0.4, 0.8)
Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])
CONTROLLERS = ("nominal", "robust", "adaptive", "oracle")
TRACKED = "adaptive-tracked"  # box position on the tray known to 0.2 mm (main runs only)
COP = "adaptive-cop"  # F/T only, centre-of-pressure differences (no box position needed)
RLS = "adaptive-rls"  # baseline B1: certainty equivalence with a recursive least-squares estimate
RLS_NOM = "adaptive-rls-nom"  # the same, started from the nominal model h = 0.07
D_TRACK, E_TRACK = 0.0005, 0.0002
SWEEP_H = (0.08, 0.11, 0.17)
SWEEP_CONTROLLERS = ("nominal", "robust", TRACKED, COP, "oracle")
ANG = 2 * np.pi * np.arange(WT.N_DIR) / WT.N_DIR
BOUNDS_FILE = Path(__file__).resolve().parent / "results" / "waiter_bounds.json"
# error bounds of the measurement models: calibrated by waiter_calibrate.py in separate runs
# (1.5 x the largest calibration residual); the defaults are the hand-set values
BOUNDS = dict(eps_f=0.2, eps_t=0.005, d_max=0.002, rho_d=0.004, d0=1e-4)
if BOUNDS_FILE.exists():
    BOUNDS.update({k: v for k, v in json.loads(BOUNDS_FILE.read_text())["bounds"].items() if k in BOUNDS})
T_MOVE2 = WT.T0 + WT.T_MOVE + WT.T_HOLD
# execution-error bound of the tray acceleration (period average), calibrated by waiter_baselines.py --calib-exec
EXEC_FILE = Path(__file__).resolve().parent / "results" / "waiter_exec_bound.json"
EPS_EXEC = json.loads(EXEC_FILE.read_text())["eps_exec"] if EXEC_FILE.exists() else 0.0


def default_controller(task):
    """The unified controller (Algorithm 1): GPU rollouts with per-sample projection, raw average, noise
    truncated at 3 sigma, the executed command projected once at the measured state."""
    from umppi.warp_mppi import WarpWaiterMPPI
    return WarpWaiterMPPI(task.chain, task, K=K, H=H, dt=DT, sigma=1.0, average="raw", noise_clip=3.0)


def boxes(name, true):
    return {"nominal": ([0.07], [0.6]), "robust": (list(PRIOR_H), list(PRIOR_MU)),
            "adaptive": (list(PRIOR_H), list(PRIOR_MU)), TRACKED: (list(PRIOR_H), list(PRIOR_MU)),
            COP: (list(PRIOR_H), list(PRIOR_MU)), RLS: (list(PRIOR_H), list(PRIOR_MU)), RLS_NOM: (list(PRIOR_H), list(PRIOR_MU)),
            "oracle": ([true["h"]], [true["mu"]])}[name]


def tray_axes(K):
    n = -K["zt"][0]
    x7 = K["R"][0, -1][:, 0]
    t1 = x7 - (x7 @ n) * n
    t1 = t1 / np.linalg.norm(t1)
    return n, t1, WT.cross(n, t1)


def run(name, seed=0, h_true=TRUE["h"], T=WT.T_RUN, rec=None, noise=(0.1, 0.003), n_win=N_WIN, collect=False,
        controller_factory=None, eps_exec=None):
    true = dict(TRUE, h=h_true)
    if eps_exec is None:  # the unified controller runs with the calibrated tightening
        eps_exec = EPS_EXEC
    chain = WT.make_chain()
    q0 = WT.ik(chain, WT.A_PT, Q_READY)
    phys = WT.WaiterPhysics(chain, q0, **true, noise=noise, rng=np.random.default_rng(1000 + seed))
    h_box, mu_box = boxes(name, true)
    task = WT.WaiterTask(chain, h_box, mu_box, q_ref=q0, dt=DT, H=H, eps_exec=eps_exec)
    ctrl = (default_controller if controller_factory is None else controller_factory)(task)
    ctrl.rng = np.random.default_rng(seed)
    tracked = name == TRACKED
    B = BOUNDS
    est = (WT.SetMembership(h_box=PRIOR_H, eps_f=B["eps_f"], eps_t=B["eps_t"], d_max=D_TRACK if tracked else B["d_max"])
           if name in ("adaptive", TRACKED) else
           WT.COPDifference(h_box=PRIOR_H, eps_f=B["eps_f"], eps_t=B["eps_t"], d0=B["d0"], rho_d=B["rho_d"])
           if name == COP else WT.RLSEstimate(h_box=PRIOR_H) if name == RLS
           else WT.RLSEstimate(h_box=PRIOR_H, h0=0.07) if name == RLS_NOM else None)
    # truth-side checks of the COP measurement model (same pairs as the estimator, true h and d)
    cop_chk = WT.COPDifference(h_box=PRIOR_H, eps_f=B["eps_f"], eps_t=B["eps_t"], d0=B["d0"], rho_d=B["rho_d"])
    chk = dict(res=0.0, creep=0.0)
    cop_buf = []
    # model wrench vs realized wrench (Section on guarantees): largest octagon ratio of the model
    # wrench under the true h, largest true COP ratio of the box, largest tangential deviation
    rig = dict(oct_model=0.0, cop_true=0.0, dev_t=0.0, cop_true_inst=0.0, n_loss=0, dev_t_inst=0.0, dev=0.0, slip_model=0.0)
    rng_tr = np.random.default_rng(2000 + seed)
    ang = rng_tr.uniform(0, 2 * np.pi)
    e_track = E_TRACK * np.array([np.cos(ang), np.sin(ang), 0.0])  # constant error of the box-position estimate
    d_obs = 0.0
    phi_true = true["m"] * true["h"]
    log = dict(t=[], p=[], tgt=[], tilt=[], ah=[], hbox=[], res_f=[], res_t=[], res_t_raw=[], d=[], stick=[])
    win = []  # (YF, YT, S) of the last sticking control periods
    t_tip = None
    t_wall = time.perf_counter()

    for step in range(int(round(T / DT))):
        t = step * DT
        task.t_now = t
        if est is not None:
            task.h_box = est.h
        q_s, qd_s = phys.q, phys.qd
        cmd = ctrl.plan(q_s, qd_s, t)
        K0 = task.kin(q_s[None], qd_s[None])
        v0 = K0["Jv"][0] @ qd_s
        s_cmd = K0["Jv"][0] @ cmd["a"] + K0["jdv"][0] - WT.G  # model acceleration of the tray point
        tilts, meas = phys.step(cmd["a"], DT)
        K1 = task.kin(phys.q[None], phys.qd[None])
        v1 = K1["Jv"][0] @ phys.qd
        # F/T impulse over the period and the tray-point velocity change relative to gravity
        S = v1 - v0 - WT.G * DT
        n_tr, t1, t2 = tray_axes(K1)
        d_now = phys.d.xpos[phys.bid] - phys.d.site_xpos[phys.sid]
        d_now = d_now - (d_now @ n_tr) * n_tr
        d_obs = max(d_obs, float(np.linalg.norm(d_now)))
        if t >= T_SETTLE and t_tip is None and max(tilts) < 2.0:
            n0, u1, u2 = tray_axes(K0)
            sn = float(s_cmd @ n0)
            st = s_cmd - sn * n0
            proj = np.cos(ANG) * (st @ u1) + np.sin(ANG) * (st @ u2)
            rig["oct_model"] = max(rig["oct_model"], true["h"] * float(proj.max()) / (WT.R_BASE * WT.C8 * sn))
            rig["slip_model"] = max(rig["slip_model"], float(proj.max()) / (true["mu"] * WT.C8 * sn))  # slip rows, true mu
            rig["cop_true"] = max(rig["cop_true"], meas["cop_true"])
            ds = S / DT - s_cmd
            rig["dev_t"] = max(rig["dev_t"], float(np.linalg.norm(ds - (ds @ n0) * n0)))
            rig["dev"] = max(rig["dev"], float(np.linalg.norm(ds)))  # period-average execution error of s
            # the same at every 1-ms substep (Proposition tighten (a) needs these, (b) the averages above)
            rig["cop_true_inst"] = max(rig["cop_true_inst"], meas["cop_true_inst"])
            rig["n_loss"] += meas["n_loss"]
            dsi = meas["s_inst"] - s_cmd
            dsi_t = dsi - np.outer(dsi @ n0, n0)
            rig["dev_t_inst"] = max(rig["dev_t_inst"], float(np.max(np.linalg.norm(dsi_t, axis=1))))
        YT_m = meas["YT"] - WT.cross(d_now + e_track, meas["YF"]) if tracked else meas["YT"]
        sticking = t >= T_SETTLE and max(tilts) < 2.0 and meas["cop"] < COP_STICK
        log["d"].append([float(d_now @ t1), float(d_now @ t2)])
        log["stick"].append(bool(sticking))
        win = (win + [(meas["YF"], YT_m, S, d_now, meas["YT"], K0["w"][0].copy(), K1["w"][0].copy())])[-n_win:] if sticking else []
        if len(win) == n_win:
            YF, YT, Sw = (sum(w[i] for w in win) for i in range(3))
            d_win = sum(w[3] for w in win) / n_win
            YT_raw = sum(w[4] for w in win)  # torque about the tray point, as the sensor gives it
            if collect:  # windows for the calibration of the error bounds
                log.setdefault("win", []).append((t, YF, YT_raw, Sw, n_tr, t1, t2, d_win, [w[2] for w in win], win[-1][6] - win[0][5]))
            Tw = n_win * DT
            nS = WT.cross(n_tr, Sw)
            # residuals of the true parameters on the components the estimator uses, as fractions of
            # the bounds the estimator assumes (a value below 1 means the bounded-error model held)
            uf, ut = np.abs(Sw) > 0.5 * Tw, np.abs(nS) > 0.3 * Tw
            sm = est if isinstance(est, WT.SetMembership) else WT.SetMembership(eps_f=B["eps_f"], eps_t=B["eps_t"], d_max=B["d_max"])
            if uf.any():
                log["res_f"].append(float(np.max(np.abs(YF - true["m"] * Sw)[uf])) / (sm.eps_f * Tw))
            if ut.any():
                rt = float(np.max(np.abs(YT - phi_true * nS)[ut]))
                log["res_t"].append(rt / WT.torque_bound(sm.eps_t, true["m"], sm.d_max, Sw, Tw))
                log["res_t_raw"].append(rt / Tw)
            # COP model with the true h and d: residual of every pair and the creep of the box
            m_ = cop_chk.cop(YF, YT_raw, Sw, n_tr, t1, t2, Tw)
            if m_ is not None:
                pc, ec, qv = m_
                dw = np.array([d_win @ t1, d_win @ t2])
                cop_buf = [b for b in cop_buf if t - b[0] <= cop_chk.span]
                for tj, pcj, ecj, qj, dj in cop_buf:
                    dq, dp = qv - qj, pc - pcj
                    cb = cop_chk.d0 + cop_chk.rho_d * (t - tj + Tw)
                    for i in range(2):
                        if abs(dq[i]) >= cop_chk.q_min:
                            chk["res"] = max(chk["res"], abs(dp[i] + true["h"] * dq[i]) / (ec[i] + ecj[i] + cb))
                    chk["creep"] = max(chk["creep"], float(np.max(np.abs(dw - dj))) / cb)
                cop_buf.append((t, pc, ec, qv, dw))
            if isinstance(est, WT.SetMembership):
                est.update(YF, YT, Sw, n_tr, Tw)
            elif est is not None:
                est.update(t, YF, YT_raw, Sw, n_tr, t1, t2, Tw)
        p = chain.tool_pose(phys.q[None])[1][0]
        log["t"].append(t + DT)
        log["p"].append(p)
        log["tgt"].append(WT.target(t + DT)[0])
        log["tilt"].append(max(tilts))
        log["ah"].append(float(np.linalg.norm((S + WT.G * DT)[:2])) / DT)
        log["hbox"].append(list(task.h_box) if len(task.h_box) == 2 else [task.h_box[0], task.h_box[0]])
        if rec is not None:
            rec.setdefault("qpos", []).append(phys.d.qpos.copy())
        if t_tip is None and max(tilts) > 20.0:
            t_tip = t + DT
        if t_tip is not None and t + DT > t_tip + 0.6:
            break
    p, tgt = np.array(log["p"]), np.array(log["tgt"])
    tt = np.array(log["t"])

    def reach_time(goal, t_start):
        idx = np.where((tt > t_start) & (np.linalg.norm(p - goal, axis=1) < 0.01))[0]
        return float(tt[idx[0]] - t_start) if idx.size else None

    def rmse(t_a, t_b):
        sel = (tt > t_a) & (tt <= t_b)
        return 1e3 * float(np.sqrt(np.mean(np.sum((p[sel] - tgt[sel]) ** 2, 1)))) if sel.any() and t_tip is None else None
    hf = log["hbox"][-1]
    res = dict(controller=name, seed=seed, h_true=h_true, tipped=t_tip is not None, t_tip=t_tip,
               max_tilt=float(np.max(log["tilt"])),
               reach1=reach_time(WT.B_PT, WT.T0), reach2=reach_time(WT.A_PT, T_MOVE2),
               rmse1=rmse(0.0, T_MOVE2), rmse2=rmse(T_MOVE2, WT.T_RUN),
               peak_ah=float(np.max(log["ah"])), h_final=hf,
               truth_in_box=bool(hf[0] - 1e-12 <= h_true <= hf[1] + 1e-12),
               ms_per_step=1e3 * float(np.mean(ctrl.stats["time"])),
               relaxed=ctrl.stats["relaxed"], wall_s=time.perf_counter() - t_wall,
               res_f_max=float(np.max(log["res_f"])) if log["res_f"] else None,
               res_t_max=float(np.max(log["res_t"])) if log["res_t"] else None,
               res_t_raw_max=float(np.max(log["res_t_raw"])) if log["res_t_raw"] else None,
               n_invalid=est.n_invalid if est is not None else None,
               m_final=est.m if isinstance(est, WT.SetMembership) else None, box_shift_mm=1e3 * d_obs,
               cop_res_max=chk["res"], cop_creep_max=chk["creep"],
               oct_model_max=rig["oct_model"], cop_true_max=rig["cop_true"], dev_t_max=rig["dev_t"],
               cop_true_inst_max=rig["cop_true_inst"], n_contact_loss=rig["n_loss"], dev_t_inst_max=rig["dev_t_inst"],
               dev_max=rig["dev"], eps_exec=eps_exec, slip_model_max=rig["slip_model"])
    return res, log


def _job(a):
    name, seed, h_true = a
    try:
        r, log = run(name, seed, h_true)
    except Exception as exc:
        return {"controller": name, "seed": seed, "h_true": h_true, "error": repr(exc)}, {}
    return r, {k: np.asarray(v).tolist() for k, v in log.items()}


if __name__ == "__main__":
    import warnings
    warnings.filterwarnings("ignore")
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--sweep-seeds", type=int, default=3)
    ap.add_argument("--procs", type=int, default=24)
    ap.add_argument("--only", default="", help="comma-separated controllers to rerun and merge into waiter.json")
    args = ap.parse_args()
    jobs = [(nm, s, TRUE["h"]) for s in range(args.seeds) for nm in CONTROLLERS + (TRACKED, COP)]
    jobs += [(nm, s, h) for h in SWEEP_H for s in range(args.sweep_seeds) for nm in SWEEP_CONTROLLERS]
    out = Path(__file__).resolve().parent / "results" / "waiter.json"
    rows, logs = [], {}
    if args.only:
        keep = set(args.only.split(","))
        jobs = [j for j in jobs if j[0] in keep]
        old = json.loads(out.read_text())
        rows = [r for r in old["rows"] if r["controller"] not in keep]
        logs = {k: v for k, v in old["logs"].items() if k.split("|")[0] not in keep}
    with Pool(args.procs) as pool:
        for r, lg in pool.imap_unordered(_job, jobs):
            rows.append(r)
            logs[f"{r['controller']}|{r['h_true']}|{r['seed']}"] = lg
            print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}), flush=True)
            out.write_text(json.dumps({"rows": rows, "logs": logs, "true": TRUE, "prior_h": PRIOR_H, "prior_mu": PRIOR_MU,
                                       "bounds": BOUNDS}))
