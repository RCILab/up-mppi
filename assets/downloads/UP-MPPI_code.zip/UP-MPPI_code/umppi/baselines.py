"""Baseline controllers that are not MPPI variants.

OneStepQPWaiter (baseline A3): one-step task-space inverse dynamics, the structure of TSID and
QP whole-body control.  A task-space PD law gives the desired tray acceleration; the joint
acceleration minimises |J a + Jdot qd - a_des|^2 + w_post |a - a_post|_M^2 subject to the same hard
rows as the unified controller (stabilised virtual rows, HOCBF and velocity rows, robust support
rows), solved exactly by the same projector in the metric of the objective.  No horizon.
"""
import time

import numpy as np

from . import waiter as WT
from . import writing as W_
from .qp import project


class OneStepQPWriting:
    """Baseline A3 on the writing task: one-step inverse dynamics with the contact in the Gauss dynamics.

    The joint acceleration command a minimises
        w_t |P_t (J (F a + f) + Jdot qd - a_des)|^2 + w_l (lambda(a) - lambda_nom)^2 + w_post |a - a_post|_M^2,
    with P_t the tangent projector at the contact and a_des a task-space PD law on the path, subject to
    the reaction band (hard), the HOCBF and velocity rows and the stabilised pen-axis rows, all in a."""

    def __init__(self, chain, delta=0.0, omega=15.0, w_t=1.0, w_l=1.0, w_post=1e-3, Kq=20.0, Dq=10.0, dt=0.01,
                 k1=4.0, k2=4.0, KP=100.0, KD=20.0, h_safe=0.05):
        from .controllers import CAMPMPPI
        self.chain, self.omega, self.w_t, self.w_l, self.w_post, self.Kq, self.Dq, self.dt = \
            chain, omega, w_t, w_l, w_post, Kq, Dq, dt
        self.h = CAMPMPPI(chain, metric="M", solver="joint", virtual="hard", k1=k1, k2=k2, KP=KP, KD=KD, dt=dt,
                          K=1, H=1, delta=delta, h_safe=h_safe)
        self.q_ref, self.rng = None, None
        self.stats = {"time": [], "relaxed": 0, "fallback": 0, "calls": 0}

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        if self.q_ref is None:
            self.q_ref = q0.copy()
        q, qd = q0[None], qd0[None]
        mdl = self.h._model(q, qd)
        k = mdl["k"]
        F, f, M, Lam, Jc, jcd = mdl["F"][0], mdl["f"][0], mdl["M"][0], mdl["Lam"][0, 0, 0], mdl["Jc"][0, 0], mdl["jcd"][0, 0]
        Jv, jdv, p, v = k["Jv"][0], k["jdv"][0], k["p"][0], k["pd"][0]
        r = p - W_.C_S
        nh = r / np.linalg.norm(r)
        Pt = np.eye(3) - np.outer(nh, nh)
        hstep = 1e-3
        pr = W_.path_point(np.array([t_now - hstep, t_now, t_now + hstep]))
        v_ref, a_ref = (pr[2] - pr[0]) / (2 * hstep), (pr[2] - 2 * pr[1] + pr[0]) / hstep ** 2
        a_des = a_ref + 2 * self.omega * (v_ref - v) + self.omega ** 2 * (pr[1] - p)
        a_post = -self.Kq * (q0 - self.q_ref) - self.Dq * qd0
        Lm = np.linalg.cholesky(M)
        G = np.concatenate([np.sqrt(self.w_t) * Pt @ Jv @ F, np.sqrt(self.w_l) * (-Lam * Jc)[None],
                            np.sqrt(self.w_post) * Lm.T], 0)
        hv = np.concatenate([np.sqrt(self.w_t) * Pt @ (a_des - jdv - Jv @ f),
                             [np.sqrt(self.w_l) * (W_.LAM_NOM + Lam * jcd)], np.sqrt(self.w_post) * Lm.T @ a_post])
        Hm = G.T @ G
        a_t = np.linalg.solve(Hm, G.T @ hv)
        d_lo, d_hi = self.h._hocbf(q, qd, mdl["f"])
        edot = mdl["Jo"][0] @ qd0
        r_v = -self.h.KD * edot - self.h.KP * mdl["e"][0]
        E = (mdl["Jo"][0] @ F)[None]
        e = (r_v - mdl["Jo"][0] @ f - mdl["jod"][0])[None]
        G0 = Lam * Jc
        LamJcd = Lam * jcd
        lo, hi = W_.LAM_BAND
        A = np.concatenate([-F, F, G0[None], -G0[None]], 0)[None]
        d = np.concatenate([d_lo[0], d_hi[0], [-lo - LamJcd, hi + LamJcd]])[None]
        soft = np.concatenate([np.ones(14, dtype=bool), np.zeros(2, dtype=bool)])
        a, info = project(a_t[None], Hm[None], E, e, A, d, soft=soft, eq_soft=np.ones(2, dtype=bool), return_info=True)
        a = a[0]
        self.stats["relaxed"] += info["relaxed"]
        self.stats["fallback"] += info["fallback"]
        self.stats["calls"] += 1
        self.stats["time"].append(time.perf_counter() - t0)
        return {"a": a, "lam_cmd": float(-Lam * (Jc @ a + jcd))}


class OneStepQPWaiter:
    def __init__(self, task, omega=15.0, w_post=1e-3, Kq=20.0, Dq=10.0, k1=4.0, k2=4.0, KP=100.0, KD=20.0, dt=0.02):
        self.task, self.omega, self.w_post, self.Kq, self.Dq = task, omega, w_post, Kq, Dq
        self.k1, self.k2, self.KP, self.KD, self.dt = k1, k2, KP, KD, dt
        self.rng = None
        self.stats = {"time": [], "relaxed": 0}

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        T = self.task
        q, qd = q0[None], qd0[None]
        K = T.kin(q, qd)
        Jv, jdv, p = K["Jv"][0], K["jdv"][0], K["p"][0]
        v = Jv @ qd0
        t = T.t_now
        a_des = (WT.target_acc(t)[0] + 2 * self.omega * (WT.target_vel(t)[0] - v)
                 + self.omega ** 2 * (WT.target(t)[0] - p))
        M = T.mass(q, K)[0]
        a_post = -self.Kq * (q0 - T.q_ref) - self.Dq * qd0
        Hm = Jv.T @ Jv + self.w_post * M
        g = Jv.T @ (a_des - jdv) + self.w_post * M @ a_post
        a_t = np.linalg.solve(Hm, g)
        # the same hard rows as the unified controller
        e_v, J_v, jvd = T.virt(K)
        r_v = -self.KD * (J_v[0] @ qd0) - self.KP * e_v[0] - jvd[0]
        C, d = T.extra_rows(K, q, qd)
        lo, hi = q0 - (T.q_min + T.h_safe), (T.q_max - T.h_safe) - q0
        s, pg = self.k1 + self.k2, self.k1 * self.k2
        d_lo = np.minimum(s * qd0 + pg * lo, (T.qd_max + qd0) / self.dt)
        d_hi = np.minimum(-s * qd0 + pg * hi, (T.qd_max - qd0) / self.dt)
        n = 7
        A = np.concatenate([C[0], -np.eye(n), np.eye(n)], 0)[None]
        dd = np.concatenate([d[0], d_lo, d_hi])[None]
        soft = np.concatenate([np.zeros(C.shape[1], dtype=bool), np.ones(2 * n, dtype=bool)])
        a, info = project(a_t[None], Hm[None], J_v, r_v[None], A, dd, soft=soft,
                          eq_soft=np.ones(J_v.shape[1], dtype=bool), return_info=True)
        self.stats["relaxed"] += info["relaxed"]
        self.stats["time"].append(time.perf_counter() - t0)
        return {"a": a[0]}
