"""Safe-MPPI baselines from the literature on the waiter task (umppi/safe_mppi.py): Shield-MPPI, DualGuard MPPI and
GS-MPPI, each on the same model, rows, costs, sample count, horizon and clipped noise draws as Algorithm 1, with
the robust (h, mu) prior.  Two conditions: the rows as they are (eps = 0, the model-level statement) and the rows
tightened by the calibrated execution-error bound (the certificate level of Algorithm 1).

--tune   each method's main parameter at h = 0.14 m, 5 seeds (Shield: penalty weight C; GS: soft-min rho)
--sweep  the best value of each method (smallest move-1 error without a tip at h = 0.14 m) at h in {0.08, 0.11,
         0.17} m, 3 seeds
Writes results/safe_baselines_tune.json and results/safe_baselines_sweep.json.
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import waiter_exp as X  # noqa: E402

HERE = Path(__file__).resolve().parent
VARIANTS = [("shield", {"C": 1e2}), ("shield", {"C": 1e3}), ("shield", {"C": 1e4}), ("dualguard", {}),
            ("gs", {"rho": 5.0}), ("gs", {"rho": 20.0}), ("gs", {"rho": 100.0})]
H_SWEEP = (0.08, 0.11, 0.17)
KEYS = ("tipped", "t_tip", "rmse1", "rmse2", "reach1", "reach2", "peak_ah", "oct_model_max", "cop_true_max", "dev_max",
        "ms_per_step", "h_true", "seed")


def label(method, prm):
    return method + "".join(f"@{k}={v:g}" for k, v in prm.items())


def _job(a):
    method, prm, seed, h, eps = a
    import warnings
    warnings.filterwarnings("ignore")
    from umppi.safe_mppi import DualGuardMPPI, GSMPPI, ShieldMPPI
    cls = {"shield": ShieldMPPI, "dualguard": DualGuardMPPI, "gs": GSMPPI}[method]
    fac = lambda task: cls(task, sigma=1.0, dt=X.DT, H=X.H, K=X.K, **prm)  # noqa: E731
    try:
        r, _ = X.run("robust", seed, h, controller_factory=fac, eps_exec=eps)
    except Exception as exc:
        return {"label": label(method, prm), "method": method, "eps": eps, "h_true": h, "seed": seed, "error": repr(exc)}
    out = {k: r[k] for k in KEYS}
    out.update(label=label(method, prm), method=method, params=prm, eps=eps)
    return out


def run_jobs(jobs, out, procs):
    rows = []
    with Pool(procs) as pool:
        for r in pool.imap_unordered(_job, jobs):
            rows.append(r)
            print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}), flush=True)
            out.write_text(json.dumps({"rows": rows}, default=float))
    return rows


def best_variants(rows):
    """Per method and eps, the variant with the smallest mean move-1 error and no tip at h = 0.14 m."""
    import numpy as np
    from collections import defaultdict
    g = defaultdict(list)
    for r in rows:
        if "error" not in r:
            g[(r["method"], r["eps"], r["label"])].append(r)
    best = {}
    for (m, e, lab), rs in g.items():
        if any(r["tipped"] for r in rs):
            continue
        score = float(np.mean([r["rmse1"] for r in rs]))
        if (m, e) not in best or score < best[(m, e)][0]:
            best[(m, e)] = (score, rs[0]["params"])
    return {k: v[1] for k, v in best.items()}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--tune", action="store_true")
    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--gs1", action="store_true", help="GS-MPPI with the single closed-form step of the paper")
    ap.add_argument("--procs", type=int, default=6)
    args = ap.parse_args()
    eps_x = X.EPS_EXEC
    if args.tune:
        jobs = [(m, p, s, 0.14, e) for e in (0.0, eps_x) for m, p in VARIANTS for s in range(5)]
        run_jobs(jobs, HERE / "results" / "safe_baselines_tune.json", args.procs)
    if args.gs1:  # the paper applies the safe law once; the composite of input rows is not affine, so it may fall short
        jobs = [("gs", {"rho": r, "iters": 1}, s, 0.14, e) for e in (0.0, eps_x) for r in (20.0, 100.0) for s in range(5)]
        jobs += [("gs", {"rho": 20.0, "iters": 1}, s, h, e) for e in (0.0, eps_x) for h in H_SWEEP for s in range(3)]
        run_jobs(jobs, HERE / "results" / "safe_baselines_gs1.json", args.procs)
    if args.sweep:
        tune = json.loads((HERE / "results" / "safe_baselines_tune.json").read_text())["rows"]
        best = best_variants(tune)
        print("best", best, flush=True)
        jobs = [(m, p, s, h, e) for (m, e), p in sorted(best.items()) for h in H_SWEEP for s in range(3)]
        run_jobs(jobs, HERE / "results" / "safe_baselines_sweep.json", args.procs)
