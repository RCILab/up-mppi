"""Waiter results: tables, figure, and the filled LaTeX section (tier2/robust_section.tex)."""
import json
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import waiter as WT  # noqa: E402

HERE = Path(__file__).resolve().parent
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
TR, CP = "adaptive-tracked", "adaptive-cop"
ORDER = ("nominal", "robust", "adaptive", CP, TR, "oracle")
SWEEP_ORDER = ("nominal", "robust", CP, TR, "oracle")
ADAPTIVE = ("adaptive", CP, TR)
# fixed categorical slots (dataviz reference palette); the entity keeps its colour across figures
COL = {"adaptive": "#2a78d6", "nominal": "#eb6834", "robust": "#1baf7a", "oracle": "#eda100", TR: "#e87ba4", CP: "#008300"}
LEG = {"nominal": "nominal ($h$ = 0.07 m)", "robust": "robust", "adaptive": "adaptive, direct F/T",
       CP: "adaptive, COP differences", TR: "adaptive, box tracked", "oracle": "oracle"}
LAB = {"nominal": "Nominal ($h=0.07$\\,m)", "robust": "Robust", "adaptive": "Adaptive, direct F/T",
       CP: "Adaptive, COP differences", TR: "Adaptive, box tracked", "oracle": "Oracle"}
H_MAIN = 0.14
LS = {nm: "-" for nm in ORDER}
LS["adaptive"] = (0, (3, 1.5))  # dashed: it nearly coincides with the robust curve
LS[CP] = (0, (5, 1.5, 1, 1.5))  # dash-dot: secondary encoding against the aqua robust curve
ZO = {nm: 2 for nm in ORDER}
ZO["adaptive"] = 3
MARGIN = lambda h: (1 - WT.C8) * WT.R_BASE * 9.81 / h  # noqa: E731  tangential deviation the octagon absorbs


def style(ax):
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(INK2)
        ax.spines[s].set_linewidth(0.6)
    ax.tick_params(colors=INK2, labelsize=7.5, width=0.6)


def mean_or_dash(vals, fmt="{:.2f}"):
    """Mean over the runs that have the value; an asterisk marks a mean over a subset."""
    v = [x for x in vals if x is not None]
    if not v:
        return "--"
    s = fmt.format(np.mean(v))
    return s if len(v) == len(vals) else s + "$^\\ast$"


def avg(v):
    v = [x for x in v if x is not None]
    return float(np.mean(v)) if v else float("nan")


def main():
    D = json.loads((HERE / "results/waiter.json").read_text())
    rows = [r for r in D["rows"] if "error" not in r]
    errors = [r for r in D["rows"] if "error" in r]
    g = defaultdict(list)
    for r in rows:
        g[(r["controller"], round(r["h_true"], 3))].append(r)
    hs = sorted({round(r["h_true"], 3) for r in rows})
    EXB = json.loads((HERE / "results/waiter_exec_bound.json").read_text())
    EPS = EXB["eps_exec"]
    rc = WT.R_BASE * WT.C8
    # acceleration the tightened tipping rows admit for COM height h (n.s = g):  (r c g - eps |L|) / h
    lim = lambda h: (rc * 9.81 - EPS * np.hypot(h, rc)) / h  # noqa: E731
    # ------------------------------------------------------------ main table (h = 0.14)
    n_main = len(g[("robust", H_MAIN)])
    t1 = ["\\begin{table}[h]", "\\centering",
          f"\\caption{{Waiter task with the true $h={H_MAIN}$\\,m, over {n_main} seeds: tipped runs, tracking error of each move (safe runs), time to come within 1\\,cm of each goal after the move starts, peak horizontal tray acceleration, and the interval of $h$ used by the rows at the end (union over seeds).}}",
          "\\label{tab:waiter}", "\\footnotesize", "\\begin{tabularx}{\\linewidth}{l Y Y Y Y Y Y c}", "\\toprule",
          "Controller & Tipped & \\multicolumn{2}{c}{RMSE [mm]} & \\multicolumn{2}{c}{Reach [s]} & Peak $|a_h|$ & Final $h$ \\\\",
          "\\cmidrule(lr){3-4}\\cmidrule(lr){5-6}",
          " & & move 1 & move 2 & move 1 & move 2 & [m/s$^2$] & [m] \\\\", "\\midrule"]
    S = {}
    for nm in ORDER:
        rs = g[(nm, H_MAIN)]
        if not rs:
            continue
        hf = np.array([r["h_final"] for r in rs])
        S[nm] = dict(n=len(rs), tipped=sum(r["tipped"] for r in rs), t_tip=[r["t_tip"] for r in rs if r["tipped"]],
                     rmse1=[r["rmse1"] for r in rs], rmse2=[r["rmse2"] for r in rs],
                     reach1=[None if r["tipped"] else r["reach1"] for r in rs],
                     reach2=[None if r["tipped"] else r["reach2"] for r in rs],
                     peak=[r["peak_ah"] for r in rs], h_lo=hf[:, 0].tolist(), h_hi=hf[:, 1].tolist(),
                     truth=[r["truth_in_box"] for r in rs], max_tilt=[r["max_tilt"] for r in rs])
        hstr = f"{hf[0, 0]:.2f}" if np.allclose(hf[:, 0], hf[:, 1]) else f"{hf[:, 0].min():.3f}--{hf[:, 1].max():.3f}"
        t1.append(f"{LAB[nm]} & {S[nm]['tipped']}/{len(rs)} & {mean_or_dash(S[nm]['rmse1'], '{:.1f}')} & {mean_or_dash(S[nm]['rmse2'], '{:.1f}')} & "
                  f"{mean_or_dash(S[nm]['reach1'])} & {mean_or_dash(S[nm]['reach2'])} & {np.mean(S[nm]['peak']):.2f} & {hstr} \\\\")
    t1 += ["\\bottomrule", "\\end{tabularx}", "\\end{table}"]
    # ------------------------------------------------------------ sweep table
    t2 = ["\\begin{table}[h]", "\\centering",
          "\\caption{Sweep over the true centre-of-mass height, all inside the prior interval $[0.05,0.18]$\\,m: tipped runs and the tracking error of move~2 [mm] over the safe runs. The last row is the acceleration that the rows of the oracle admit.}",
          "\\label{tab:waiter_sweep}", "\\footnotesize", "\\begin{tabularx}{\\linewidth}{l " + "Y " * len(hs) + "}", "\\toprule",
          "Controller & " + " & ".join(f"$h={h:.2f}$\\,m" for h in hs) + " \\\\", "\\midrule"]
    SW = {}
    for nm in SWEEP_ORDER:
        cells = []
        for h in hs:
            rs = g[(nm, h)]
            tip = sum(r["tipped"] for r in rs)
            r2 = [r["rmse2"] for r in rs if r["rmse2"] is not None]
            SW[(nm, h)] = dict(n=len(rs), tipped=tip, rmse2=float(np.mean(r2)) if r2 else None,
                               truth=all(r["truth_in_box"] for r in rs))
            cells.append(f"{tip}/{len(rs)}" + (f", {np.mean(r2):.1f}" if r2 else ""))
        t2.append(f"{LAB[nm]} & " + " & ".join(cells) + " \\\\")
    t2.append("\\midrule")
    t2.append("Oracle rows admit [m/s$^2$] & " + " & ".join(f"{lim(h):.2f}" for h in hs) + " \\\\")
    t2 += ["\\bottomrule", "\\end{tabularx}", "\\end{table}"]
    # ------------------------------------------------------------ figure
    plt.rcParams.update({"font.size": 8, "font.family": "serif", "mathtext.fontset": "cm"})
    fig, (a, b) = plt.subplots(1, 2, figsize=(6.6, 2.6), gridspec_kw={"width_ratios": [1.3, 1.0]})
    for t0 in (WT.T0, WT.T0 + WT.T_MOVE + WT.T_HOLD):  # the two moves of the reference
        a.axvspan(t0, t0 + WT.T_MOVE, color=GRID, alpha=0.6, lw=0)
    for nm in ORDER:
        lg = D["logs"].get(f"{nm}|{H_MAIN}|0")
        if not lg:
            continue
        t, p, tg = np.array(lg["t"]), np.array(lg["p"]), np.array(lg["tgt"])
        e = 1e3 * np.linalg.norm(p - tg, axis=1)
        r0 = next(r for r in g[(nm, H_MAIN)] if r["seed"] == 0)
        if r0["tipped"]:  # draw only until the box tipped
            k = int(np.argmin(np.abs(t - r0["t_tip"])))
            a.plot(t[:k + 1], e[:k + 1], color=COL[nm], lw=1.3)
            a.plot(t[k], e[k], "x", color=COL[nm], ms=8, mew=2, zorder=5)
            a.annotate("tipped", (t[k], e[k]), xytext=(5, 4), textcoords="offset points", fontsize=7, color=INK2)
        else:
            a.plot(t, e, color=COL[nm], lw=1.3, ls=LS[nm], zorder=ZO[nm])
    a.set_xlabel("time [s]")
    a.set_ylabel("distance to reference [mm]")
    a.set_title("(a) tracking error (grey: reference moves)", fontsize=8, loc="left", color=INK)
    style(a)
    b.axhspan(D["prior_h"][0], D["prior_h"][1], color=COL["robust"], alpha=0.10, lw=0)
    for nm in ADAPTIVE:
        lg = D["logs"].get(f"{nm}|{H_MAIN}|0")
        if not lg:
            continue
        t, hb = np.array(lg["t"]), np.array(lg["hbox"])
        if nm != "adaptive":  # bands for the two informative variants, lines only for the direct one
            b.fill_between(t, hb[:, 0], hb[:, 1], color=COL[nm], alpha=0.18, lw=0)
        b.plot(t, hb[:, 0], color=COL[nm], lw=1.2, ls=LS[nm])
        b.plot(t, hb[:, 1], color=COL[nm], lw=1.2, ls=LS[nm])
    b.axhline(H_MAIN, color=INK, lw=1.0, ls=(0, (4, 2)))
    b.text(WT.T_RUN * 0.98, H_MAIN + 0.002, "true $h$", ha="right", va="bottom", fontsize=7, color=INK2)
    b.text(WT.T_RUN * 0.98, D["prior_h"][1] - 0.003, "prior (robust)", ha="right", va="top", fontsize=7, color=INK2)
    b.set_xlabel("time [s]")
    b.set_ylabel("interval of $h$ in the rows [m]")
    b.set_ylim(0.04, 0.19)
    b.set_title("(b) certified interval of $h$, seed 0", fontsize=8, loc="left", color=INK)
    style(b)
    handles = [plt.Line2D([], [], color=COL[nm], lw=1.4, ls=LS[nm]) for nm in ORDER] + [plt.Line2D([], [], color=INK, lw=1.0, ls=(0, (4, 2)))]
    fig.legend(handles, [LEG[nm] for nm in ORDER] + ["true $h$"], loc="upper center", ncol=4, frameon=False,
               fontsize=6.8, bbox_to_anchor=(0.5, 1.10), labelcolor=INK, handlelength=2.2, columnspacing=1.2)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    out = HERE.parent / "tier2" / "figs"
    out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / "waiter.pdf", bbox_inches="tight")
    fig.savefig(out / "waiter.png", dpi=200, bbox_inches="tight")
    # ------------------------------------------------------------ findings
    nom, rob, ada, cop, trk, orc = (S[k] for k in ORDER)
    nom_sweep = ", ".join(f"{SW[('nominal', h)]['tipped']}/{SW[('nominal', h)]['n']} at $h={h:.2f}$" for h in hs if h != H_MAIN)
    safe_ctrl = ("robust",) + ADAPTIVE + ("oracle",)
    safe_rows = [r for r in rows if r["controller"] in safe_ctrl]
    n_safe, tip_safe = len(safe_rows), sum(r["tipped"] for r in safe_rows)
    ada_rows = [r for r in rows if r["controller"] in ADAPTIVE]
    truth_all = all(r["truth_in_box"] for r in ada_rows)
    n_inv = sum(r["n_invalid"] or 0 for r in ada_rows)
    # bounded-error checks over the runs whose estimators use the calibrated bounds
    res_f = max(r["res_f_max"] for r in ada_rows if r["res_f_max"] is not None)
    res_t = max(r["res_t_max"] for r in ada_rows if r["res_t_max"] is not None and r["controller"] != CP)
    cop_res = max(r["cop_res_max"] for r in ada_rows if r["controller"] == CP)
    cop_creep = max(r["cop_creep_max"] for r in ada_rows if r["controller"] == CP)
    shift = max(r["box_shift_mm"] for r in ada_rows)
    CAL = json.loads((HERE / "results/waiter_bounds.json").read_text())
    BND = CAL["bounds"]
    # certificate and its margin, over the certified runs
    oct_cert = max(r["oct_model_max"] for r in safe_rows)
    cop_true = max(r["cop_true_max"] for r in safe_rows)
    dev_all = max(r["dev_max"] for r in safe_rows)  # period-average execution error of s, all certified runs
    oct_nom = min(r["oct_model_max"] for r in rows if r["controller"] == "nominal" and r["tipped"]) if nom["tipped"] else float("nan")
    # the same at 1-ms resolution (Proposition tighten (a)); older result files lack these fields
    has_inst = all("dev_t_inst_max" in r for r in safe_rows)
    diag_file = HERE / "results/waiter_inst_diag.json"
    DIAG = json.loads(diag_file.read_text()) if diag_file.exists() else None
    if has_inst:
        dev_inst_ratio = max(r["dev_t_inst_max"] / MARGIN(r["h_true"]) for r in safe_rows)
        dev_inst_main = max(r["dev_t_inst_max"] for r in safe_rows if round(r["h_true"], 3) == H_MAIN)
        cop_inst = max(r["cop_true_inst_max"] for r in safe_rows)
        n_loss = sum(r["n_contact_loss"] for r in safe_rows)
        n_edge = sum(r["cop_true_inst_max"] >= 0.999 for r in safe_rows)
    gap = lambda x: avg(x["rmse2"]) - avg(orc["rmse2"])  # noqa: E731
    close = lambda x: 100 * (1 - gap(x) / gap(rob)) if gap(rob) > 0 else float("nan")  # noqa: E731

    def sweep_close(h, nm):
        r_, t_, o_ = (SW[(k, h)]["rmse2"] for k in ("robust", nm, "oracle"))
        return max(0.0, 100 * (r_ - t_) / (r_ - o_)) if r_ - o_ > 1e-9 else float("nan")

    def sweep_list(nm):
        return ", ".join(f"{sweep_close(h, nm):.0f}" for h in hs)
    fnd = ["\\paragraph{Findings.}", "\\begin{enumerate}",
           f"\\item The nominal model tipped the box in {nom['tipped']} of {nom['n']} runs at $h={H_MAIN}$\\,m"
           + (f", {avg(nom['t_tip']) - WT.T0:.2f}\\,s into the first move on average" if nom["t_tip"] else "")
           + f", and in {nom_sweep} of the sweep.",
           f"Its peak horizontal acceleration of {avg(nom['peak']):.2f}\\,m/s$^2$ is admissible for the assumed $h=0.07$\\,m but not for the true box.",
           f"\\item No controller with certified rows tipped the box: {tip_safe} of {n_safe} runs over all heights.",
           "This is consistent with Propositions~\\ref{prop:certificate} and~\\ref{prop:tighten}: the certificate covers the model wrench for any $h$ in the prior interval, and the tightening covered the measured deviation (item~3).",
           f"The price of the robust rows is speed: at $h={H_MAIN}$\\,m they held the peak acceleration to {avg(rob['peak']):.2f}\\,m/s$^2$ and tracked move~2 with {avg(rob['rmse2']):.1f}\\,mm RMSE, against {avg(orc['peak']):.2f}\\,m/s$^2$ and {avg(orc['rmse2']):.1f}\\,mm for the oracle.",
           f"\\item What the certified runs verify, level by level (Propositions~\\ref{{prop:certificate}} and~\\ref{{prop:tighten}}).",
           f"At the sampling instants the model wrench under the true $h$ used at most {100 * oct_cert:.0f}\\% of the octagon: the certificate.",
           f"Averaged over each 20\\,ms period, the realized tray acceleration deviated from the model by at most {dev_all:.3f}\\,m/s$^2$ over all certified runs, {100 * dev_all / EPS:.0f}\\% of the calibrated $\\varepsilon$, and the period-averaged centre of pressure stayed within {100 * cop_true:.0f}\\% of the edge of the base: the hypothesis and the conclusion of Proposition~\\ref{{prop:tighten}}(b) hold.",
           (f"At the 1\\,ms resolution of the simulation the hypothesis of~(a) does not: in a diagnostic run of the oracle at $h={H_MAIN}$\\,m, the deviation exceeded $\\varepsilon$ in {100 * DIAG['eps_frac_above']:.1f}\\% of the settled substeps (99th percentile {DIAG['eps_p99']:.2f} and maximum {DIAG['eps_max']:.2f} times $\\varepsilon$), and the instantaneous centre of pressure touched an edge in {100 * DIAG['frac_periods_edge']:.0f}\\% of the control periods; in the sweep it touched an edge in some substep of {n_edge} of {n_safe} certified runs."
            if has_inst and DIAG and "eps_frac_above" in DIAG else "The pointwise statement~(a) was not checked in these runs."),
           "The pointwise statement~(a) is therefore not verified with this bound.",
           f"The box rocked momentarily in those substeps but never tipped; the nominal model's wrench under the true $h$ reached {oct_nom:.2f} times the octagon before its box tipped.",
           f"\\item The interval of $h$ contained the true value in {'every' if truth_all else 'not every'} adaptive run, and no measurement contradicted the bounds ({n_inv} rejections), as Proposition~\\ref{{prop:setmember}} states.",
           f"How far it shrinks is set by the measurement model.",
           f"The direct model ended at $[{min(ada['h_lo']):.3f},{max(ada['h_hi']):.3f}]$\\,m and closed {close(ada):.0f}\\% of the move-2 tracking gap between the robust controller and the oracle, because the unknown position of the box dominates its torque bound.",
           f"COP differences cancel that position and, with the same sensor, ended at $[{min(cop['h_lo']):.3f},{max(cop['h_hi']):.3f}]$\\,m and closed {close(cop):.0f}\\%.",
           f"With the box tracked the interval ended at $[{min(trk['h_lo']):.3f},{max(trk['h_hi']):.3f}]$\\,m and closed {close(trk):.0f}\\%.",
           "\\item Across the sweep, at $h=" + ", ".join(f"{h:.2f}" for h in hs) + f"$\\,m, COP differences closed {sweep_list(CP)}\\% of that gap and the tracked variant {sweep_list(TR)}\\%.",
           "The gain is largest when the true box is far from the conservative end of the prior, and vanishes near that end, where the robust rows are already almost exact.",
           f"\\item The calibrated bounds held in every adaptive run.",
           f"The residuals of the true parameters reached at most {100 * res_f:.0f}\\% of the force bound and {100 * res_t:.0f}\\% of the torque bound of the direct model, and {100 * cop_res:.0f}\\% of the bound of the COP differences.",
           f"The box shifted on the tray by at most {shift:.2f}\\,mm, inside $\\bar d={1e3 * BND['d_max']:.1f}$\\,mm, and its creep between paired windows used at most {100 * cop_creep:.0f}\\% of the creep bound.",
           "\\end{enumerate}"]
    if errors:
        fnd.insert(-1, f"\\item {len(errors)} runs raised an exception and are excluded.")
    tpl = (HERE / "robust_section.tex.in").read_text(encoding="utf-8")
    body = ("\n".join(t1) + "\n\n" + "\n".join(t2) + "\n\n\\begin{figure}[h]\n\\centering\n\\includegraphics[width=\\linewidth]{figs/waiter.pdf}\n"
            "\\caption{Waiter task at $h=0.14$\\,m, seed~0. (a) Distance of the tray point to the reference; a cross marks the moment the nominal controller tipped the box, and the direct adaptive controller (dashed) nearly coincides with the robust one. "
            "(b) The interval of the centre-of-mass height used by the rows of the three adaptive controllers, inside the prior interval of the robust controller, against the true value.}\n"
            "\\label{fig:waiter}\n\\end{figure}\n\n" + "\n".join(fnd))
    fill = {"@@EPS_F@@": f"{BND['eps_f']:.3f}", "@@EPS_T@@": f"{1e3 * BND['eps_t']:.1f}", "@@DMAX@@": f"{1e3 * BND['d_max']:.1f}",
            "@@RHO@@": f"{1e3 * BND['rho_d']:.1f}", "@@ET_CAL@@": f"{1e3 * CAL['worst']['e_t']:.1f}",
            "@@SHIFT_CAL@@": f"{1e3 * CAL['worst']['d']:.1f}", "@@EPS_X@@": f"{EPS:.3f}", "@@DEV_CAL@@": f"{EXB['dev_max']:.3f}",
            "@@A_NOM@@": f"{lim(0.07):.1f}", "@@A_ROB@@": f"{lim(max(D['prior_h'])):.2f}", "@@A_ORC@@": f"{lim(H_MAIN):.2f}",
            "@@ET40@@": (f"{1e3 * json.loads((HERE / 'results/waiter_bounds_w40.json').read_text())['worst']['e_t']:.1f}"
                         if (HERE / "results/waiter_bounds_w40.json").exists() else "8.0")}
    for k_, v_ in fill.items():
        tpl = tpl.replace(k_, v_)
    (HERE.parent / "tier2" / "robust_section.tex").write_text(tpl.replace("@@RESULTS@@", body), encoding="utf-8")
    (HERE / "results/waiter_summary.json").write_text(json.dumps(
        {"main": S, "sweep": {f"{k[0]}|{k[1]}": v for k, v in SW.items()}, "res_f_ratio": res_f, "res_t_ratio": res_t,
         "box_shift_mm": shift, "n_invalid": n_inv, "truth_all": truth_all, "errors": len(errors),
         "gap_closed_pct": {"adaptive": close(ada), CP: close(cop), TR: close(trk)},
         "sweep_gap_closed_pct": {nm: {h: sweep_close(h, nm) for h in hs} for nm in (CP, TR)},
         "certificate": {"oct_model_max": oct_cert, "cop_true_max": cop_true, "dev_max": dev_all, "eps_exec": EPS,
                         "oct_nominal_min": oct_nom},
         "cop_res": cop_res, "cop_creep": cop_creep}, indent=1, default=float))
    for nm in ORDER:
        v = S[nm]
        print(f"{nm:17s} tipped {v['tipped']}/{v['n']}  rmse1 {avg(v['rmse1']):6.1f}  rmse2 {avg(v['rmse2']):6.1f}  "
              f"reach {avg(v['reach1']):.2f}/{avg(v['reach2']):.2f}  peak {avg(v['peak']):.2f}  h [{min(v['h_lo']):.3f},{max(v['h_hi']):.3f}]")
    for h in hs:
        print(h, {nm: (SW[(nm, h)]["tipped"], SW[(nm, h)]["n"], SW[(nm, h)]["rmse2"] and round(SW[(nm, h)]["rmse2"], 1)) for nm in SWEEP_ORDER})
    print("res_f ratio", res_f, "res_t ratio", res_t, "box shift mm", shift, "n_invalid", n_inv, "truth_all", truth_all,
          "gap closed", close(ada), close(cop), close(trk), "errors", len(errors))
    print("certificate: oct", oct_cert, "cop_true", cop_true, "dev", dev_all, "eps", EPS, "oct nominal", oct_nom, "cop res", cop_res, "creep", cop_creep)


if __name__ == "__main__":
    main()
