"""T3b -- finite-step CBF layer at order 1 (Lemma 1 of PR-MPPI) and order 2 (HOCBF, new).

The one-step Taylor error has order-dependent sign:
  order 1, Euler            E_h = +1/2 dt^2 u^T Hess(h) u            -> adverse on CONCAVE h
  order 2, semi-implicit    E_h = dt^2 (hdd - 1/2 qd^T Hess(h) qd)   -> adverse on CONVEX h
so each order is tested on its adverse geometry, with the controller sliding along the boundary.
  A   order 1, keep inside a disk (concave)          predicted layer  v^2 dt / (2 R gamma)
  B   order 2, keep outside a disk obstacle (convex)  Lemma 2 bound    (kap_h + kap_psi/k2) dt / k1
  B+  order 2 on the concave disk: favourable sign, margin stays positive (info)
  C   order 2 on the unit sphere (physical equality, Gauss dynamics), ZOH command held
      over dt, exact fine-step physics, braking along a latitude boundary
Fixed gains -> O(dt) layer; fixed per-step gains (k dt const) -> O(dt^2) (Euler-type
rollout models); exact ZOH physics can only be better (C).
"""
import numpy as np

from common import Report, loglog_slope

V0 = 1.0
DTS = np.array([0.02, 0.01, 0.005, 0.0025, 0.00125])
T_SIM = 6.0


def unit(v):
    return v / np.linalg.norm(v)


# --------------------------------------------------------------------------- A
def run_order1(dt, gamma, R=1.0, vout=0.5):
    q = np.array([0.5, 0.0])
    hs, vmax = [], 0.0
    for _ in range(int(T_SIM / dt)):
        rh = unit(q)
        th = np.array([-rh[1], rh[0]])
        u = V0 * th + vout * rh
        h = R - np.linalg.norm(q)
        excess = rh @ u - gamma * h  # grad h^T u >= -gamma h  <=>  rh^T u <= gamma h
        if excess > 0:
            u = u - excess * rh
        vmax = max(vmax, np.linalg.norm(u))
        q = q + dt * u
        hs.append(R - np.linalg.norm(q))
    hs = np.array(hs)
    return hs[len(hs) // 2:].min(), vmax


# --------------------------------------------------------------------------- B
def run_order2(dt, k1, k2, convex=True, R=0.5, Kv=5.0, vin=0.5):
    """Point mass, semi-implicit Euler, HOCBF.  convex: stay OUTSIDE radius R; else INSIDE."""
    q = np.array([R + 0.3, 0.0]) if convex else np.array([0.5 * R, 0.0])
    qd = np.zeros(2)
    s = 1.0 if convex else -1.0  # h = s (rho - R)
    hs, vmax, amax = [], 0.0, 0.0
    for _ in range(int(T_SIM / dt)):
        rho = np.linalg.norm(q)
        rh = q / rho
        th = np.array([-rh[1], rh[0]])
        a = Kv * (V0 * th - s * vin * rh - qd)  # circulate and push into the boundary
        h = s * (rho - R)
        g = s * rh  # grad h
        hdd_drift = s * (qd @ qd - (rh @ qd) ** 2) / rho  # qd^T Hess(h) qd
        beta = -hdd_drift - (k1 + k2) * (g @ qd) - k1 * k2 * h  # HOCBF <=> g^T a >= beta
        if g @ a < beta:
            a = a + (beta - g @ a) * g
        qd = qd + dt * a
        q = q + dt * qd
        vmax, amax = max(vmax, np.linalg.norm(qd)), max(amax, np.linalg.norm(a))
        hs.append(s * (np.linalg.norm(q) - R))
    hs = np.array(hs)
    return hs[len(hs) // 2:].min(), vmax, amax


def lemma2_layer(dt, k1, k2, vbar, abar, rho_min):
    L1, L2, L3 = 1.0, 1.0 / rho_min, 3.0 / rho_min ** 2
    kh = 0.5 * L2 * vbar ** 2 + L1 * abar
    kpsi = 2 * L2 * abar * vbar + dt * L2 * abar ** 2 + 0.5 * L3 * vbar ** 3 + k1 * kh
    return (kh + kpsi / k2) * dt / k1


# --------------------------------------------------------------------------- C
ZMAX = 0.5
EZ = np.array([0.0, 0.0, 1.0])


def sphere_acc(q, qd, a):
    N = np.eye(3) - np.outer(q, q) / (q @ q)
    return N @ a - q * (qd @ qd) / (q @ q)  # Gauss dynamics, M = I, c = (|q|^2 - 1)/2


def physics_step(q, qd, a, dt, sub=40):
    hh = dt / sub
    for _ in range(sub):  # RK4 on the constrained ODE, then project (physics stays on TS^2)
        def f(x):
            return np.concatenate([x[3:], sphere_acc(x[:3], x[3:], a)])
        x = np.concatenate([q, qd])
        k1 = f(x)
        k2 = f(x + 0.5 * hh * k1)
        k3 = f(x + 0.5 * hh * k2)
        k4 = f(x + hh * k3)
        x = x + hh / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        q = unit(x[:3])
        qd = x[3:] - q * (q @ x[3:])
    return q, qd


def run_sphere(dt, k1, k2, Kv=5.0, vup=0.5, return_jerk=False):
    q, qd = unit(np.array([1.0, 0.0, 0.45])), np.zeros(3)
    hs, jerks = [], []
    for i in range(int(T_SIM / dt)):
        t = i * dt
        N = np.eye(3) - np.outer(q, q)
        speed = max(2.0 - 0.3 * t, 0.2)  # braking along the boundary
        v_des = speed * unit(np.cross(EZ, q)) + vup * N @ EZ
        a = Kv * (v_des - qd)
        n_vec = N @ EZ
        f = -q * (qd @ qd)
        beta = -(EZ @ f) - (k1 + k2) * qd[2] + k1 * k2 * (ZMAX - q[2])  # HOCBF <=> n^T a <= beta
        if n_vec @ a > beta:
            a = a - (n_vec @ a - beta) * n_vec / (n_vec @ n_vec)
        # barrier jerk at the start of the interval under the held command (Prop. 4(c))
        qdd = sphere_acc(q, qd, a)
        Ndot = -(np.outer(qd, q) + np.outer(q, qd))
        jerk = -(EZ @ (Ndot @ a - qd * (qd @ qd) - 2 * q * (qd @ qdd)))
        jerks.append(jerk)
        q, qd = physics_step(q, qd, a, dt)
        hs.append(ZMAX - q[2])
    hs = np.array(hs)
    s0 = len(hs) // 3
    if return_jerk:
        i = s0 + int(np.argmin(hs[s0:]))
        return hs[i], jerks[i]
    return hs[s0:].min()


def main():
    rep = Report("T3b CBF layer")
    data = {"dts": DTS}

    # A: order 1, concave ------------------------------------------------------
    gamma = 5.0
    out = [run_order1(dt, gamma) for dt in DTS]
    lay = np.array([-o[0] for o in out])
    pred = V0 ** 2 * DTS / (2 * 1.0 * gamma)
    s = loglog_slope(DTS, lay)
    rep.check("A order-1 (concave), fixed gamma: layer slope ~ 1", abs(s - 1) < 0.1, f"slope {s:.2f}")
    rep.check("A order-1: layer matches v^2 dt/(2 R gamma)", np.max(np.abs(lay / pred - 1)) < 0.05,
              f"measured/predicted {np.round(lay / pred, 3)}")
    vmax = max(o[1] for o in out)
    bound = 0.5 * vmax ** 2 * DTS / (0.9 * gamma)
    rep.check("A order-1: Lemma 1 bound covers the layer", np.all(lay <= bound), f"max ratio {np.max(lay / bound):.2f}")
    lay_fs = np.array([-run_order1(dt, 0.1 / dt)[0] for dt in DTS])
    s = loglog_slope(DTS, lay_fs)
    rep.check("A order-1, fixed gamma*dt: layer slope ~ 2", abs(s - 2) < 0.1, f"slope {s:.2f}")
    data.update(A_fixed=lay, A_perstep=lay_fs)

    # B: order 2, convex obstacle --------------------------------------------
    k1 = k2 = 4.0
    out = [run_order2(dt, k1, k2, convex=True) for dt in DTS]
    lay = np.array([-o[0] for o in out])
    s = loglog_slope(DTS, lay)
    rep.check("B order-2 (convex), fixed gains: layer slope ~ 1", abs(s - 1) < 0.15, f"slope {s:.2f}")
    vbar, abar = max(o[1] for o in out), max(o[2] for o in out)
    bnd = np.array([lemma2_layer(dt, k1, k2, vbar, abar, 0.9 * 0.5) for dt in DTS])
    rep.check("B order-2: Lemma 2 bound covers the layer", np.all(lay <= bnd), f"max ratio {np.max(lay / bnd):.3f}")
    lead = 0.5 * DTS * V0 ** 2 / 0.5 * (1 / k1 + 1 / k2)
    rep.info("B leading-order estimate 1/2 v^2 dt/rho (1/k1+1/k2)", f"measured/estimate {np.round(lay / lead, 2)}")
    lay_fs = np.array([-run_order2(dt, 0.08 / dt, 0.08 / dt, convex=True)[0] for dt in DTS])
    s = loglog_slope(DTS, lay_fs)
    rep.check("B order-2, fixed per-step gains: layer slope ~ 2", abs(s - 2) < 0.15, f"slope {s:.2f}")
    data.update(B_fixed=lay, B_perstep=lay_fs)

    marg = np.array([run_order2(dt, k1, k2, convex=False)[0] for dt in DTS])
    rep.check("B+ order-2 on concave disk: favourable sign, no violation", np.all(marg > 0),
              f"min h {np.round(marg, 5)}")

    # C: sphere, ZOH exact physics, braking ------------------------------------
    lay = np.array([-run_sphere(dt, k1, k2) for dt in DTS])
    ok = np.all(lay > 0)
    s = loglog_slope(DTS, lay) if ok else float("nan")
    rep.check("C sphere (Gauss, ZOH physics), fixed gains: violation, slope ~ 1", ok and abs(s - 1) < 0.2,
              f"layer {np.array2string(lay, precision=2)}  slope {s:.2f}")
    lay_fs = np.array([-run_sphere(dt, 0.08 / dt, 0.08 / dt) for dt in DTS])
    pos = lay_fs > 0
    s2 = loglog_slope(DTS[pos], lay_fs[pos]) if pos.sum() >= 3 else float("nan")
    rep.check("C sphere, fixed per-step gains: at least second order", (not pos.any()) or s2 >= 1.9,
              f"layer {np.array2string(lay_fs, precision=2)}  slope {s2:.2f}")
    data.update(C_fixed=lay, C_perstep=lay_fs)
    # ZOH leading term: h* = dt * jerk / (2 k1 k2) at the minimum (Prop. 4(c))
    ratios = []
    for dt in DTS[1:4]:
        hmin, jerk = run_sphere(dt, k1, k2, return_jerk=True)
        ratios.append(hmin / (dt * jerk / (2 * k1 * k2)))
    ratios = np.array(ratios)
    rep.check("C sphere, ZOH: layer = dt * dddot h / (2 k1 k2)", np.all(np.abs(ratios - 1) < 0.2),
              f"measured/predicted {np.round(ratios, 3)}")
    np.savez("v3_data.npz", **data)
    return rep


if __name__ == "__main__":
    main()
