"""PR-MPPI (order 1), CAMP-MPPI (order 2) and the unified controller, from the manuscripts.

Order 1 (PR-MPPI, Alg. 1 of RA-L 26-4730): joint-velocity samples, nested projection
(equality tangent space + CBF half-spaces) inside every rollout step, projected averaging,
execution filtering along the averaged sequence, Gauss-Newton retraction of the command.
Option anchor=True retracts the physical rows onto the level set through the measured
state (Prop. 7 of the Tier-2 note).

Order 2 (CAMP-MPPI, ICRA 2027 #281): commanded-acceleration samples, Gauss constrained
dynamics for the physical equality, composite projection of wrench (reaction) rows and
HOCBF rows under the metric W, projected averaging, execution of the first averaged
command through tau = M a + b.  Unified options: solver="separable" (Thm. 1),
virtual="hard" (stabilised virtual equality rows), metric "I" for the ablation.
"""
import time

import numpy as np

from . import writing as W_
from .qp import project
from .robot import Q_MAX, Q_MIN, QD_MAX


def _weights(S, eta):
    beta = max(eta * np.std(S), 1e-12)
    w = np.exp(-(S - S.min()) / beta)
    return w / w.sum()


class _Base:
    def __init__(self, chain, K=256, H=15, dt=0.02, eta=0.5, seed=0, delta=0.0, h_safe=0.05,
                 w_p=2e4, w_T=2e3, w_v=0.1, w_q=1.0):
        self.chain, self.K, self.H, self.dt, self.eta = chain, K, H, dt, eta
        self.w_q, self.q_ref = w_q, None  # posture regularisation of the null space
        self.rng = np.random.default_rng(seed)
        self.delta, self.h_safe = delta, h_safe
        self.w_p, self.w_T, self.w_v = w_p, w_T, w_v
        self.n = chain.n
        self.U = np.zeros((H, self.n))
        self.stats = {"fallback": 0, "relaxed": 0, "calls": 0, "time": []}

    def _targets(self, t_now):
        return W_.path_point(t_now + self.dt * np.arange(1, self.H + 1))

    def _limits(self, q):
        return q - (Q_MIN + self.h_safe), (Q_MAX - self.h_safe) - q

    def _project(self, *args, **kw):
        u, info = project(*args, return_info=True, **kw)
        self.stats["fallback"] += info["fallback"]
        self.stats["relaxed"] += info["relaxed"]
        self.stats["calls"] += args[0].shape[0]
        return u


class PRMPPI(_Base):
    """Order 1.  metric "I" is PR-MPPI as published; anchor=True is Prop. 7."""

    def __init__(self, chain, sigma=0.05, gamma=5.0, metric="I", anchor=False, **kw):
        super().__init__(chain, **kw)
        self.sigma, self.gamma, self.metric, self.anchor = sigma, gamma, metric, anchor

    def _pi(self, q, v):
        k = W_.kin(self.chain, q, np.zeros_like(q))
        _, Jc, _, _ = W_.contact(k, self.delta)
        _, Jo, _ = W_.orientation(k)
        E = np.concatenate([Jc, Jo], 1)
        lo, hi = self._limits(q)
        B, n = q.shape
        I = np.broadcast_to(np.eye(n), (B, n, n))
        vmax = np.broadcast_to(QD_MAX, (B, n))
        A = np.concatenate([-I, I, I, -I], 1)  # joint-limit CBF rows, then velocity limits
        d = np.concatenate([self.gamma * lo, self.gamma * hi, vmax, vmax], 1)
        Wm = self.chain.mass_matrix(q, k["R"], k["o"]) if self.metric == "M" else np.eye(n)
        soft = np.ones(4 * n, dtype=bool)  # motion rows may be relaxed if infeasible (Prop. 8)
        eq_soft = np.array([False, True, True])  # physical row hard, virtual rows soft
        return self._project(v, Wm, E, np.zeros((B, 3)), A, d, soft=soft, eq_soft=eq_soft), k

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        K, H, n, dt = self.K, self.H, self.n, self.dt
        if self.q_ref is None:
            self.q_ref = q0.copy()
        eps = self.sigma * self.rng.standard_normal((K, H, n))
        tgt = self._targets(t_now)
        q = np.repeat(q0[None], K, 0)
        S = np.zeros(K)
        Uplus = np.empty((K, H, n))
        for t in range(H):
            u, _ = self._pi(q, self.U[t][None] + eps[:, t])
            q = q + dt * u
            Uplus[:, t] = u
            p = self.chain.tool_pose(q)[1]
            S += (self.w_p * np.sum((p - tgt[t]) ** 2, 1) + self.w_v * np.sum(u * u, 1)
                  + self.w_q * np.sum((q - self.q_ref) ** 2, 1)) * dt
        S += self.w_T * np.sum((p - tgt[-1]) ** 2, 1)
        w = _weights(S, self.eta)
        Ustar = np.einsum("k,kti->ti", w, Uplus)
        # execution filtering along the averaged sequence (Eq. 13); t = 0 is already admissible
        qe = q0[None].copy()
        Uf = np.empty_like(Ustar)
        for t in range(H):
            Uf[t] = self._pi(qe, Ustar[t][None])[0][0]
            qe = qe + dt * Uf[t][None]
        q_plus = self.retract(q0 + dt * Uf[0], q0)
        self.U = np.concatenate([Uf[1:], np.zeros((1, n))], 0)  # warm start as PR-MPPI Alg. 1 line 23
        self.stats["time"].append(time.perf_counter() - t0)
        return {"q_plus": q_plus, "u": Uf[0]}

    def retract(self, q, q_meas, tol=1e-12, iters=30):
        """Gauss-Newton retraction (Eq. 15).  Physical row targets 0, or c(q_meas) if anchored."""
        target_c = 0.0
        if self.anchor:
            km = W_.kin(self.chain, q_meas[None], np.zeros((1, self.n)))
            target_c = W_.contact(km, self.delta)[0][0, 0]
        q = q.copy()
        for _ in range(iters):
            k = W_.kin(self.chain, q[None], np.zeros((1, self.n)))
            c, Jc, _, _ = W_.contact(k, self.delta)
            e, Jo, _ = W_.orientation(k)
            g = np.concatenate([c[0] - target_c, e[0]])
            if np.linalg.norm(g) < tol:
                break
            J = np.concatenate([Jc[0], Jo[0]], 0)
            q = q - J.T @ np.linalg.solve(J @ J.T, g)
        return q


class CAMPMPPI(_Base):
    """Order 2.  CAMP-MPPI: metric "M", solver "joint", and the pen orientation either as a
    cost (virtual="soft") or inside the constraint manifold (virtual="physical", i.e. treated
    as if the surface supplied the orienting reaction).  Unified: solver "separable",
    virtual="hard" (stabilised virtual rows, Prop. 2)."""

    def __init__(self, chain, sigma=1.5, k1=4.0, k2=4.0, metric="M", solver="joint", virtual="soft",
                 KP=100.0, KD=20.0, w_f=1.0, w_o=5e3, w_v=1.0, w_q=5.0, average="projected", noise_clip=None,
                 reaction="clamped", **kw):
        super().__init__(chain, w_v=w_v, w_q=w_q, **kw)
        self.average, self.noise_clip = average, noise_clip  # as in generic.CAMP2 (Algorithm 1: "raw", 3.0)
        self.reaction = reaction
        self.sigma, self.k1, self.k2 = sigma, k1, k2
        self.metric, self.solver, self.virtual = metric, solver, virtual
        self.KP, self.KD, self.w_f, self.w_o = KP, KD, w_f, w_o
        self.lo, self.hi = W_.LAM_BAND

    def _model(self, q, qd):
        k = W_.kin(self.chain, q, qd)
        M = self.chain.mass_matrix(q, k["R"], k["o"])
        Mi = np.linalg.inv(M)
        _, Jc, jcd, _ = W_.contact(k, self.delta)
        e, Jo, jod = W_.orientation(k)
        if self.virtual == "physical":  # orientation rows inside the Gauss manifold
            Jc = np.concatenate([Jc, Jo], 1)
            jcd = np.concatenate([jcd, jod], 1)
        Lam = np.linalg.inv(Jc @ Mi @ np.swapaxes(Jc, 1, 2))  # (B,nc,nc)
        MiJt = Mi @ np.swapaxes(Jc, 1, 2)  # (B,n,nc)
        F = np.eye(self.n) - MiJt @ Lam @ Jc
        f = -(MiJt @ Lam @ jcd[..., None])[..., 0]
        return dict(k=k, M=M, Mi=Mi, Jc=Jc, jcd=jcd, Lam=Lam, MiJt=MiJt, F=F, f=f, e=e, Jo=Jo, jod=jod)

    def _hocbf(self, q, qd, f):
        """Motion rows on x = qdd - f:  -x <= d_lo, x <= d_hi (joint-limit HOCBF and the
        velocity limits |qd + dt qdd| <= qd_max, whichever is tighter per joint and side)."""
        lo, hi = self._limits(q)
        s, p = self.k1 + self.k2, self.k1 * self.k2
        d_lo = np.minimum(f + s * qd + p * lo, (QD_MAX + qd) / self.dt + f)
        d_hi = np.minimum(-f - s * qd + p * hi, (QD_MAX - qd) / self.dt - f)
        return d_lo, d_hi

    def _pi(self, q, qd, a_raw, mdl):
        B, n = q.shape
        F, f, M = mdl["F"], mdl["f"], mdl["M"]
        d_lo, d_hi = self._hocbf(q, qd, f)
        edot = np.einsum("bij,bj->bi", mdl["Jo"], qd)
        r_v = -self.KD * edot - self.KP * mdl["e"]
        Lam, Jc, jcd = mdl["Lam"], mdl["Jc"], mdl["jcd"]
        Wm = M if self.metric == "M" else np.eye(n)
        if self.solver == "separable":
            assert self.metric == "M", "separation needs the inertia metric (Thm. 1)"
            I = np.broadcast_to(np.eye(n), (B, n, n))
            A = np.concatenate([-I, I], 1)
            d = np.concatenate([d_lo, d_hi], 1)
            E = Jc
            e = np.zeros((B, 1))
            if self.virtual == "hard":
                E = np.concatenate([Jc, mdl["Jo"]], 1)
                e = np.concatenate([e, r_v - np.einsum("bij,bj->bi", mdl["Jo"], f) - mdl["jod"]], 1)
            soft = np.ones(2 * n, dtype=bool)
            eq_soft = np.array([False] + ([True, True] if self.virtual == "hard" else []))
            x = self._project(np.einsum("bij,bj->bi", F, a_raw), M, E, e, A, d, soft=soft, eq_soft=eq_soft)
            lam_raw = -(Lam[:, 0, 0] * (np.einsum("bij,bj->bi", Jc, a_raw)[:, 0] + jcd[:, 0]))
            lam = np.clip(lam_raw, self.lo, self.hi)
            a = x - mdl["MiJt"][..., 0] * (lam + Lam[:, 0, 0] * jcd[:, 0])[:, None]
            return a
        # joint composite projection (CAMP-MPPI Eq. 37), rows expressed in a;
        # the band acts on the normal-force component lambda_0
        G0 = (Lam @ Jc)[:, :1]
        LamJcd = np.einsum("bij,bj->bi", Lam, jcd)[:, :1]
        A = np.concatenate([-F, F, G0, -G0], 1)
        d = np.concatenate([d_lo, d_hi, -self.lo - LamJcd, self.hi + LamJcd], 1)
        E = e = None
        if self.virtual == "hard":
            E = mdl["Jo"] @ F
            e = r_v - np.einsum("bij,bj->bi", mdl["Jo"], f) - mdl["jod"]
        soft = np.concatenate([np.ones(2 * n, dtype=bool), np.zeros(2, dtype=bool)])  # reaction rows hard
        eq_soft = np.ones(2, dtype=bool) if E is not None else None
        return self._project(a_raw, Wm, E, e, A, d, soft=soft, eq_soft=eq_soft)

    def plan(self, q0, qd0, t_now):
        t0 = time.perf_counter()
        K, H, n, dt = self.K, self.H, self.n, self.dt
        if self.q_ref is None:
            self.q_ref = q0.copy()
        z = self.rng.standard_normal((K, H, n))
        eps = self.sigma * (z if self.noise_clip is None else np.clip(z, -self.noise_clip, self.noise_clip))
        tgt = self._targets(t_now)
        q = np.repeat(q0[None], K, 0)
        qd = np.repeat(qd0[None], K, 0)
        S = np.zeros(K)
        Aplus = np.empty((K, H, n))
        for t in range(H):
            mdl = self._model(q, qd)
            a = self._pi(q, qd, self.U[t][None] + eps[:, t], mdl)
            qdd = np.einsum("bij,bj->bi", mdl["F"], a) + mdl["f"]
            lam = -np.einsum("bij,bj->bi", mdl["Lam"], np.einsum("bij,bj->bi", mdl["Jc"], a) + mdl["jcd"])[:, 0]
            qd = qd + dt * qdd
            q = q + dt * qd
            Aplus[:, t] = a
            p = self.chain.tool_pose(q)[1]
            run = self.w_p * np.sum((p - tgt[t]) ** 2, 1) + self.w_v * np.sum(qd * qd, 1)
            run += self.w_q * np.sum((q - self.q_ref) ** 2, 1)
            run += self.w_f * (lam - W_.LAM_NOM) ** 2
            if self.virtual == "soft":
                run += self.w_o * np.sum(mdl["e"] ** 2, 1)
            S += run * dt
        S += self.w_T * np.sum((p - tgt[-1]) ** 2, 1)
        w = _weights(S, self.eta)
        mdl0 = self._model(q0[None], qd0[None])
        if self.average == "raw":  # Algorithm 1: raw average, the executed command projected once
            Astar = self.U + np.einsum("k,kti->ti", w, eps)
            a0 = self._pi(q0[None], qd0[None], Astar[0][None], mdl0)[0]
        else:  # first averaged step, admissible at t = 0 by convexity (Prop. 3(b))
            Astar = np.einsum("k,kti->ti", w, Aplus)
            a0 = Astar[0]
        self.U = np.concatenate([Astar[1:], np.zeros((1, n))], 0)
        if self.average == "raw" and self.reaction == "clamped":
            # separation: motion part from the projection of the raw average, reaction = average of the clamped
            # sample reactions; the reaction map of the measured state serves every step of the warm start
            Lam, Jc, jcd, MiJt = mdl0["Lam"][0, 0, 0], mdl0["Jc"][0, 0], mdl0["jcd"][0, 0], mdl0["MiJt"][0][:, 0]
            lam_bar = w @ (-Lam * (Aplus @ Jc + jcd))
            a0 = a0 + MiJt * (-Lam * (Jc @ a0 + jcd) - lam_bar[0])
            lam_U = -Lam * (self.U @ Jc + jcd)
            self.U = self.U + (lam_U - np.concatenate([lam_bar[1:], [lam_bar[-1]]]))[:, None] * MiJt[None]
        lam0 = -(mdl0["Lam"][0] @ (mdl0["Jc"][0] @ a0 + mdl0["jcd"][0]))[0]
        self.stats["time"].append(time.perf_counter() - t0)
        return {"a": a0, "lam_cmd": lam0}
