# UP-MPPI 실기 실험 인수인계

## 현재 원고의 범위

현재 `tier2_theory.tex`와 PDF는 **이론·수치 검증·시뮬레이션·계산 시간 측정**으로 작성한다.
수행하지 않은 실기 결과나 예상 성공률은 본문에 넣지 않는다. 실기 전용 계획은 이 문서와
[waiter 상세 프로토콜](HARDWARE.md)에 둔다.

최종 T-RO 원고에는 주요 실험을 실제 로봇에서 검증한 결과를 추가한다. 시뮬레이션의 정밀한
ablation과 이론 검증은 필요에 따라 본문이나 보충자료에 유지한다. 학생의 목표는 아래 주장과
비교 조건을 실기로 검증하는 것이다. 시뮬레이션과 같은 숫자를 얻는 것이 목표는 아니다.

## 실험별로 이어받을 내용

표 번호는 편집에 따라 바뀌므로 원고의 절 이름과 실험 파일을 기준으로 연결한다.

| 실험 / 원고 절 | 검증할 주장 | 유지할 주요 비교 | 실기에서 측정할 항목 | 출발점 |
|---|---|---|---|---|
| Curved-surface writing | 물리 접촉과 가상 자세 제약의 구분, 모델 오프셋에 따른 접촉력, 명령/실제 반력의 차이 | PR, anchored PR, CAMP의 자세 cost, UP-MPPI; 필요 시 동일 raw update의 joint/separable 및 metric ablation | 실제 접촉력의 평균·분산·범위 만족률, 명령 반력, 경로/자세 RMSE, 접촉 유지, 중단 시점, 모델 오프셋 | `experiments/writing_exp.py`, `experiments/writing_baselines.py` |
| Dual-arm closed chain | 기하 모델 오차가 내부 힘으로 이어지는 현상, anchoring과 반력 제약의 효과 | PR, anchored PR, UP-MPPI; 기존 joint-limit ablation | 양쪽 wrench를 공통 좌표계로 변환한 내부 힘·모멘트, closed-chain 오차, 트레이 자세, 관절 여유, 명령/측정값 | `experiments/dualarm_exp.py` |
| Waiter / certified wrench rows | 불확실한 CoM에 대한 robust 제약과 F/T-only COP 적응, 명시적 실행 오차 마진 | nominal, robust, adaptive-COP, oracle; 현재 A1/A2/A3/B1 및 projected/raw ablation | 전도·접촉 상실, 주기 평균과 센서 주기의 COP/잔차, h 구간과 참값 포함 여부, 업데이트 거절, 이동별 RMSE, 물체 위치 변화 | `experiments/waiter_exp.py`, `experiments/waiter_baselines.py`, [HARDWARE.md](HARDWARE.md) |
| Computation timing | 같은 projection 문제에서 분리 풀이의 계산 이점, 실제 제어 주기를 지킬 수 있는지 | 같은 장치·K·H·정밀도에서 joint/separable | 계획 시간 중앙값·p95·p99·최대, deadline miss, 센싱부터 명령 전달까지 지연; kernel 시간은 별도 | `experiments/gpu_timing.py` |

## Baseline과 조건

현재 합의한 baseline 구성을 유지한다. 외부 방법 세 종류를 새로 추가하는 것을 실기 작업의
선행 조건으로 두지 않는다.

- A1: penalty MPPI.
- A2: penalty rollout + 최종 projection; 같은 tightening 조건에서 UP-MPPI와 비교.
- A3: 같은 hard rows를 사용하는 one-step QP.
- B1: 같은 측정 창을 사용하는 RLS certainty equivalence.
- Ablation: projected/raw 평균, tightening 유무, joint/separable, metric.

각 비교의 공통 모델, 입력/제약, 참조 경로, 제어 주기, 샘플 수, 지평, 센서 정보를 기록한다.
튜닝 범위와 선택 기준은 평가 전에 정하고, 평가 trial로 튜닝하지 않는다. baseline이 이기는
조건도 함께 보고한다. A3는 예측 지평을 제거하는 비교이므로 MPPI와 지평이 같다고 쓰지 않는다.

## 실기로 옮기기 전 확인할 두 항목

1. **Writing의 명령 반력과 실제 반력을 구분한다.** 현재 raw-update 시뮬레이션은 명령 반력의
   2–4 N 제약을 만족해도 실제 힘이 하한 아래로 내려갈 수 있다. 실행 오차 마진을 추가하는
   실험은 별도 variant로 기록하고, 명령/측정 힘과 추종 성능을 함께 평가한다.
2. **Waiter의 보장 범위를 유지한다.** 현재 시뮬레이션은 제어 주기 평균 wrench에 관한
   조건부 보장을 평가한다. 순간 값의 위반을 평균으로 숨기지 말고 두 해상도의 잔차와 COP를
   각각 기록한다. 마찰 추정이나 모든 순간의 접촉 안전은 현재 결과만으로 주장하지 않는다.

## 학생이 진행할 순서

1. 전달받은 코드와 결과의 버전을 고정하고, 대표 시뮬레이션을 재현한다. 원고와 사용한
   알고리즘의 평균 방식·noise clipping·tightening이 일치하는지 확인한다.
2. 실제 장비, 물체, 저수준 제어기, 센서 좌표계 및 보정 방법을 기록한다. 시뮬레이션의
   noise/error bound와 제어 주기를 실기에 그대로 가정하지 않는다.
3. 평가와 별도의 데이터로 모델/센서/실행 오차를 보정한다. 평가 중에는 이 설정을 고정하고,
   bound가 깨진 trial도 남긴다. 재보정 후 실험은 별도 batch로 구분한다.
4. 비교 조건과 반복 횟수를 정하고 trial 순서를 섞어 수행한다. 같은 물체·궤적·센서 조건을
   맞추되, 실제 사용 조건이 달라지면 simulation과 hardware를 별도 표로 제시한다.
5. 전체 trial을 분석하고 대표 영상을 고른다. 실패·중단 사유와 전체 분모를 함께 보고한다.
6. 실기 절의 setup, 표·그림, 결과 해석을 실제 데이터에 맞게 작성한다. 시뮬레이션의
   설명을 그대로 복사하거나 `simulation`이라는 단어만 바꾸지 않는다.

## 전달할 산출물

각 실험에 대해 다음을 묶어 전달한다.

- **설정:** 코드 버전, 장비/센서/물체, 단위·좌표계, 제어기 파라미터, baseline 튜닝 기록,
  calibration/evaluation 구분, trial ID.
- **원시 로그:** 시간, 관절 상태, 참조/실제 경로, 명령, 명령·측정 wrench, 활성 제약과 잔차,
  추정 구간, 실패/중단/거절 이벤트, 계획 및 실행 지연. 해당 실험에 필요한 센서 원본을 보존한다.
- **분석:** 원시 로그로부터 표·그림을 재생성하는 코드, trial별 수치, 집계와 산포,
  제외한 trial이 있다면 그 사유.
- **영상:** trial ID와 연결된 원본 및 비교 영상, 재생 속도와 실패/중단 표시.
- **원고:** 실제 setup 문단, 표·그림 caption, 관찰 결과와 한계. 기대와 다른 결과도 반영한다.

실기 데이터가 준비되기 전에는 이 문서의 계획을 완료된 결과로 본문에 옮기지 않는다.
