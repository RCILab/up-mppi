"""Section 'Certified wrench constraints under model uncertainty' -- Propositions R1-R3.

R1 vertex reduction: for rows multilinear in theta over a box, the maximum over the box is attained
   at a vertex (random multilinear rows, dense sampling), and the waiter support rows are affine in
   h and in mu; a row quadratic in theta is the negative control.
R2 certificate: the executed command of the unified controller on the waiter task, with the rows of
   a parameter box, satisfies the rows of every parameter in the box.
R3 set membership: bounded-error impulse measurements keep the true (m, m h) inside nonincreasing
   intervals; noise beyond the bound is the negative control.
"""
import itertools
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common import Report  # noqa: E402
from umppi import waiter as WT  # noqa: E402
from umppi.generic import CAMP2  # noqa: E402
from umppi.robot import cross  # noqa: E402

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])


def multilinear(theta, C):
    """f(theta) = sum_S C_S prod_{i in S} theta_i, subsets S of {0..p-1} enumerated by bitmask."""
    p = theta.shape[-1]
    out = np.zeros(theta.shape[:-1])
    for mask in range(2 ** p):
        term = np.ones(theta.shape[:-1])
        for i in range(p):
            if mask >> i & 1:
                term = term * theta[..., i]
        out = out + C[mask] * term
    return out


def check_vertex(rep, rng):
    p, worst, trials = 3, -np.inf, 300
    for _ in range(trials):
        lo = rng.uniform(-1, 0.5, p)
        hi = lo + rng.uniform(0.1, 1.5, p)
        n_a = 5
        W = rng.standard_normal((2 ** p, n_a))
        b = rng.standard_normal(2 ** p)
        a = rng.standard_normal(n_a)
        C = W @ a + b  # coefficients affine in the command
        th = lo + (hi - lo) * rng.uniform(size=(4000, p))
        verts = np.array(list(itertools.product(*zip(lo, hi))))
        worst = max(worst, multilinear(th, C).max() - multilinear(verts, C).max())
    rep.check("R1: max of a multilinear row over a box is at a vertex", worst <= 1e-12,
              f"max(sampled) - max(vertices) = {worst:.1e} over {trials} random rows")
    # negative control: -(theta - 0.5)^2 on [0, 1] peaks inside
    th = np.linspace(0, 1, 1001)
    f = -(th - 0.5) ** 2
    rep.check("R1 control: a row quadratic in theta peaks inside the box", f.max() - max(f[0], f[-1]) > 0.2,
              f"interior max exceeds the vertex max by {f.max() - max(f[0], f[-1]):.2f}")


def check_affine_rows(rep, rng):
    ch = WT.make_chain()
    q0 = WT.ik(ch, WT.A_PT, Q_READY)
    B = 64
    q = q0[None] + 0.2 * rng.standard_normal((B, 7))
    qd = 0.5 * rng.standard_normal((B, 7))
    a = 2.0 * rng.standard_normal((B, 7))

    def rows(h, mu):
        T = WT.WaiterTask(ch, [h], [mu], q_ref=q0)
        K = T.kin(q, qd)
        C, d = T.extra_rows(K, q, qd)
        return np.einsum("bij,bj->bi", C, a) - d
    r1, r2, rm = rows(0.05, 0.4), rows(0.18, 0.8), rows(0.115, 0.6)
    err = np.max(np.abs(rm - 0.5 * (r1 + r2)))
    rep.check("R1: waiter tipping/slipping rows are affine in (h, mu)", err < 1e-12, f"midpoint error {err:.1e}")


def check_certificate(rep, rng):
    ch = WT.make_chain()
    q0 = WT.ik(ch, WT.A_PT, Q_READY)
    h_box, mu_box = [0.05, 0.18], [0.4, 0.8]
    worst, n_states = -np.inf, 8
    for k in range(n_states):
        task = WT.WaiterTask(ch, h_box, mu_box, q_ref=q0, dt=0.02, H=8)
        task.t_now = 0.3 + 0.1 * k  # inside move 1: the tracking cost pushes against the rows
        ctrl = CAMP2(task, sigma=1.0, solver="separable", virtual="hard", dt=0.02, H=8, K=64)
        ctrl.rng = np.random.default_rng(k)
        q = q0 + 0.05 * rng.standard_normal(7)
        qd = 0.3 * rng.standard_normal(7)
        a = ctrl.plan(q, qd, task.t_now)["a"]
        for h in np.linspace(*h_box, 7):
            for mu in np.linspace(*mu_box, 5):
                T = WT.WaiterTask(ch, [h], [mu], q_ref=q0)
                K = T.kin(q[None], qd[None])
                C, d = T.extra_rows(K, q[None], qd[None])
                worst = max(worst, float(np.max(C[0] @ a - d[0])))
    rep.check("R2: executed command satisfies the rows of every parameter in the box", worst <= 1e-8,
              f"largest row value {worst:.1e} over {n_states} states x 35 parameters")


def check_set_membership(rep, rng, noise_scale=1.0, trials=400, steps=60):
    """Synthetic windows with the error model of the waiter task: bounded sensor noise and a constant
    unknown offset d of the box on the tray (|d| <= d_max), scaled by noise_scale."""
    contained, monotone, invalid = True, True, 0
    for _ in range(trials):
        m, h = rng.uniform(0.25, 1.4), rng.uniform(0.06, 0.17)
        est = WT.SetMembership(h_box=(0.05, 0.18))
        ang = rng.uniform(0, 2 * np.pi)
        d = noise_scale * est.d_max * rng.uniform(0.5, 1.0) * np.array([np.cos(ang), np.sin(ang), 0.0])
        widths = [(est.m[1] - est.m[0], est.phi[1] - est.phi[0])]
        Tw = 0.04
        for _ in range(steps):
            tilt = np.radians(rng.uniform(0, 1.5)) * np.array([np.cos(rng.uniform(0, 2 * np.pi)), np.sin(rng.uniform(0, 2 * np.pi)), 0])
            n = np.array([0, 0, 1.0]) + tilt
            n /= np.linalg.norm(n)
            acc = np.array([*rng.uniform(-2.0, 2.0, 2), rng.uniform(-1.0, 1.0)])
            S = Tw * (acc - WT.G)
            YF = m * S + noise_scale * est.eps_f * Tw * rng.uniform(-1, 1, 3)
            YT = m * h * cross(n, S) + m * cross(d, S) + noise_scale * est.eps_t * Tw * rng.uniform(-1, 1, 3)
            ok = est.update(YF, YT, S, n, Tw)
            invalid += not ok
            lo, hi = est.h
            contained &= est.m[0] <= m <= est.m[1] and est.phi[0] <= m * h <= est.phi[1] and lo <= h <= hi
            widths.append((est.m[1] - est.m[0], est.phi[1] - est.phi[0]))
        w = np.array(widths)
        monotone &= bool(np.all(np.diff(w, axis=0) <= 1e-15))
    return contained, monotone, invalid


def check_tighten(rep, rng, trials=2000):
    """Prop. (model -> realized wrench): rows tightened by eps ||A_i||_* keep every realized wrench
    with ||delta|| <= eps admissible (Euclidean norm, self-dual); untightened rows do not."""
    worst_t, viol_untight = -np.inf, 0
    for _ in range(trials):
        m, p = 6, 4
        A = rng.standard_normal((m, p))
        b = rng.uniform(0.5, 2.0, m)
        eps = rng.uniform(0.01, 0.3)
        bt = b - eps * np.linalg.norm(A, axis=1)
        lam = rng.standard_normal(p)
        # push lam onto the boundary of the tightened set along a random row (worst case for the margin)
        i = rng.integers(m)
        lam = lam + (bt[i] - A[i] @ lam) / (A[i] @ A[i]) * A[i]
        if np.any(A @ lam > bt + 1e-12):
            continue
        delta = eps * A[i] / np.linalg.norm(A[i])  # the worst direction for row i
        worst_t = max(worst_t, float(np.max(A @ (lam + delta) - b)))
        lam_u = lam + (b[i] - A[i] @ lam) / (A[i] @ A[i]) * A[i]  # on the untightened boundary
        viol_untight += bool(A[i] @ (lam_u + delta) - b[i] > 1e-12)
    rep.check("R4: tightened rows keep the realized wrench admissible", worst_t <= 1e-12, f"largest row value {worst_t:.1e}")
    rep.check("R4 control: without tightening the worst deviation leaves the set", viol_untight > 0,
              f"{viol_untight} violations out of the tested cases")


def check_cop(rep, rng, scale=1.0, trials=200, steps=150):
    """COP differences: p_c = d - h q with a creeping box position and bounded sensor errors;
    containment and nesting of the h interval, and the control with errors beyond the bounds."""
    contained, nested, invalid = True, True, 0
    Tw, dt = 0.04, 0.02
    for _ in range(trials):
        h, m = rng.uniform(0.06, 0.17), rng.uniform(0.3, 1.2)
        est = WT.COPDifference(h_box=(0.05, 0.18))
        n, t1, t2 = np.array([0, 0, 1.0]), np.array([1.0, 0, 0]), np.array([0, 1.0, 0])
        d = np.zeros(3)
        prev_w = est.h[1] - est.h[0]
        for k in range(steps):
            t = 0.1 + k * dt
            a_h = 1.2 * np.sin(2 * np.pi * t / 1.6) * np.array([np.cos(0.3), np.sin(0.3), 0])  # smooth excitation
            S = Tw * (a_h - WT.G)
            # creep: at most rho per second, plus a d0 jump now and then, scaled
            d = d + scale * est.rho_d * dt * rng.uniform(-1, 1, 3) * np.array([1, 1, 0])
            YF_true = m * S
            YT_true = m * cross(h * n + d, S)
            YF = YF_true + scale * est.eps_f * Tw * rng.uniform(-1, 1, 3)
            YT = YT_true + scale * est.eps_t * Tw * rng.uniform(-1, 1, 3)
            ok = est.update(t, YF, YT, S, n, t1, t2, Tw)
            invalid += not ok
            contained &= est.h[0] - 1e-12 <= h <= est.h[1] + 1e-12
            w = est.h[1] - est.h[0]
            nested &= w <= prev_w + 1e-15
            prev_w = w
    return contained, nested, invalid


def main():
    rep = Report("R1-R3 robust wrench rows")
    rng = np.random.default_rng(8)
    check_vertex(rep, rng)
    check_affine_rows(rep, rng)
    check_certificate(rep, rng)
    c, mono, inv = check_set_membership(rep, rng)
    rep.check("R3: true (m, m h, h) stays in the intervals; intervals nonincreasing", c and mono and inv == 0,
              f"contained {c}, nonincreasing {mono}, rejected updates {inv} (400 objects x 60 windows)")
    c2, _, inv2 = check_set_membership(rep, rng, noise_scale=3.0, trials=100)
    rep.check("R3 control: noise and offset three times the bound break containment or are rejected", (not c2) or inv2 > 0,
              f"contained {c2}, rejected updates {inv2}")
    check_tighten(rep, rng)
    c3, n3, inv3 = check_cop(rep, rng)
    rep.check("R3 COP differences: true h stays in the interval; interval nonincreasing", c3 and n3 and inv3 == 0,
              f"contained {c3}, nonincreasing {n3}, rejected updates {inv3} (200 boxes x 150 windows)")
    c4, _, inv4 = check_cop(rep, rng, scale=3.0, trials=60)
    rep.check("R3 COP control: creep and noise three times the bounds break containment or are rejected", (not c4) or inv4 > 0,
              f"contained {c4}, rejected updates {inv4}")
    return rep


if __name__ == "__main__":
    main()
