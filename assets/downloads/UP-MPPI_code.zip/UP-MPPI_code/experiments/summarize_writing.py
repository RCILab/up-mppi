"""Aggregate the writing sweep: table (mean +- std over seeds) and the Prop. 2(b) prediction."""
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from experiments.writing_exp import DT, Q_READY  # noqa: E402
from umppi import writing as W_  # noqa: E402
from umppi.robot import Chain  # noqa: E402

NAMES = ["PR", "PR-anchored", "CAMP", "CAMP-manifold", "Unified", "Unified-joint", "Unified-W=I"]
DELTAS = [-1.0, -0.5, 0.0, 0.5, 1.0]


def predicted_gain(omega=2 * np.pi * 10, k_env=2.0e4):
    """Series stiffness (N/m) of Prop. 2(b) along the path, with the period-averaged stiffness
    K_eff = M (omega^2 / 2 + 2 omega / dt) of the interpolated computed-torque loop."""
    ch = Chain()
    q = Q_READY.copy()
    out = []
    for t in np.linspace(0, W_.T_PATH, 33)[:-1]:
        q = W_.ik_on_surface(ch, W_.path_point(t)[0], q)
        k = W_.kin(ch, q[None], np.zeros((1, 7)))
        Jc = W_.contact(k)[1][0]
        Keff = ch.mass_matrix(q[None])[0] * (omega ** 2 / 2 + 2 * omega / DT)
        LamK = 1.0 / (Jc @ np.linalg.solve(Keff, Jc.T))[0, 0]
        out.append(1.0 / (1.0 / LamK + 1.0 / k_env))
    return float(np.mean(out))


def main(path="results/writing.json"):
    D = json.loads((Path(__file__).resolve().parent / path).read_text())
    rows = [r for r in D["rows"] if "error" not in r]
    errors = [r for r in D["rows"] if "error" in r]
    g = defaultdict(list)
    for r in rows:
        g[(r["controller"], r["delta_mm"])].append(r)
    gain = predicted_gain()
    table = []
    for nm in NAMES:
        for dl in DELTAS:
            rs = g[(nm, dl)]
            if not rs:
                continue

            def ms(key):
                v = np.array([r[key] for r in rs])
                return float(v.mean()), float(v.std())
            pred = gain * (-dl * 1e-3) if nm == "PR" and dl < 0 else (0.0 if nm.startswith("PR") else None)
            table.append(dict(controller=nm, delta_mm=dl, n=len(rs), force=ms("force_mean"), force_std=ms("force_std"),
                              in_band=ms("in_band"), contact=ms("contact"), track=ms("track_rmse_mm"),
                              ori=ms("ori_rms_deg"), ms_step=ms("ms_per_step"), pred_force=pred,
                              relaxed=int(sum(r.get("relaxed", 0) for r in rs)),
                              fallback=max(r["fallback_rate"] for r in rs)))
    same = 0.0
    for dl in DELTAS:
        for s in range(3):
            a, b = D["traces"].get(f"Unified|{dl}|{s}"), D["traces"].get(f"Unified-joint|{dl}|{s}")
            if a and b:
                same = max(same, float(np.max(np.abs(np.array(a) - np.array(b)))))
    summary = dict(pred_gain_N_per_mm=gain * 1e-3, separable_vs_joint_max_force_diff=same, errors=errors, table=table)
    (Path(__file__).resolve().parent / "results/writing_summary.json").write_text(json.dumps(summary, indent=1))
    print(f"Prop. 2(b) predicted PR slope: {gain * 1e-3:.2f} N/mm;  max |F_sep - F_joint| = {same:.2e} N;  errors: {len(errors)}")
    print(f"{'controller':14s} {'dl':>5s} {'force [N]':>12s} {'pred':>6s} {'in band':>8s} {'contact':>8s} {'track [mm]':>11s} {'ori [deg]':>9s} {'relax':>6s}")
    for t in table:
        pf = "" if t["pred_force"] is None else f"{t['pred_force']:.2f}"
        print(f"{t['controller']:14s} {t['delta_mm']:5.1f} {t['force'][0]:6.2f}+-{t['force'][1]:4.2f} {pf:>6s} "
              f"{t['in_band'][0]:8.3f} {t['contact'][0]:8.3f} {t['track'][0]:6.2f}+-{t['track'][1]:3.2f} "
              f"{t['ori'][0]:9.3f} {t['relaxed']:6d}")


if __name__ == "__main__":
    main(*sys.argv[1:])
