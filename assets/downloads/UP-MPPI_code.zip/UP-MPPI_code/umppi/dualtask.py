"""Dual-arm tray task for the generic controllers (PR-MPPI Exp. 1 analogue).

Lower the level tray from START to GOAL by joint tracking of an IK solution; joint 4 of both arms
is given an artificial lower bound 0.06 rad above its goal value (the goal lies beyond the bound),
with the 0.05 rad CBF margin of PR-MPPI.  Physical rows: the 6 closed-chain rows; virtual rows:
tray roll and pitch.  The controller model may carry a calibration offset of the right-arm base,
while the grasp transform is the nominal one (CAD knowledge).
"""
import numpy as np

from . import dualarm as DA
from .robot import Q_MAX, Q_MIN, QD_MAX

START, GOAL = np.array([0.60, 0.0, 0.40]), np.array([0.42, 0.0, 0.20])
Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])


def configurations(arms):
    q_start = DA.ik_pair(arms, START, np.concatenate([Q_READY, Q_READY]))
    q_goal = DA.ik_pair(arms, GOAL, q_start)
    return q_start, q_goal


class DualTask:
    n = 14

    def __init__(self, arms_model, grasp, q_goal, q4_min, w_track=20.0, w_v=0.5, w_T=50.0, w_lam=0.01,
                 penalty=False, lam_box=(1.0, 5.0)):
        self.arms, self.grasp, self.q_goal = arms_model, grasp, q_goal
        self.q_min = np.tile(Q_MIN, 2)
        self.q_min[3] = self.q_min[10] = q4_min
        self.q_max, self.qd_max, self.h_safe = np.tile(Q_MAX, 2), np.tile(QD_MAX, 2), 0.05
        self.w_track, self.w_v, self.w_T, self.w_lam = w_track, w_v, w_T, w_lam
        self.w_pen = w_track / 10.0 if penalty else 0.0  # PR-MPPI: tracking weight 10x the limit penalty
        if lam_box is None:
            self.lam_lo = self.lam_hi = None
        else:
            tq, fc = lam_box
            self.lam_hi = np.array([tq, tq, tq, fc, fc, fc])
            self.lam_lo = -self.lam_hi

    def kin(self, q, qd):
        return DA.kin_pair(self.arms, q, qd)

    def mass(self, q, K):
        B = q.shape[0]
        M = np.zeros((B, 14, 14))
        M[:, :7, :7] = self.arms[0].mass_matrix(q[:, :7], K[0]["R"], K[0]["o"])
        M[:, 7:, 7:] = self.arms[1].mass_matrix(q[:, 7:], K[1]["R"], K[1]["o"])
        return M

    def phys(self, K):
        return DA.chain_rows(K, self.grasp)

    def virt(self, K):
        return DA.tilt_rows(K)

    def run_cost(self, q, qd, lam, t):
        c = self.w_track * np.sum((q - self.q_goal) ** 2, 1) + self.w_v * np.sum(qd * qd, 1)
        if self.w_pen:
            c += self.w_pen * np.sum(np.maximum(0.0, (self.q_min + self.h_safe) - q) ** 2, 1)
        if lam is not None:
            c += self.w_lam * np.sum(lam * lam, 1)
        return c

    def term_cost(self, q, qd):
        return self.w_T * np.sum((q - self.q_goal) ** 2, 1)
