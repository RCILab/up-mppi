"""Curved-surface writing task (CAMP-MPPI Sec. IV-B), batched model-side quantities.

Board: sphere of radius R_S centred at C_S; pen tip on its top region.
  physical equality  c(q) = |p - C_S| - (R_S + delta)            (1 row, model offset delta)
  virtual equality   e(q) = [z_t . e_x, z_t . e_y] = 0             (pen axis vertical, 2 rows)
Path: lemniscate on the sphere, one period in T_PATH seconds.
"""
import numpy as np

C_S = np.array([0.50, 0.0, -0.45])
R_S = 0.60
A_PATH, T_PATH = 0.08, 8.0
LAM_BAND = (2.0, 4.0)
LAM_NOM = 3.0
EX, EY = np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def path_point(t):
    """(T,) -> (T, 3) points on the real board surface."""
    t = np.atleast_1d(t)
    w = 2 * np.pi / T_PATH
    u = A_PATH * np.sin(w * t)
    v = A_PATH * np.sin(w * t) * np.cos(w * t)
    d = np.stack([u, v, np.full_like(u, R_S)], -1)
    return C_S + R_S * d / np.linalg.norm(d, axis=-1, keepdims=True)


def kin(chain, q, qd):
    """Everything the constraints need, batched."""
    R, o = chain.fk(q)
    Jv, Jw, p = chain.jacobian(q, R=R, o=o)
    pd = np.einsum("bij,bj->bi", Jv, qd)
    w = np.einsum("bij,bj->bi", Jw, qd)
    jdv, jdw = chain.point_acc_bias(q, qd)
    zt = R[:, -1, :, 2]
    return dict(R=R, o=o, p=p, pd=pd, w=w, Jv=Jv, Jw=Jw, jdv=jdv, jdw=jdw, zt=zt)


def contact(k, delta=0.0):
    """Physical row: c, Jc (B,1,n), Jcdot qd (B,1)."""
    r = k["p"] - C_S
    rho = np.linalg.norm(r, axis=1)
    nh = r / rho[:, None]
    c = rho - (R_S + delta)
    Jc = np.einsum("bi,bij->bj", nh, k["Jv"])[:, None, :]
    pd = k["pd"]
    pn = np.sum(nh * pd, axis=1)
    jcd = np.sum(nh * k["jdv"], axis=1) + (np.sum(pd * pd, axis=1) - pn ** 2) / rho
    return c[:, None], Jc, jcd[:, None], nh


def orientation(k):
    """Virtual rows: e (B,2), Jv (B,2,n), Jvdot qd (B,2)."""
    zt, w = k["zt"], k["w"]
    e = np.stack([zt[:, 0], zt[:, 1]], 1)
    ax = np.cross(zt, EX)
    ay = np.cross(zt, EY)
    J = np.stack([np.einsum("bi,bij->bj", ax, k["Jw"]), np.einsum("bi,bij->bj", ay, k["Jw"])], 1)
    ztd = np.cross(w, zt)
    jd = np.stack([np.sum(np.cross(ztd, EX) * w, 1) + np.sum(ax * k["jdw"], 1),
                   np.sum(np.cross(ztd, EY) * w, 1) + np.sum(ay * k["jdw"], 1)], 1)
    return e, J, jd


def ik_on_surface(chain, p_target, q_init, iters=200):
    """Pen tip at p_target with the pen axis vertical (damped least squares)."""
    q = q_init.copy()[None, :]
    for _ in range(iters):
        k = kin(chain, q, np.zeros_like(q))
        err = np.concatenate([k["p"][0] - p_target, k["zt"][0] - np.array([0.0, 0.0, -1.0])])
        J = np.concatenate([k["Jv"][0], -np.cross(k["zt"][0][None, :].repeat(7, 0), k["Jw"][0].T).T], 0)
        dq = -J.T @ np.linalg.solve(J @ J.T + 1e-6 * np.eye(6), err)
        q = q + dq[None, :]
        if np.linalg.norm(err) < 1e-12:
            break
    return q[0]
