"""Distribution of the 1-ms deviation of the realized tray acceleration from the model (oracle, h = 0.14 m,
seed 0, settled periods only) and of the instantaneous centre of pressure; writes results/waiter_inst_diag.json."""
import json
import sys, numpy as np, warnings
warnings.filterwarnings("ignore")
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1])); sys.path.insert(0, str(Path(__file__).resolve().parent))
import waiter_exp as X
from umppi import waiter as WT
orig = WT.WaiterPhysics.step
rec = {"s": [], "t": [], "cop": []}
def step(self, a, T):
    tilts, meas = orig(self, a, T)
    rec["s"].append(meas["s_inst"].copy()); rec["t"].append(self.d.time); rec["cop"].append(meas["cop_true_inst"])
    return tilts, meas
WT.WaiterPhysics.step = step
# rerun the controller loop but keep s_cmd per period: wrap the plan of the default controller
cmds = []
def factory(task):
    ctrl = X.default_controller(task)
    orig_plan = ctrl.plan
    def plan(q0, qd0, t_now):
        out = orig_plan(q0, qd0, t_now); K0 = task.kin(q0[None], qd0[None])
        cmds.append((K0["Jv"][0] @ out["a"] + K0["jdv"][0] - WT.G, -K0["zt"][0])); return out
    ctrl.plan = plan
    return ctrl
r, log = X.run("oracle", 0, 0.14, controller_factory=factory)
dev, devf = [], []
for (s_cmd, n0), S, tt in zip(cmds, rec["s"], rec["t"]):
    if tt < X.T_SETTLE + X.DT:
        continue
    d = S - s_cmd; devf.append(np.linalg.norm(d, axis=1)); d = d - np.outer(d @ n0, n0); dev.append(np.linalg.norm(d, axis=1))
dev, devf = np.concatenate(dev), np.concatenate(devf); margin = (1 - WT.C8) * WT.R_BASE * 9.81 / 0.14
eps = X.EPS_EXEC  # the tightening of the rows: the pointwise statement (a) needs |deviation| <= eps at every substep
print(f"1-ms tangential deviation / margin: median {np.median(dev)/margin:.2f}  p90 {np.percentile(dev,90)/margin:.2f}  p99 {np.percentile(dev,99)/margin:.2f}  p99.9 {np.percentile(dev,99.9)/margin:.2f}  max {dev.max()/margin:.1f}")
print(f"fraction of substeps above the margin: {np.mean(dev > margin):.4f}   (n = {dev.size})")
cop = np.array([c for c, tt in zip(rec["cop"], rec["t"]) if tt >= X.T_SETTLE + X.DT]); print(f"periods whose max instantaneous COP >= 0.999: {np.mean(cop >= 0.999):.3f} of {cop.size}")

out = dict(median=float(np.median(dev) / margin), p90=float(np.percentile(dev, 90) / margin), p99=float(np.percentile(dev, 99) / margin),
           max=float(dev.max() / margin), frac_above=float(np.mean(dev > margin)), frac_periods_edge=float(np.mean(cop >= 0.999)), n=int(dev.size),
           eps=float(eps), eps_median=float(np.median(devf) / eps), eps_p99=float(np.percentile(devf, 99) / eps),
           eps_max=float(devf.max() / eps), eps_frac_above=float(np.mean(devf > eps)))
(Path(__file__).resolve().parent / "results" / "waiter_inst_diag.json").write_text(json.dumps(out, indent=1))
print(out)
