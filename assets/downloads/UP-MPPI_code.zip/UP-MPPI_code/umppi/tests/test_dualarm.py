"""Dual-arm rows: Jacobians and Jdot qd against finite differences; IK consistency."""
import numpy as np

from umppi import dualarm as DA

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])


def main():
    arms = DA.make_arms()
    q0 = DA.ik_pair(arms, np.array([0.50, 0.0, 0.30]), np.concatenate([Q_READY, Q_READY]))
    grasp = DA.grasp_from(arms, q0)
    rng = np.random.default_rng(0)
    worst = dict(c0=0.0, J=0.0, jd=0.0, Jt=0.0, jdt=0.0)
    K0 = DA.kin_pair(arms, q0[None], np.zeros((1, 14)))
    worst["c0"] = float(np.max(np.abs(DA.chain_rows(K0, grasp)[0])))
    for _ in range(10):
        # stay on the chain manifold (exact Jacobian holds at e_R = 0): perturb then project the velocity
        q = q0.copy()
        K = DA.kin_pair(arms, q[None], np.zeros((1, 14)))
        c, J, _ = DA.chain_rows(K, grasp)
        qd = rng.normal(0, 0.3, 14)  # generic direction: the Jacobian is exact at e_R = 0 for any qd
        eps = 1e-6
        Kp = DA.kin_pair(arms, (q + eps * qd)[None], qd[None])
        Km = DA.kin_pair(arms, (q - eps * qd)[None], qd[None])
        cp, Jp, _ = DA.chain_rows(Kp, grasp)
        cm, Jm, _ = DA.chain_rows(Km, grasp)
        Kq = DA.kin_pair(arms, q[None], qd[None])
        _, Jq, jdq = DA.chain_rows(Kq, grasp)
        worst["J"] = max(worst["J"], np.max(np.abs((cp - cm)[0] / (2 * eps) - Jq[0] @ qd)))
        worst["jd"] = max(worst["jd"], np.max(np.abs(((Jp - Jm)[0] / (2 * eps)) @ qd - jdq[0])))
        ep, Jtp, _ = DA.tilt_rows(Kp)
        em, Jtm, _ = DA.tilt_rows(Km)
        _, Jt, jdt = DA.tilt_rows(Kq)
        worst["Jt"] = max(worst["Jt"], np.max(np.abs((ep - em)[0] / (2 * eps) - Jt[0] @ qd)))
        worst["jdt"] = max(worst["jdt"], np.max(np.abs(((Jtp - Jtm)[0] / (2 * eps)) @ qd - jdt[0])))
    ok = worst["c0"] < 1e-10 and all(worst[k] < 1e-6 for k in ("J", "jd", "Jt", "jdt"))
    for k, v in worst.items():
        print(f"  {k:4s} {v:.2e}")
    print("PASS" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    main()
