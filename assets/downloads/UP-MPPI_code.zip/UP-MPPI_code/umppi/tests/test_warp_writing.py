"""The Warp writing controllers (separable and joint) against controllers.CAMPMPPI, same noise,
and the timing comparison of the two solvers on GPU and in numpy.
Run from the repo root: python -m umppi.tests.test_warp_writing
"""
import time

import numpy as np

from umppi import writing as W_
from umppi.controllers import CAMPMPPI, _weights
from umppi.robot import Chain
from umppi.warp_writing import WarpWritingMPPI

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])
O2 = dict(dt=0.01, H=15, sigma=0.8, w_p=1e5, w_T=1e4, w_v=5.0)


def numpy_plan(ctrl, q0, qd0, t_now, eps):
    """The loop of CAMPMPPI.plan, returning the samples."""
    K, H, n, dt = ctrl.K, ctrl.H, ctrl.n, ctrl.dt
    tgt = ctrl._targets(t_now)
    q, qd = np.repeat(q0[None], K, 0), np.repeat(qd0[None], K, 0)
    S, Ap = np.zeros(K), np.empty((K, H, n))
    for t in range(H):
        mdl = ctrl._model(q, qd)
        a = ctrl._pi(q, qd, ctrl.U[t][None] + eps[:, t], mdl)
        qdd = np.einsum("bij,bj->bi", mdl["F"], a) + mdl["f"]
        lam = -np.einsum("bij,bj->bi", mdl["Lam"], np.einsum("bij,bj->bi", mdl["Jc"], a) + mdl["jcd"])[:, 0]
        qd = qd + dt * qdd
        q = q + dt * qd
        Ap[:, t] = a
        p = ctrl.chain.tool_pose(q)[1]
        run = ctrl.w_p * np.sum((p - tgt[t]) ** 2, 1) + ctrl.w_v * np.sum(qd * qd, 1)
        run += ctrl.w_q * np.sum((q - ctrl.q_ref) ** 2, 1) + ctrl.w_f * (lam - W_.LAM_NOM) ** 2
        S += run * dt
    S += ctrl.w_T * np.sum((p - tgt[-1]) ** 2, 1)
    w = _weights(S, ctrl.eta)
    return Ap, S, w, np.einsum("k,kti->ti", w, Ap)


def main(K=256, seed=0):
    ch = Chain()
    q0 = W_.ik_on_surface(ch, W_.path_point(0.0)[0], Q_READY)
    qd0 = np.array([0.02, -0.05, 0.03, 0.06, -0.02, 0.05, 0.01])
    rng = np.random.default_rng(seed)
    eps = 0.8 * rng.standard_normal((K, 15, 7))
    ok = True
    t_np = {}
    for solver in ("separable", "joint"):
        ref = CAMPMPPI(ch, metric="M", solver=solver, virtual="hard", K=K, **O2)
        ref.q_ref = q0.copy()
        t0 = time.perf_counter()
        Ap, S, w, As = numpy_plan(ref, q0, qd0, 1.0, eps)
        t_np[solver] = time.perf_counter() - t0
        gpu = WarpWritingMPPI(ch, solver=solver, K=K)
        gpu.q_ref = q0.astype(np.float32)
        out = gpu.plan(q0, qd0, 1.0, eps=eps, return_samples=True)
        scale = np.max(np.abs(Ap)) + 1e-12
        e0 = np.max(np.abs(out["A"][:, 0] - Ap[:, 0]))
        eall = np.abs(out["A"] - Ap)
        print(f"[{solver}] step-0 max |dA| {e0:.2e} (scale {scale:.1f});  all steps median {np.median(eall):.1e}, "
              f"99th pct {np.percentile(eall, 99):.1e}, max {eall.max():.1e};  cost rel {np.max(np.abs(out['S'] - S) / np.abs(S)):.1e};  "
              f"command |da| {np.max(np.abs(out['a'] - As[0])):.1e};  relaxed {gpu.stats['relaxed']}")
        ok &= e0 / scale < 1e-3 and np.percentile(eall, 99) / scale < 1e-2
    print(f"numpy plan K={K}: separable {1e3 * t_np['separable']:.0f} ms, joint {1e3 * t_np['joint']:.0f} ms")
    for Kt in (256, 1024, 4096):
        res = {}
        for solver in ("separable", "joint"):
            g = WarpWritingMPPI(ch, solver=solver, K=Kt)
            g.plan(q0, qd0, 1.0)
            ts = []
            for _ in range(20):
                t0 = time.perf_counter()
                g.plan(q0, qd0, 1.0)
                ts.append(time.perf_counter() - t0)
            res[solver] = 1e3 * np.median(ts)
        print(f"GPU plan K={Kt:5d}: separable {res['separable']:.2f} ms, joint {res['joint']:.2f} ms")
    ok = raw_check(ch, q0, qd0, K) and ok
    print("PASS" if ok else "FAIL")
    return ok


def raw_check(ch, q0, qd0, K, seed=3):
    """Algorithm 1 as run in the experiments: raw average, noise truncated at 3 sigma, the executed command
    projected once; two consecutive plans from the same state with the same numpy draws.  The commanded
    reaction of the GPU command must lie in the band."""
    ok = True
    for solver in ("separable", "joint"):
        ref = CAMPMPPI(ch, metric="M", solver=solver, virtual="hard", K=K, average="raw", noise_clip=3.0, **O2)
        gpu = WarpWritingMPPI(ch, solver=solver, K=K, average="raw", noise_clip=3.0)
        ref.q_ref, gpu.q_ref = q0.copy(), q0.astype(np.float32)
        ref.rng, gpu.rng = np.random.default_rng(seed), np.random.default_rng(seed)
        for i in range(2):
            o_r, o_g = ref.plan(q0, qd0, 1.0), gpu.plan(q0, qd0, 1.0)
            da = np.max(np.abs(o_g["a"] - o_r["a"]))
            lo, hi = W_.LAM_BAND
            print(f"[{solver}] raw average, plan {i + 1}: executed |da| = {da:.2e} (|a| = {np.max(np.abs(o_r['a'])):.2f}), "
                  f"nominal |dU| = {np.max(np.abs(gpu.U - ref.U)):.2e}, commanded reaction {o_g['lam_cmd']:.3f} N (band [{lo}, {hi}])")
            ok = ok and da / (np.max(np.abs(o_r["a"])) + 1e-12) < 1e-3 and lo - 1e-4 <= o_g["lam_cmd"] <= hi + 1e-4
    return ok


if __name__ == "__main__":
    main()
