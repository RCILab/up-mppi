# Additional analyses outside the current simulation manuscript

The current manuscript reports numerical checks, simulation results, and computation benchmarks.
Unmeasured hardware outcomes and the former red claims have been removed. The tasks below are
future analyses, not evidence supporting completed experiments in this version. See
[HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md) for the student handoff and [HARDWARE.md](HARDWARE.md)
for the detailed waiter protocol.

| # | Question for future physical measurements | Analysis to perform |
|---|---|---|
| 1 | Does the contact load of PR-MPPI on hardware vary with surface-model offset as Prop. 2(b) predicts? | If the original CAMP writing logs contain the required measurements, compute the local surface-model offset δ at the contact point and the measured normal force. Regress force on δ over the contact phase. Compare the slope with (Λ_K⁻¹ + k_env⁻¹)⁻¹, using the actual loop stiffness, reference interpolation, and measured pen/board compliance. Report the available trial count, slope, fit error, R², and predicted value. If the signals are unavailable, collect them in the planned writing experiment. |

The simulated writing task already tests the force-offset relation. Agreement in simulation does
not establish that the same relation was measured on a physical robot; analysis #1 is separate future work.

Additional diagnostics (not completed result claims):

- CAMP rollout drift: log ‖c(q)‖ at the end of the horizon for CAMP-MPPI rollouts (writing task) to quantify the O(T_h Δt) off-manifold drift of Prop. 5 on the real parameters.
- Execution-only vs Full PR-MPPI: log the online clipped-heterogeneity mass w(𝒟) of Prop. 6(b) during the obstacle trials; it should be largest at the placements where the execution-only ablation stalls.

Section "Simulation: dual-arm closed chain" contains no red text; its numbers come from `experiments/dualarm_exp.py` via `fill_dualarm_section.py`.

Section "Certified wrench constraints under model uncertainty": simulation numbers come from
`experiments/waiter_exp.py` via `report_waiter.py`. The unmeasured hardware paragraph has been removed
from both the rendered section and `experiments/robust_section.tex.in`, so regeneration does not restore it.

Future physical results need their own setup, raw data, analysis and findings. Keep simulation and
hardware provenance distinct, and rewrite conclusions from the observed outcomes.
