"""Unified projection MPPI: PR-MPPI (order 1), CAMP-MPPI (order 2) and the unified controller."""
