"""Timing of the GPU controllers (NVIDIA Warp) against the numpy reference, for the note.

Waiter task (robust rows, H = 20, dt = 20 ms) and writing task (separable and joint solvers,
H = 15, dt = 10 ms).  Per configuration: 10 warm-up plans, then 3 rounds of 50 plans; the reported
value is the smallest round median (robust to background load on a shared machine).  Kernel time is
measured in a separate pass with device synchronisation around the launch.  numpy: median of 3 plans.
Writes results/gpu_timing.json.
"""
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from umppi import waiter as WT  # noqa: E402
from umppi import writing as W_  # noqa: E402
from umppi.controllers import CAMPMPPI  # noqa: E402
from umppi.generic import CAMP2  # noqa: E402
from umppi.robot import Chain  # noqa: E402
from umppi.warp_mppi import WarpWaiterMPPI  # noqa: E402
from umppi.warp_writing import WarpWritingMPPI  # noqa: E402

Q_READY = np.array([0.0, -np.pi / 4, 0.0, -3 * np.pi / 4, 0.0, np.pi / 2, np.pi / 4])
KS = (256, 1024, 4096)
O2 = dict(dt=0.01, H=15, sigma=0.8, w_p=1e5, w_T=1e4, w_v=5.0)


def bench(ctrl, q0, qd0, t_now, rounds=3, n=50):
    for _ in range(10):
        ctrl.plan(q0, qd0, t_now)
    meds = []
    for _ in range(rounds):  # the controller's own timing: the control path, without logging
        ctrl.stats["time"] = []
        for _ in range(n):
            ctrl.plan(q0, qd0, t_now)
        meds.append(np.median(ctrl.stats["time"]))
    ctrl.profile = True
    ctrl.stats["kernel"] = []
    for _ in range(n):
        ctrl.plan(q0, qd0, t_now)
    ctrl.profile = False
    return 1e3 * min(meds), 1e3 * float(np.median(ctrl.stats["kernel"]))


def bench_numpy(ctrl, q0, qd0, t_now, n=3):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        ctrl.plan(q0, qd0, t_now)
        ts.append(time.perf_counter() - t0)
    return 1e3 * float(np.median(ts))


def main():
    out = {"device": "NVIDIA GeForce RTX 4060 (8 GB)", "method": __doc__.strip().splitlines()[3:6]}
    # ---------------------------------------------------------------- waiter
    ch = WT.make_chain()
    q0 = WT.ik(ch, WT.A_PT, Q_READY)
    qd0 = np.zeros(7)
    # Algorithm 1 as in the experiments: raw average, final projection, tightened rows, truncated noise
    eps_file = Path(__file__).resolve().parent / "results" / "waiter_exec_bound.json"
    eps_exec = json.loads(eps_file.read_text())["eps_exec"] if eps_file.exists() else 0.0
    task = WT.WaiterTask(ch, [0.05, 0.18], [0.4, 0.8], q_ref=q0, dt=0.02, H=20, eps_exec=eps_exec)
    task.t_now = 0.5
    ref = CAMP2(task, sigma=1.0, solver="separable", virtual="hard", dt=0.02, H=20, K=256, average="raw", noise_clip=3.0)
    out["waiter_numpy_K256_ms"] = bench_numpy(ref, q0, qd0, 0.5)
    out["waiter_gpu"] = {}
    for K in KS:
        plan_ms, kern_ms = bench(WarpWaiterMPPI(ch, task, K=K, H=20, dt=0.02, average="raw"), q0, qd0, 0.5)
        out["waiter_gpu"][K] = {"plan_ms": plan_ms, "kernel_ms": kern_ms}
        print(f"waiter K={K}: plan {plan_ms:.2f} ms, kernel {kern_ms:.2f} ms", flush=True)
    # ---------------------------------------------------------------- writing
    chw = Chain()
    q0w = W_.ik_on_surface(chw, W_.path_point(0.0)[0], Q_READY)
    out["writing_numpy_K256_ms"] = {}
    out["writing_gpu"] = {"separable": {}, "joint": {}}
    for solver in ("separable", "joint"):
        refw = CAMPMPPI(chw, metric="M", solver=solver, virtual="hard", K=256, average="raw", noise_clip=3.0, **O2)
        out["writing_numpy_K256_ms"][solver] = bench_numpy(refw, q0w, np.zeros(7), 1.0)
        for K in KS:
            plan_ms, kern_ms = bench(WarpWritingMPPI(chw, solver=solver, K=K, average="raw"), q0w, np.zeros(7), 1.0)
            out["writing_gpu"][solver][K] = {"plan_ms": plan_ms, "kernel_ms": kern_ms}
            print(f"writing {solver} K={K}: plan {plan_ms:.2f} ms, kernel {kern_ms:.2f} ms", flush=True)
    print("numpy K=256:", out["waiter_numpy_K256_ms"], out["writing_numpy_K256_ms"])
    (Path(__file__).resolve().parent / "results" / "gpu_timing.json").write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
