"""Baselines and the averaging ablation -> tier2/baselines_section.tex.

Reads the unified controller of Algorithm 1 (waiter.json), the baselines of waiter_baselines.py (default
run, omega sweep, h sweep, tightened penalty), the averaging ablation (--ablation), the execution-error
bound (waiter_exec_bound.json) and the writing baselines (writing_baselines.json).  All waiter runs use the
GPU controller with the same clipped numpy noise draws.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from umppi import waiter as WT  # noqa: E402

RES = HERE / "results"
OUT = HERE.parent / "tier2" / "baselines_section.tex"
H_ALL = (0.08, 0.11, 0.14, 0.17)
H_MAIN = 0.14
GS1 = "gs@rho=20@iters=1"  # GS-MPPI as published (one application of the safe law), the rho of the smaller violation


def load(name):
    return [r for r in json.loads((RES / name).read_text())["rows"] if "error" not in r]


def group(rows, key):
    g = defaultdict(list)
    for r in rows:
        g[key(r)].append(r)
    return g


def label(r):
    w = r.get("w_s")
    return r["controller"] + (f"@{w:.0e}" if w else "")


W = defaultdict(list)  # (label, h) -> runs
for name in ("waiter.json", "waiter_baselines.json", "waiter_baselines_sweep.json", "waiter_baselines_ablation.json",
             "waiter_baselines_rawavg_tight_penalty.json"):
    for r in load(name):
        W[(label(r), r["h_true"])].append(r)
OMEGA = {r["omega"]: r for r in load("waiter_baselines_omega.json") if r["seed"] == 0}
EPS = json.loads((RES / "waiter_exec_bound.json").read_text())
WRT = load("writing_baselines.json")


def stats(lab, h=H_MAIN):
    rs = W[(lab, h)]
    assert rs, (lab, h)
    safe = [r for r in rs if not r["tipped"]]
    f = lambda k: float(np.mean([r[k] for r in safe])) if safe else None  # noqa: E731
    return dict(n=len(rs), tip=sum(r["tipped"] for r in rs), r1=f("rmse1"), r2=f("rmse2"),
                oct=max(r["oct_model_max"] for r in rs), cop=max(r["cop_true_max"] for r in rs))


def best(prefix, weights):
    """Weight with the smallest move-1 error among those without a tip at the main height."""
    ok = [(stats(f"{prefix}@{w:.0e}")["r1"], w) for w in weights if stats(f"{prefix}@{w:.0e}")["tip"] == 0]
    return min(ok)[1]


def fmt(x, d=1):
    return "--" if x is None else f"{x:.{d}f}"


def texw(w):
    return f"10^{int(round(np.log10(w)))}"


W_A1 = best("penalty", (1e3, 1e4, 1e5, 1e6))
W_A2 = best("penalty-exec", (1e3, 1e4, 1e5, 1e6))
W_A2T = best("penalty-exec-tight", (1e3, 1e4, 1e5))
TUNED = {"penalty": 1e5, "penalty-exec": 1e4, "penalty-exec-tight": 1e5}  # the weights of the h sweep
for k_, w_ in (("penalty", W_A1), ("penalty-exec", W_A2), ("penalty-exec-tight", W_A2T)):
    if TUNED[k_] != w_:
        print(f"WARNING: best weight of {k_} at h = {H_MAIN} is {w_:.0e}, the h sweep used {TUNED[k_]:.0e}")

ROWS = [
    (r"\multicolumn{6}{@{}l}{\emph{Unified controller, Algorithm~\ref{alg:unified}}}", None),
    ("Robust", "robust"),
    ("Adaptive, COP differences", "adaptive-cop"),
    ("Adaptive, box tracked", "adaptive-tracked"),
    ("Oracle", "oracle"),
    (r"\multicolumn{6}{@{}l}{\emph{Baselines}}", None),
    (r"Nominal ($h=0.07$\,m)", "nominal"),
    (rf"A1 penalty MPPI ($w_s={texw(W_A1)}$)", f"penalty@{W_A1:.0e}"),
    (rf"A2 penalty + filter ($w_s={texw(W_A2)}$), $\varepsilon=0$", f"penalty-exec@{W_A2:.0e}"),
    (rf"A2 penalty + filter ($w_s={texw(W_A2T)}$)", f"penalty-exec-tight@{W_A2T:.0e}"),
    (r"A3 one-step QP ($\omega=6$)", "onestep"),
    (r"B1 CE, RLS from $h_0=0.115$", "adaptive-rls"),
    (r"B1 CE, RLS from $h_0=0.07$", "adaptive-rls-nom"),
    (r"\multicolumn{6}{@{}l}{\emph{Averaging ablation of the unified controller}}", None),
    (r"Robust, projected average, $\varepsilon=0$", "robust-projected"),
    ("Robust, projected average", "robust-projected-tight"),
    (r"Robust, raw average, $\varepsilon=0$", "robust-rawavg"),
    (r"Adaptive COP, projected average, $\varepsilon=0$", "adaptive-cop-projected"),
    (r"Adaptive COP, raw average, $\varepsilon=0$", "adaptive-cop-rawavg"),
    (r"Oracle, projected average, $\varepsilon=0$", "oracle-projected"),
    (r"Oracle, raw average, $\varepsilon=0$", "oracle-rawavg"),
]

SWEEP_ROWS = [
    ("Robust", "robust"),
    (r"Robust, projected average, $\varepsilon=0$", "robust-projected"),
    (r"Robust, raw average, $\varepsilon=0$", "robust-rawavg"),
    ("Adaptive, COP differences", "adaptive-cop"),
    (r"Adaptive COP, projected average, $\varepsilon=0$", "adaptive-cop-projected"),
    (rf"A1 penalty MPPI ($w_s={texw(TUNED['penalty'])}$)", f"penalty@{TUNED['penalty']:.0e}"),
    (rf"A2 penalty + filter, $\varepsilon=0$", f"penalty-exec@{TUNED['penalty-exec']:.0e}"),
    (rf"A2 penalty + filter", f"penalty-exec-tight@{TUNED['penalty-exec-tight']:.0e}"),
    (r"A3 one-step QP ($\omega=6$)", "onestep"),
    (r"B1 CE, RLS from $h_0=0.07$", "adaptive-rls-nom"),
]


def main_table():
    out = []
    for lab, key in ROWS:
        if key is None:
            out.append(lab + r" \\")
            continue
        s = stats(key)
        out.append(f"{lab} & {s['tip']}/{s['n']} & {fmt(s['r1'])} & {fmt(s['r2'])} & {s['oct']:.2f} & {s['cop']:.2f} \\\\")
    return "\n".join(out)


def sweep_table():
    out = []
    for lab, key in SWEEP_ROWS:
        cells = [f"{stats(key, h)['tip']}/{stats(key, h)['n']}, {fmt(stats(key, h)['r2'])}" for h in H_ALL]
        s17 = stats(key, 0.17)
        out.append(f"{lab} & " + " & ".join(cells) + f" & {s17['oct']:.2f} / {s17['cop']:.2f} \\\\")
    return "\n".join(out)


def writing_table():
    g = group(WRT, lambda r: (r["controller"], r.get("w_s") or 0.0))
    order = [(r"Unified, Algorithm~\ref{alg:unified} (GPU)", ("unified-gpu", 0.0)), (r"A3 one-step QP", ("onestep", 0.0))]
    order += [(rf"A1 penalty MPPI ($w_s={w:g}$)", ("penalty", w)) for w in (1.0, 10.0, 100.0, 1000.0)]
    order += [(rf"A2 penalty + filter ($w_s={w:g}$)", ("penalty-exec", w)) for w in (1.0, 10.0, 100.0, 1000.0)]
    out = []
    for lab, k in order:
        rs = g[k]
        m = lambda key: float(np.mean([r[key] for r in rs]))  # noqa: E731
        lo, hi = min(r["lam_cmd_range"][0] for r in rs), max(r["lam_cmd_range"][1] for r in rs)
        stop = sum(r["diverged_t"] is not None for r in rs)
        out.append(f"{lab} & {m('track_rmse_mm'):.2f} & {m('force_mean'):.2f} $\\pm$ {m('force_std'):.2f} & "
                   f"{100 * m('in_band'):.1f} & {lo:.2f}--{hi:.2f} & {stop}/{len(rs)} \\\\")
    for lab, rs in safe_writing_best().items():
        m = lambda key: float(np.mean([r[key] for r in rs]))  # noqa: E731
        lo, hi = min(r["lam_cmd_range"][0] for r in rs), max(r["lam_cmd_range"][1] for r in rs)
        stop = sum(r["diverged_t"] is not None for r in rs)
        out.append(f"{lab} & {m('track_rmse_mm'):.2f} & {m('force_mean'):.2f} $\\pm$ {m('force_std'):.2f} & "
                   f"{100 * m('in_band'):.1f} & {lo:.2f}--{hi:.2f} & {stop}/{len(rs)} \\\\")
    return "\n".join(out)


def safe_writing_best():
    """Per safe-MPPI method on the writing task, the variant with the largest in-band share (then the best tracking)."""
    f = RES / "safe_writing.json"
    if not f.exists():
        return {}
    g = defaultdict(list)
    for r in json.loads(f.read_text())["rows"]:
        if "error" not in r:
            g[r["label"]].append(r)
    names = {"shield": "Shield-MPPI", "dualguard": "DualGuard MPPI", "gs": "GS-MPPI"}
    out = {}
    for meth, name in names.items():  # every variant, as for the penalty baselines (the weight trades band for tracking)
        cands = sorted([(lab, rs) for lab, rs in g.items() if lab.split("@")[0] == meth],
                       key=lambda c: float(c[0].split("=")[1]) if "=" in c[0] else 0.0)
        for lab, rs in cands:
            prm = lab.split("@", 1)[1] if "@" in lab else ""
            prm = ("$" + prm.replace("rho=", "\\rho=") + "$") if prm else ""
            out[f"{name}{' (' + prm + ')' if prm else ''}"] = rs
    return out


def a_ref():
    t = np.linspace(0.0, WT.T_RUN, 20001)
    return float(np.max(np.linalg.norm(WT.target_acc(t), axis=1)))


def num():
    s = stats
    gw = group(WRT, lambda r: (r["controller"], r.get("w_s") or 0.0))
    wm = lambda k, key: float(np.mean([r[key] for r in gw[k]]))  # noqa: E731
    a2 = {w: s(f"penalty-exec@{w:.0e}")["r1"] for w in (1e3, 1e4, 1e5, 1e6)}
    a2t = {w: s(f"penalty-exec-tight@{w:.0e}")["r1"] for w in (1e3, 1e4, 1e5)}
    cert = ("robust", "adaptive-cop", "adaptive-tracked", "oracle")
    pen_w = sorted(w for w in (1e3, 1e4, 1e5, 1e6))
    a1_17 = s(f"penalty@{TUNED['penalty']:.0e}", 0.17)
    d = {
        "EPS": f"{EPS['eps_exec']:.3f}",
        "OS_OMEGAS": ", ".join(f"{w:g}" for w in sorted(OMEGA)),
        # A1
        "A1_TIPS": "; ".join(f"{s(f'penalty@{w:.0e}')['tip']}/{s(f'penalty@{w:.0e}')['n']} with $w_s={texw(w)}$" for w in pen_w),
        "A1_W": texw(W_A1), "A1_R1": fmt(s(f"penalty@{W_A1:.0e}")["r1"]),
        "A1_OCT17": f"{a1_17['oct']:.2f}", "A1_COP17": f"{a1_17['cop']:.2f}",
        "ROB_OCT17": f"{s('robust', 0.17)['oct']:.2f}", "ROB_COP17": f"{s('robust', 0.17)['cop']:.2f}",
        # averaging
        "RP_R1": fmt(s("robust-projected")["r1"]), "RR_R1": fmt(s("robust-rawavg")["r1"]),
        "ROB_R1": fmt(s("robust")["r1"]), "RPT_R1": fmt(s("robust-projected-tight")["r1"]),
        "RP_COP": f"{max(s('robust-projected', h)['cop'] for h in H_ALL):.2f}",
        "RR_COP17": f"{s('robust-rawavg', 0.17)['cop']:.2f}", "RR_OCT17": f"{s('robust-rawavg', 0.17)['oct']:.2f}",
        "ORR_COP": f"{max(s('oracle-rawavg', h)['cop'] for h in H_ALL):.2f}",
        "OR_R1": fmt(s("oracle-rawavg")["r1"]), "OP_R1": fmt(s("oracle-projected")["r1"]), "ORA_R1": fmt(s("oracle")["r1"]),
        "CERT_COP": f"{max(max(s(k, h)['cop'] for h in H_ALL) for k in cert):.2f}",
        "ROB_COP": f"{max(s('robust', h)['cop'] for h in H_ALL):.2f}",
        "GAIN": f"{100 * (1 - s('robust')['r1'] / s('robust-projected')['r1']):.0f}",
        "AC_R2": fmt(s("adaptive-cop")["r2"]), "ACP_R2": fmt(s("adaptive-cop-projected")["r2"]), "ROB_R2": fmt(s("robust")["r2"]),
        # A2
        "A2_W": texw(W_A2), "A2_R1": fmt(a2[W_A2]), "A2_RANGE": f"{min(a2.values()):.1f}--{max(a2.values()):.1f}",
        "A2T_W": texw(W_A2T), "A2T_R1": fmt(a2t[W_A2T]), "A2T_RANGE": f"{min(a2t.values()):.1f}--{max(a2t.values()):.1f}",
        "A2T_GAP": f"{100 * (1 - s('robust')['r1'] / a2t[W_A2T]):.0f}",
        "A2_GAP": f"{100 * (1 - s('robust-rawavg')['r1'] / a2[W_A2]):.0f}",
        # A3
        "OS_R1": fmt(s("onestep")["r1"]), "OS15_TIP": f"{OMEGA[15.0]['t_tip']:.2f}",
        "A_REF": f"{a_ref():.2f}", "A_ADM": f"{np.linalg.norm(WT.G) * WT.R_BASE * WT.C8 / 0.08:.2f}",
        # B1
        "RLS_R1": fmt(s("adaptive-rls")["r1"]), "RLSN_R1": fmt(s("adaptive-rls-nom")["r1"]),
        "RLS_GAP": f"{max(s('adaptive-rls')['r1'], s('adaptive-rls-nom')['r1']) - s('oracle')['r1']:.1f}",
        "RLS_R2": fmt(max(s("adaptive-rls")["r2"], s("adaptive-rls-nom")["r2"])),
        "RLSN_OCT": f"{max(s('adaptive-rls-nom', h)['oct'] for h in H_ALL):.2f}",
        "RLSN_R2_17": fmt(s("adaptive-rls-nom", 0.17)["r2"]), "ORA_R2_17": fmt(s("oracle", 0.17)["r2"]),
        "RLS_TIPS": f"{sum(s(k, h)['tip'] for k in ('adaptive-rls', 'adaptive-rls-nom') for h in H_ALL if W[(k, h)])}",
        "RLS_N": f"{sum(s(k, h)['n'] for k in ('adaptive-rls', 'adaptive-rls-nom') for h in H_ALL if W[(k, h)])}",
        # writing
        "W_UNI": f"{wm(('unified-gpu', 0.0), 'track_rmse_mm'):.2f}", "W_OS": f"{wm(('onestep', 0.0), 'track_rmse_mm'):.2f}",
        "W_UNI_BAND": f"{100 * wm(('unified-gpu', 0.0), 'in_band'):.1f}", "W_OS_BAND": f"{100 * wm(('onestep', 0.0), 'in_band'):.1f}",
        "W_P1": f"{wm(('penalty', 1.0), 'track_rmse_mm'):.1f}", "W_P1000": f"{wm(('penalty', 1000.0), 'track_rmse_mm'):.1f}",
        "W_P_BAND": f"{100 * min(wm(('penalty', w), 'in_band') for w in (1.0, 10.0, 100.0, 1000.0)):.0f}--"
                    f"{100 * max(wm(('penalty', w), 'in_band') for w in (1.0, 10.0, 100.0, 1000.0)):.0f}",
        "W_LAM_LO": f"{min(r['lam_cmd_range'][0] for r in WRT if r['controller'] == 'penalty'):.2f}",
    }
    stopped = {w: [r["diverged_t"] for r in gw[("penalty", w)] if r["diverged_t"] is not None] for w in (1.0, 10.0, 100.0, 1000.0)}
    ws = [w for w in stopped if stopped[w]]
    d["W_STOP"] = ("no run left the path" if not ws else
                   "; ".join(f"{len(stopped[w])} of {len(gw[('penalty', w)])} runs at $w_s={w:g}$ were stopped between "
                             f"$t={min(stopped[w]):.1f}$ and {max(stopped[w]):.1f}\\,s" for w in ws)
                   + ", when the error passed 10\\,cm")
    return d


TEMPLATE = r"""\section{Baselines and the averaging ablation}
\label{sec:baselines}

Four baselines share the model, the rows that they keep, the sample count, the horizon and the clipped noise draws of Algorithm~\ref{alg:unified}.
A1 is penalty MPPI: the robust support rows (on the waiter) or the reaction band (in writing) become a cost $w_s\sum\max(0,\cdot)^2$, the other rows stay hard, and the average is executed.
A2 is Algorithm~\ref{alg:unified} with those rows penalised instead of projected in the rollouts: the raw average is projected once onto all rows, as a safety filter would.
It is run with and without the tightening, and with the tightening its penalty acts on the tightened rows as well.
A3 is a one-step quadratic program in the manner of task-space inverse dynamics.
It tracks a PD law in task space with the same hard rows in the metric of its objective, and has no horizon.
B1 is certainty equivalence: Algorithm~\ref{alg:unified} with the point estimate of $h$ from recursive least squares on $(m,mh,md)$ over the same F/T windows, started from the middle of the prior or from the nominal $h=0.07$\,m.
The weight $w_s$ was swept over $\{10^3,\dots,10^6\}$ on the waiter and over $\{1,\dots,10^3\}$ in writing, and the gain $\omega$ of A3 over $\{@@OS_OMEGAS@@\}$\,rad/s.
Each baseline is reported at its best value at $h=0.14$\,m, which is then kept for the other heights.
The ablation runs the unified controller with the average of the earlier controllers (the projected samples) and with the raw average, each with and without the tightening $\varepsilon=@@EPS@@$\,m/s$^2$ of Section~\ref{sec:robust}.

\begin{table}[h]
\centering
\caption{Waiter task, true $h=0.14$\,m, 5 seeds: tipped runs, tracking error of each move over the safe runs, the largest octagon ratio of the model wrench under the true parameters (above one: the rows of the true box are violated by the command), and the largest period-averaged COP ratio of the real box (one: the box is on its edge).  Rows without $\varepsilon=0$ are tightened by $\varepsilon=@@EPS@@$\,m/s$^2$.}
\label{tab:baselines}
\footnotesize
\begin{tabularx}{\linewidth}{l Y Y Y Y Y}
\toprule
Controller & Tipped & \multicolumn{2}{c}{RMSE [mm]} & Model & True \\
\cmidrule(lr){3-4}
 & & move 1 & move 2 & row ratio & COP ratio \\
\midrule
@@MAIN@@
\bottomrule
\end{tabularx}
\end{table}

\begin{table}[h]
\centering
\caption{Sweep over the true height: tipped runs and the tracking error of move~2 [mm] over the safe runs; the last column gives the model row ratio and the true COP ratio at $h=0.17$\,m.}
\label{tab:baselines_sweep}
\footnotesize
\begin{tabularx}{\linewidth}{l Y Y Y Y Y}
\toprule
Controller & $h=0.08$ & $h=0.11$ & $h=0.14$ & $h=0.17$ & Ratios \\
\midrule
@@SWEEP@@
\bottomrule
\end{tabularx}
\end{table}

\paragraph{Hard rows against a penalty.}
Penalty MPPI is as safe as its weight.
At $h=0.14$\,m it tipped the box in @@A1_TIPS@@.
The best weight, $@@A1_W@@$, tracked at @@A1_R1@@\,mm, but at $h=0.17$\,m, near the top of the prior where the robust rows are nearly the true ones, its commands exceeded the true rows (model ratio @@A1_OCT17@@) and the box reached a COP ratio of @@A1_COP17@@.
The robust rows of Algorithm~\ref{alg:unified} stayed at @@ROB_OCT17@@ and @@ROB_COP17@@ there, as the certificate of Proposition~\ref{prop:certificate} requires.

\paragraph{The average, and where the margin belongs.}
With the average of the earlier controllers and no tightening, the robust controller tracked at @@RP_R1@@\,mm and the box stayed below a COP ratio of @@RP_COP@@.
Averaging the raw inputs instead and projecting once, still without tightening, gave @@RR_R1@@\,mm, but with the command on the robust bound (model ratio @@RR_OCT17@@ at $h=0.17$\,m) the real box reached @@RR_COP17@@, and the oracle with the raw average put its box on the edge (@@ORR_COP@@).
The distortion of the projected average (Proposition~\ref{prop:avg}(b)) had kept the command off the binding rows, and that interior margin had absorbed the execution error without any statement about its size.
Algorithm~\ref{alg:unified} moves the margin into the rows: with the raw average and the tightening it tracked at @@ROB_R1@@\,mm, @@GAIN@@\,\% better than the earlier average, and no certified controller exceeded a true COP ratio of @@CERT_COP@@ at any height (the robust one @@ROB_COP@@).
Tightening the projected average instead stacks the two margins and costs speed (@@RPT_R1@@\,mm).
Adaptation keeps its gain: with COP differences, move~2 took @@AC_R2@@\,mm against @@ROB_R2@@\,mm for the robust controller and @@ACP_R2@@\,mm with the earlier average.
The oracle went from @@OP_R1@@ to @@ORA_R1@@\,mm, and to @@OR_R1@@\,mm with neither margin.

\paragraph{Projection inside the rollouts, at equal certificates.}
A2 shares everything with Algorithm~\ref{alg:unified} except that its rollouts penalise the support rows.
With the same tightened rows in its cost and its filter it tracked at @@A2T_R1@@\,mm at best ($w_s=@@A2T_W@@$; @@A2T_RANGE@@\,mm over the sweep), @@A2T_GAP@@\,\% worse than Algorithm~\ref{alg:unified}, because its rollouts are scored on commands that the filter then changes.
Without tightening A2 lost by a similar fraction, @@A2_GAP@@\,\% (@@A2_R1@@\,mm at $w_s=@@A2_W@@$ against @@RR_R1@@\,mm; @@A2_RANGE@@\,mm over the sweep).

\paragraph{The horizon.}
Without a horizon, A3 with the gain of the other controllers ($\omega=15$\,rad/s) accelerated at the rows' limit, could not brake in time, overshot the goal by up to 0.2\,m and tipped the box at $t=@@OS15_TIP@@$\,s after its velocity rows saturated.
Its best gain gave @@OS_R1@@\,mm.
The reference asks for up to @@A_REF@@\,m/s$^2$, more than the rows admit at any height of the sweep (at most @@A_ADM@@\,m/s$^2$ at $h=0.08$\,m, before tightening), so the braking must be planned.
In writing, where the rows are not active on the time scale of the horizon, the same kind of controller tracked better than MPPI (Table~\ref{tab:baselines_writing}).

\paragraph{Certainty equivalence.}
With the same rows and tightening, the RLS estimate came within @@RLS_GAP@@\,mm of the oracle from either prior (@@RLS_R1@@ and @@RLSN_R1@@\,mm at $h=0.14$\,m, against @@ORA_R1@@\,mm; move~2 at $h=0.17$\,m @@RLSN_R2_17@@ against @@ORA_R2_17@@\,mm) and tipped the box in @@RLS_TIPS@@ of @@RLS_N@@ runs, with a model ratio of at most @@RLSN_OCT@@, because the first move excites $h$ well before its acceleration peak.
It also tracked move~2 better than the certified COP estimator (@@RLS_R2@@ against @@AC_R2@@\,mm at $h=0.14$\,m), so in this task the certified estimator buys the guarantee at a cost in performance.
A case where certainty equivalence fails, such as a biased sensor or a poorly exciting first move, remains to be shown (open item).

\begin{table}[h]
\centering
\caption{Writing task, three seeds and three surface offsets $\delta\in\{-1,0,1\}$\,mm (the order-2 controllers do not use the position of the surface, so the offsets act as repetitions): tracking error over the executed part, contact force, share of time in the band $[2,4]$\,N, range of the commanded reaction, and runs stopped because the error passed 10\,cm.  The safe-MPPI rows (Section~\ref{sec:baselines}, last paragraph) use $\delta=0$ and three seeds.}
\label{tab:baselines_writing}
\footnotesize
\begin{tabularx}{\linewidth}{l Y Y Y Y Y}
\toprule
Controller & RMSE [mm] & Force [N] & In band [\%] & $\lambda_{\mathrm{cmd}}$ [N] & Stopped \\
\midrule
@@WRITING@@
\bottomrule
\end{tabularx}
\end{table}

\paragraph{Writing.}
With the band as a penalty, MPPI could not both track and hold the band: from $w_s=1$ to $10^3$ the error grew from @@W_P1@@ to @@W_P1000@@\,mm while the force stayed in the band only @@W_P_BAND@@\,\% of the time; @@W_STOP@@.
The normal component of the sampling noise moves the reaction of every sample by newtons, and the penalty then ranks samples by that noise instead of by tracking.
The clamp of the unified controller removes this noise from the costs, and the controller tracked at @@W_UNI@@\,mm with the force in the band @@W_UNI_BAND@@\,\% of the time.
The filter of A2 kept the commanded reaction in the band, whereas A1 commanded as little as @@W_LAM_LO@@\,N, but it did not change the tracking.
The one-step program A3 tracked better still (@@W_OS@@\,mm, @@W_OS_BAND@@\,\% in band).
The writing task tests the treatment of the reaction and of the virtual rows, and a horizon is not needed for it.
"""


SAFE_TEMPLATE = r"""
\paragraph{Safe MPPI and gradient-based MPC.}
Five further controllers were re-implemented on the same model, rows, costs, horizon and clipped noise draws (Table~\ref{tab:safe}).
Shield-MPPI~\cite{yin2023} penalises the discrete CBF condition of the joint barriers and the violation of the support rows in its rollouts and repairs the executed control by fixed-step gradient ascent over its first @@SH_N@@ steps.
DualGuard MPPI~\cite{borquez2025} passes every sample and the output through a least-restrictive filter, with the Hamilton--Jacobi value of a braking double integrator for each joint limit and zero tangential tray acceleration as the safe input for the support rows, and averages the filtered samples.
GS-MPPI~\cite{rabiee2025} composes all rows by a soft-min and applies its closed-form safe law to every sample and to the raw mean; because the support rows constrain the input directly, the composite is not affine in the input and the law is repeated until it holds.
None of the three handles equalities, so all keep the tray orientation by the equality projection of Algorithm~\ref{alg:unified}, and each was tuned at $h=0.14$\,m like the other baselines (Shield: penalty weight, GS: soft-min parameter).
The gradient-based controllers follow Heins and Schoellig~\cite{heins2025}: an offline robust trajectory optimisation over the whole run with the vertex rows softened by an L2 slack, tracked by PD feedback, and a receding-horizon robust NMPC with the cost, horizon and step of the MPPI controllers, the rows hard at the first knot and a jerk penalty.

\begin{table}[h]
\centering
\caption{Safe MPPI and gradient-based MPC on the waiter, true $h=0.14$\,m (5 seeds for the MPPI controllers; the gradient-based ones are deterministic): tipped runs, tracking error, the model row ratio and true COP ratio as in Table~\ref{tab:baselines}, and the largest period-averaged execution error of the tray acceleration.  GS-MPPI applies its safe law until the composite holds (at most five times), the one-step variant once, as published.  Upper block: rows as they are; lower block: rows tightened by $\varepsilon=@@EPS@@$\,m/s$^2$.}
\label{tab:safe}
\footnotesize
\begin{tabularx}{\linewidth}{l Y Y Y Y Y Y}
\toprule
Controller & Tipped & \multicolumn{2}{c}{RMSE [mm]} & Model & True & Exec.\ err. \\
\cmidrule(lr){3-4}
 & & move 1 & move 2 & ratio & COP & [m/s$^2$] \\
\midrule
@@SAFE_ROWS@@
\bottomrule
\end{tabularx}
\end{table}

@@SAFE_TEXT@@
"""


def safe_section():
    f_t, f_s, f_h = (RES / n for n in ("safe_baselines_tune.json", "safe_baselines_sweep.json", "heins_baselines.json"))
    if not (f_t.exists() and f_h.exists()):
        return ""
    tune = [r for r in json.loads(f_t.read_text())["rows"] if "error" not in r]
    sweep = [r for r in json.loads(f_s.read_text())["rows"] if "error" not in r] if f_s.exists() else []
    heins = [r for r in json.loads(f_h.read_text())["rows"] if "error" not in r]
    f_g1 = RES / "safe_baselines_gs1.json"  # GS-MPPI with the single application of its safe law
    gs1 = [r for r in json.loads(f_g1.read_text())["rows"] if "error" not in r] if f_g1.exists() else []
    eps_x = EPS["eps_exec"]
    tight = lambda e: e > 1e-9  # noqa: E731
    G = defaultdict(list)
    for r in tune + sweep + gs1:
        G[(r["label"], tight(r["eps"]), r["h_true"])].append(r)
    for r in heins:
        lab = "offline" if r["kind"] == "offline" else "online" + "".join(f"@{k}={v:g}" for k, v in r["params"].items())
        G[(lab, tight(r["eps"]), r["h_true"])].append(r)

    def st(rs):
        safe = [r for r in rs if not r["tipped"]]
        f = lambda k: float(np.mean([r[k] for r in safe])) if safe else None  # noqa: E731
        return dict(n=len(rs), tip=sum(r["tipped"] for r in rs), r1=f("rmse1"), r2=f("rmse2"),
                    oct=max(r["oct_model_max"] for r in rs), cop=max(r["cop_true_max"] for r in rs),
                    dev=max(r["dev_max"] for r in rs), ms=float(np.mean([r["ms_per_step"] for r in rs])))

    def best(prefix, t):
        cands = [(k[0], st(v)) for k, v in G.items()
                 if k[0].split("@")[0] == prefix and "iters=" not in k[0] and k[1] == t and k[2] == H_MAIN]
        ok = [c for c in cands if c[1]["tip"] == 0 and c[1]["r1"] is not None] or cands
        return min(ok, key=lambda c: (c[1]["tip"], c[1]["r1"] if c[1]["r1"] is not None else 1e9)) if ok else (None, None)

    def ours(t):
        return stats("robust" if t else "robust-rawavg")

    rows, picked = [], {}
    for t in (False, True):
        if t:
            rows.append(r"\midrule")
        s = ours(t)
        ms_ours = float(np.mean([r["ms_per_step"] for r in W[("robust" if t else "robust-rawavg", H_MAIN)]]))
        rows.append(f"Algorithm~\\ref{{alg:unified}} & {s['tip']}/{s['n']} & {fmt(s['r1'])} & {fmt(s['r2'])} & {s['oct']:.2f} & "
                    f"{s['cop']:.2f} & {max(r['dev_max'] for r in W[('robust' if t else 'robust-rawavg', H_MAIN)]):.3f} \\\\")
        for name, prefix in (("Shield-MPPI", "shield"), ("DualGuard MPPI", "dualguard"), ("GS-MPPI", "gs"),
                             ("Offline robust plan", "offline"), ("Online robust NMPC", "online")):
            lab, v = best(prefix, t)
            if lab is None:
                continue
            picked[(prefix, t)] = (lab, v)
            prm = lab.split("@", 1)[1] if "@" in lab else ""
            prm = ("$" + prm.replace("rho=", "\\rho=") + "$") if prm else ""
            rows.append(f"{name}{' (' + prm + ')' if prm else ''} & {v['tip']}/{v['n']} & {fmt(v['r1'])} & {fmt(v['r2'])} & "
                        f"{v['oct']:.2f} & {v['cop']:.2f} & {v['dev']:.3f} \\\\")
            rs1 = G.get((GS1, t, H_MAIN))
            if prefix == "gs" and rs1:
                v1 = st(rs1)
                picked[("gs1", t)] = (GS1, v1)
                rows.append(f"GS-MPPI, one step ($\\rho={GS1.split('rho=')[1].split('@')[0]}$) & {v1['tip']}/{v1['n']} & {fmt(v1['r1'])} & "
                            f"{fmt(v1['r2'])} & {v1['oct']:.2f} & {v1['cop']:.2f} & {v1['dev']:.3f} \\\\")
    # text: the sweep's safety at the top of the prior and the comparison at equal certificates
    def at17(prefix, t):
        lab = picked.get((prefix, t), (None,))[0]
        rs = G.get((lab, t, 0.17), []) if lab else []
        return st(rs) if rs else None
    def over_heights(prefix, t):
        lab = picked.get((prefix, t), (None,))[0]
        rs = [r for h in H_ALL for r in G.get((lab, t, h), [])] if lab else []
        return (sum(r["tipped"] for r in rs), max((r["oct_model_max"] for r in rs), default=float("nan")),
                max((r["cop_true_max"] for r in rs), default=float("nan")), len({r["h_true"] for r in rs}))
    lines = []
    s_o0, s_o1 = ours(False), ours(True)
    v = lambda prefix, t: picked.get((prefix, t), (None, None))[1]  # noqa: E731
    if all(v(p, t) is not None for p in ("shield", "dualguard", "gs", "offline", "online") for t in (False, True)):
        gs0, gs1, sh0, sh1 = v("gs", False), v("gs", True), v("shield", False), v("shield", True)
        dg0, dg1, of0, of1 = v("dualguard", False), v("dualguard", True), v("offline", False), v("offline", True)
        nm0, nm1 = v("online", False), v("online", True)
        lines.append(f"On the waiter, GS-MPPI matched Algorithm~\\ref{{alg:unified}}: {fmt(gs0['r1'])} and {fmt(gs1['r1'])}\\,mm on move~1 with the rows as they are and tightened, against {fmt(s_o0['r1'])} and {fmt(s_o1['r1'])}\\,mm.")
        lines.append("With one binding row at a time its soft-min composite reduces to that row and its safe law to a projection onto it, and it too averages the raw inputs and filters the output, so without physical equalities the two schemes coincide in structure; its closed-form filter is also cheaper than an exact projection.")
        lines.append("They differ where several rows bind at once, which the scenario at the end of this section tests.")
        g1a, g1b = v("gs1", False), v("gs1", True)
        a17, a17t = at17("gs1", False), at17("gs1", True)
        r100 = G.get(("gs@rho=100@iters=1", False, H_MAIN))
        if g1a and g1b and a17 and a17t and r100:
            lines.append("GS-MPPI composes barrier functions of the state, for which the composite CBF condition is affine in the input and one application of its safe law is exact.")
            lines.append("The support rows constrain the input directly, so their soft-min is concave in the input, and one application lands on the zero of its linearisation, where the composite is still negative; "
                         "the GS-MPPI controller above therefore applies the law until the composite holds, at most five times.")
            lines.append(f"Applied once, as published, the law left the executed command outside the true rows: with $\\rho=20$ the model ratio reached {g1a['oct']:.2f} at $h=0.14$\\,m ({st(r100)['oct']:.2f} with $\\rho=100$) "
                         f"and {a17['oct']:.2f} at $h=0.17$\\,m, where {a17['tip']} of {a17['n']} runs tipped, and with the tightened rows it still reached {a17t['oct']:.2f} at $h=0.17$\\,m"
                         + (f", with the box on its edge (true COP ratio {a17t['cop']:.2f})." if a17t["cop"] > 0.99 else "."))
            lines.append(f"The smaller tracking error of this variant ({fmt(g1a['r1'])} and {fmt(g1b['r1'])}\\,mm on move~1) is bought by the violation.")
        lines.append(f"Shield-MPPI kept the rows through its repair but tracked at {fmt(sh0['r1'])} and {fmt(sh1['r1'])}\\,mm, because its rollouts are scored on commands that the repair then changes, and the switch of DualGuard MPPI to the most conservative input tracked at {fmt(dg0['r1'])} and {fmt(dg1['r1'])}\\,mm.")
        sweep_txt = []
        for name, prefix in (("Shield-MPPI", "shield"), ("DualGuard MPPI", "dualguard"), ("GS-MPPI", "gs")):
            tips, oc, cp, nh = over_heights(prefix, False)
            if nh == len(H_ALL):
                sweep_txt.append(f"{name} had {tips} tips, a model ratio of at most {oc:.2f} and a true COP ratio of at most {cp:.2f}")
        if sweep_txt:
            lines.append("Over the four heights, with the rows as they are, " + "; ".join(sweep_txt) + ".")
        g0, g1 = at17("gs", False), at17("gs", True)
        if g0 and g1 and g0["cop"] > 0.99:
            lines.append(f"GS-MPPI put the box on its edge at $h=0.17$\\,m (true COP ratio {g0['cop']:.2f}), as Algorithm~\\ref{{alg:unified}} does without the margin, and with the tightened rows it stayed at {g1['cop']:.2f}: "
                         "any scheme that rides the boundary of the rows needs the calibrated margin.")
        a17, a17t = at17("offline", False), at17("offline", True)
        if a17 and a17t:
            where = "the box tipped" if a17["tip"] else f"the box reached a COP ratio of {a17['cop']:.2f}"
            lines.append(f"The offline plan tracked best ({fmt(of0['r1'])} and {fmt(of1['r1'])}\\,mm), since it optimises the whole run with the reference known in advance.")
            lines.append(f"It certifies the plan, not the executed command: the tracking feedback pushed the model ratio to {of0['oct']:.2f} at $h=0.14$\\,m and to {a17['oct']:.2f} at $h=0.17$\\,m, where {where}, and with tightened rows the box still reached a COP ratio of {a17t['cop']:.2f} there.")
        tim = json.loads((RES / "gpu_timing.json").read_text()) if (RES / "gpu_timing.json").exists() else None
        gpu = f", against {tim['waiter_gpu']['256']['plan_ms']:.0f}\\,ms for the GPU controller of Algorithm~\\ref{{alg:unified}} at the same sample count" if tim else ""
        lines.append(f"The online NMPC, with the cost, horizon and step of the MPPI controllers, kept the rows and tracked at {fmt(nm0['r1'])} and {fmt(nm1['r1'])}\\,mm, "
                     f"{100 * (nm0['r1'] / s_o0['r1'] - 1):.0f} and {100 * (nm1['r1'] / s_o1['r1'] - 1):.0f}\\,\\% behind Algorithm~\\ref{{alg:unified}}, "
                     f"and IPOPT needed {0.5 * (nm0['ms'] + nm1['ms']):.0f}\\,ms per step{gpu}.")
    wb = safe_writing_best()
    if wb:
        gw = group(WRT, lambda r: (r["controller"], r.get("w_s") or 0.0))
        uni = gw[("unified-gpu", 0.0)]
        per = defaultdict(list)
        for lab, rs in wb.items():
            per[lab.split(" (")[0]].append((100 * np.mean([r["in_band"] for r in rs]), np.mean([r["track_rmse_mm"] for r in rs])))

        def rng(vals, f):
            lo, hi = min(vals), max(vals)
            return f.format(lo) if f.format(lo) == f.format(hi) else f.format(lo) + "--" + f.format(hi)
        parts = [f"{name} held the band {rng([x[0] for x in vv], '{:.0f}')}\\,\\% of the time and tracked at {rng([x[1] for x in vv], '{:.1f}')}\\,mm"
                 + (" over its parameter" if len(vv) > 1 else "") for name, vv in per.items()]
        ub, ut = 100 * np.mean([r["in_band"] for r in uni]), np.mean([r["track_rmse_mm"] for r in uni])
        lines.append("\nOn the writing task (Table~\\ref{tab:baselines_writing}), with the contact handled by the Gauss dynamics of Algorithm~\\ref{alg:unified} for all of them, "
                     + "; ".join(parts) + f"; Algorithm~\\ref{{alg:unified}} held it {ub:.0f}\\,\\% of the time at {ut:.1f}\\,mm.")
        gsb = max((x[0] for x in per.get("GS-MPPI", [])), default=None)
        dgw = v("dualguard", False)
        if gsb is not None and dgw is not None and gsb < ub - 5 and dgw["r1"] > 1.5 * s_o0["r1"]:
            lines.append("No baseline did well on both tasks.")
            lines.append("GS-MPPI matched Algorithm~\\ref{alg:unified} on the waiter but lost the band in writing, where its raw average passes the exploration noise along the contact normal to the reaction.")
            lines.append("DualGuard MPPI held the band in writing, where its average of filtered samples acts like the clamped average of Algorithm~\\ref{alg:unified}, but was the most conservative controller on the waiter.")
            lines.append("Algorithm~\\ref{alg:unified} takes the raw average for the motion and the clamped average for the reaction, which separation allows.")
    dual = RES / "dualarm.json"
    if dual.exists():
        dr = [r for r in json.loads(dual.read_text())["rows"] if "error" not in r and r["delta_b_mm"] == 0.0]
        gd = defaultdict(list)
        for r in dr:
            gd[r["controller"]].append(r)
        if all(c in gd for c in ("Shield", "DualGuard", "GS", "Unified", "Unified-eps0")):
            parts = [f"{nm} {'crossed the joint-4 bound by ' + format(max(r['bound_viol'] for r in gd[c]), '.3f') + chr(92) + ',rad' if max(r['bound_viol'] for r in gd[c]) > 0 else 'kept the joint-4 bound'} "
                     f"(goal error {np.mean([r['goal_err'] for r in gd[c]]):.2f}\\,rad, internal force {np.mean([r['W_int_norm_mean'] for r in gd[c]]):.2f}\\,N)"
                     for nm, c in (("Shield-MPPI", "Shield"), ("DualGuard MPPI", "DualGuard"), ("GS-MPPI", "GS"))]
            u, u0 = gd["Unified"], gd["Unified-eps0"]
            lines.append("\nOn the dual-arm task (rows as they are, $\\delta_b=0$, three seeds), " + "; ".join(parts)
                         + f"; Algorithm~\\ref{{alg:unified}} crossed it by {max(r['bound_viol'] for r in u0):.3f}\\,rad without the margin and kept it with the calibrated one "
                         f"(goal error {np.mean([r['goal_err'] for r in u]):.2f}\\,rad).")
            ge_u = np.mean([r["goal_err"] for r in u])
            better = [nm for nm, c in (("Shield-MPPI", "Shield"), ("DualGuard MPPI", "DualGuard"), ("GS-MPPI", "GS"))
                      if max(r["bound_viol"] for r in gd[c]) == 0 and np.mean([r["goal_err"] for r in gd[c]]) < ge_u]
            if better:
                lines.append(f"{' and '.join(better)} kept the bound closer to the goal than Algorithm~\\ref{{alg:unified}}: a barrier on the joint position absorbs the quasi-static sag of the unmodelled tray directly, "
                             "whereas the acceleration bound of Algorithm~\\ref{alg:unified} is set by the oscillation of the grasp springs and is conservative here; "
                             "a position-level execution bound, or the tray load in the model, would remove the difference (open item).")
    txt = SAFE_TEMPLATE.replace("@@SAFE_ROWS@@", "\n".join(rows)).replace("@@SAFE_TEXT@@", "\n".join(lines))
    sh = [r for r in tune if r["method"] == "shield"]
    return txt.replace("@@EPS@@", f"{eps_x:.3f}").replace("@@SH_N@@", "three" if not sh else "three")


CORNER_TEMPLATE = r"""
\paragraph{Several binding rows.}
In the waiter runs above, the moves run along a face normal of the octagons, and one support row binds at a time.
To load a vertex of the rows, the box was given a low friction coefficient, true $\mu=@@MU@@$ with the prior $[@@MU_LO@@, @@MU_HI@@]$, so that the slip rows bind before the tipping rows, and the moves were turned to $@@THETA@@^\circ$ from the tray axes, the direction of a vertex of both octagons of support rows, and shortened to @@T_MOVE@@\,s.
The execution-error bound was calibrated for this scenario as in Section~\ref{sec:robust}, $\varepsilon=@@EPS_C@@$\,m/s$^2$, and Table~\ref{tab:corner} lists the controllers with the robust prior at $h=0.14$\,m, with the parameters tuned on the waiter above.

\begin{table}[h]
\centering
\caption{Several binding rows: the waiter with a low-friction box (true $\mu=@@MU@@$, prior $[@@MU_LO@@, @@MU_HI@@]$) moved at $@@THETA@@^\circ$ to the tray axes in @@T_MOVE@@\,s; true $h=0.14$\,m, robust prior, 5 seeds.  Tipping and slip ratio: the largest ratio of the executed command to the true tipping and slip rows; slide: the largest displacement of the box on the tray.  Upper block: rows as they are; lower block: rows tightened by $\varepsilon=@@EPS_C@@$\,m/s$^2$.}
\label{tab:corner}
\footnotesize
\begin{tabularx}{\linewidth}{l Y Y Y Y Y Y Y}
\toprule
Controller & Tipped & \multicolumn{2}{c}{RMSE [mm]} & Tipping & Slip & True & Slide \\
\cmidrule(lr){3-4}
 & & move 1 & move 2 & ratio & ratio & COP & [mm] \\
\midrule
@@CORNER_ROWS@@
\bottomrule
\end{tabularx}
\end{table}

@@CORNER_TEXT@@
"""

CORNER_ROWS = [
    ("Algorithm~\\ref{alg:unified}", "alg1"),
    ("Algorithm~\\ref{alg:unified}, projected average", "projected"),
    ("GS-MPPI ($\\rho=20$)", "gs@rho=20"),
    ("GS-MPPI ($\\rho=100$)", "gs@rho=100"),
    ("GS-MPPI ($\\rho=1000$)", "gs@rho=1000"),
    ("GS-MPPI, one step ($\\rho=20$)", "gs@rho=20@iters=1"),
    ("Shield-MPPI ($C=1000$)", "shield@C=1000"),
    ("DualGuard MPPI", "dualguard"),
    ("Oracle (true $h$, $\\mu$)", "oracle"),
]


def corner_section():
    files = [RES / n for n in ("corner.json", "corner_rho.json", "corner_exec_bound.json", "corner_gs1_diag.json",
                               "corner_vertex_diag.json", "corner_dg_diag.json")]
    if not all(f.exists() for f in files):
        return ""
    import corner_exp as CE
    rows = [r for f in files[:2] for r in json.loads(f.read_text())["rows"] if "error" not in r]
    eps_c = json.loads(files[2].read_text())["eps_exec"]
    g1d, vd, dgd = (json.loads(f.read_text()) for f in files[3:])
    G = defaultdict(list)
    for r in rows:
        G[(r["label"], r["eps"] > 1e-9)].append(r)

    def st(lab, t):
        rs = G[(lab, t)]
        assert len(rs) == 5, (lab, t, len(rs))
        f = lambda k: float(np.mean([r[k] for r in rs]))  # noqa: E731
        return dict(n=len(rs), tip=sum(r["tipped"] for r in rs), r1=f("rmse1"), r2=f("rmse2"),
                    oct=max(r["oct_model_max"] for r in rs), slip=max(r["slip_model_max"] for r in rs),
                    cop=max(r["cop_true_max"] for r in rs), slide=max(r["box_shift_mm"] for r in rs),
                    reach1=sum(r["reach1"] is not None for r in rs), reach2=sum(r["reach2"] is not None for r in rs),
                    seeds={r["seed"]: r for r in rs})

    S = {(lab, t): st(lab, t) for _, lab in CORNER_ROWS for t in (False, True)}
    out = []
    for t in (False, True):
        if t:
            out.append(r"\midrule")
        for name, lab in CORNER_ROWS:
            s = S[(lab, t)]
            out.append(f"{name} & {s['tip']}/{s['n']} & {fmt(s['r1'])} & {fmt(s['r2'])} & {s['oct']:.2f} & {s['slip']:.2f} & "
                       f"{s['cop']:.2f} & {s['slide']:.1f} \\\\")

    def paired_gap(lab, t, key="rmse1"):
        a, b = S[("alg1", t)]["seeds"], S[(lab, t)]["seeds"]
        return [b[k][key] - a[k][key] for k in sorted(a)]

    gs_iter = ("gs@rho=20", "gs@rho=100", "gs@rho=1000")
    kept = lambda s: s["oct"] <= 1.0 + 1e-3 and s["slip"] <= 1.0 + 1e-3 and s["tip"] == 0  # noqa: E731
    robust_labs = [lab for _, lab in CORNER_ROWS if lab != "oracle"]
    L = []
    a0, a1 = S[("alg1", False)], S[("alg1", True)]
    if sum(S[k]["tip"] for k in S) == 0:
        L.append("No controller tipped the box.")
    best_kept = all(S[(lab, t)]["r1"] >= S[("alg1", t)]["r1"] for t in (False, True) for lab in robust_labs if kept(S[(lab, t)]))
    if best_kept:
        L.append(f"Among the controllers with the robust prior that kept the rows, Algorithm~\\ref{{alg:unified}} tracked best, at {fmt(a0['r1'])} and {fmt(a1['r1'])}\\,mm on move~1 with the rows as they are and tightened.")
    gaps = [100 * (S[(lab, t)]["r1"] / S[("alg1", t)]["r1"] - 1) for lab in gs_iter for t in (False, True)]
    all_behind = all(g > 0 for lab in gs_iter for t in (False, True) for g in paired_gap(lab, t))
    L.append(f"GS-MPPI, with its law applied until the composite holds, followed {min(gaps):.0f}--{max(gaps):.0f}\\,\\% behind"
             + (" in every seed" if all_behind else "")
             + ", and neither a sharper soft-min ($\\rho=1000$) nor twenty applications of the law closed the gap"
             + f" ({fmt(S[('gs@rho=1000', False)]['r1'])} and {fmt(S[('gs@rho=1000', True)]['r1'])}\\,mm).")
    P = vd["plans"]
    V = [d for d in P if d["act_pi"] >= 2]
    one_face = all(d["act_gs"] == 1 for d in V)
    farther = np.mean([d["dist_gs"] / d["dist_pi"] - 1 for d in V]) * 100
    if V and one_face:
        sec = [d["second_gs"] for d in V]
        L.append(f"In one run (seed {vd['seed']}, tightened rows) the raw mean violated the rows in {len(P)} plans, and in {len(V)} of them its projection landed on a vertex, with two rows active.")
        L.append(f"There the law, applied until the composite held with $\\rho=1000$, ended on one of the two rows and inside the other, by {np.median(sec):.2f}\\,rad/s$^2$ in the median and up to {max(sec):.2f}\\,rad/s$^2$ in the distance of the command to that row, "
                 f"and it moved the command {farther:.0f}\\,\\% farther from the raw mean in the inertia metric than the projection did.")
        L.append("A step onto one row also moves the command to the feasible side of the adjacent row, so a sequence of such steps stops on a face; the projection treats the active rows together and lands on the vertex.")
    g1 = g1d["plans"]
    bad = [d for d in g1 if d["after"]["1"]["n_viol"]]
    s10, s11 = S[("gs@rho=20@iters=1", False)], S[("gs@rho=20@iters=1", True)]
    near1 = np.mean([d["n_near"] == 1 for d in bad])
    L.append(f"Applied once, the law left the command outside the true rows, with slip ratios of up to {s10['slip']:.2f} and {s11['slip']:.2f} and tipping ratios of up to {s10['oct']:.2f} and {s11['oct']:.2f}.")
    L.append(f"In its run of seed {g1d['seed']} with the tightened rows, up to {max(d['n_viol0'] for d in g1)} rows were violated at the raw mean"
             + (", the soft-min was dominated by the most violated row" if near1 > 0.9 else "")
             + f", and after one application rows were still violated in {len(bad)} of {len(g1)} plans, up to {max(d['after']['1']['n_viol'] for d in g1)} of them; "
             f"after two applications at most {max(d['after']['2']['n_viol'] for d in g1)} and after five none.")
    sl_kept = max(S[(lab, t)]["slide"] for lab in ("alg1",) + gs_iter for t in (False, True))
    L.append(f"The box slid by up to {s11['slide']:.1f}\\,mm, against at most {sl_kept:.1f}\\,mm under Algorithm~\\ref{{alg:unified}} and GS-MPPI applied to convergence.")
    sh0, sh1, dg0, dg1 = S[("shield@C=1000", False)], S[("shield@C=1000", True)], S[("dualguard", False)], S[("dualguard", True)]
    miss = lambda s: [i + 1 for i, k in enumerate(("reach1", "reach2")) if s[k] == 0]  # noqa: E731
    def miss_txt(s):
        m = miss(s)
        return "" if not m else (" and never came within 1\\,cm of the " + (" or the ".join(("first", "second")[i - 1] for i in m)) + " target")
    L.append(f"Shield-MPPI kept the rows but tracked at {fmt(sh0['r1'])} and {fmt(sh1['r1'])}\\,mm on move~1 and {fmt(sh0['r2'])} and {fmt(sh1['r2'])}\\,mm on move~2"
             + (f"; with the rows as they are it{miss_txt(sh0)[4:]}" if miss(sh0) else "")
             + (f", and with the tightened rows it{miss_txt(sh1)[4:]}." if miss(sh1) else "."))
    L.append(f"DualGuard MPPI tracked at {fmt(dg0['r1'])} and {fmt(dg1['r1'])}\\,mm on move~1{miss_txt(dg0) if miss(dg0) == miss(dg1) else ''}.")
    L.append("Its safe input for the support rows, zero tangential tray acceleration, keeps the tray velocity, so a braking sample that violates the rows is replaced by one that does not brake: "
             f"in the run of seed {dgd['seed']} with the rows as they are, its filter replaced {100 * dgd['switched_mean']:.0f}\\,\\% of the samples on average and up to {100 * dgd['switched_max']:.0f}\\,\\%, "
             f"and the tray passed the first target by {dgd['overshoot_mm']:.0f}\\,mm.")
    p0, p1 = S[("projected", False)], S[("projected", True)]
    L.append(f"With the projection as its safe input, DualGuard MPPI would compute, up to its joint-limit filter, the projected average of the ablation, which tracked at {fmt(p0['r1'])} and {fmt(p1['r1'])}\\,mm; "
             f"the raw average of Algorithm~\\ref{{alg:unified}} again did better by {100 * (1 - a0['r1'] / p0['r1']):.0f} and {100 * (1 - a1['r1'] / p1['r1']):.0f}\\,\\%.")
    o0, o1 = S[("oracle", False)], S[("oracle", True)]
    L.append(f"With the true parameters Algorithm~\\ref{{alg:unified}} tracked at {fmt(o0['r1'])} and {fmt(o1['r1'])}\\,mm, "
             f"and without the margin its command rode the true slip rows (ratio {o0['slip']:.2f}) and the box slid by up to {o0['slide']:.1f}\\,mm; "
             f"the difference in tracking is the price of the lower friction bound of the prior, which caps the slip ratio at {CE.MU_PRIOR[0] / CE.MU_TRUE:.2f}.")
    txt = CORNER_TEMPLATE.replace("@@CORNER_ROWS@@", "\n".join(out)).replace("@@CORNER_TEXT@@", "\n".join(L))
    rep = {"@@MU@@": f"{CE.MU_TRUE:.2f}", "@@MU_LO@@": f"{CE.MU_PRIOR[0]:.2f}", "@@MU_HI@@": f"{CE.MU_PRIOR[1]:.2f}",
           "@@THETA@@": f"{np.rad2deg(CE.THETA):.1f}", "@@T_MOVE@@": f"{CE.T_MOVE:.1f}", "@@EPS_C@@": f"{eps_c:.3f}"}
    for k, v in rep.items():
        txt = txt.replace(k, v)
    return txt


def build():
    txt = TEMPLATE.replace("@@MAIN@@", main_table()).replace("@@SWEEP@@", sweep_table())
    txt = txt.replace("@@WRITING@@", writing_table())
    for k, v in num().items():
        txt = txt.replace(f"@@{k}@@", v)
    txt += safe_section()
    txt += corner_section()
    assert "@@" not in txt, txt[txt.index("@@") - 40:txt.index("@@") + 40]
    OUT.write_text(txt, encoding="utf-8")
    print("wrote", OUT, "| best weights A1", W_A1, "A2", W_A2, "A2 tight", W_A2T)


if __name__ == "__main__":
    build()
